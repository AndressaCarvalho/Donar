<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/cadastroDoacao.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });


    //Para monstrar a imagens
    function previewImagem1() {
      var imagem = document.querySelector('input[name=imgb1]').files[0];
      var preview = document.querySelector('img[name=imgPreview1]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem2() {
      var imagem = document.querySelector('input[name=imgb2]').files[0];
      var preview = document.querySelector('img[name=imgPreview2]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem3() {
      var imagem = document.querySelector('input[name=imgb3]').files[0];
      var preview = document.querySelector('img[name=imgPreview3]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem4() {
      var imagem = document.querySelector('input[name=imgb4]').files[0];
      var preview = document.querySelector('img[name=imgPreview4]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem5() {
      var imagem = document.querySelector('input[name=imgb5]').files[0];
      var preview = document.querySelector('img[name=imgPreview5]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <div class="container-fluid row divprincipal corfonte fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <form class="box form-horizontal col-11 col-sm-11 col-md-11 col-lg-7 col-xl-7" method="post" action="<?php echo base_url("CadastroDoacao/cadastrarDoacao"); ?>" enctype="multipart/form-data">
      <fieldset>

        <legend class="fonte1 titulo1 corfonte">Doar</legend>

        <div class="row divs rowimagens col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <label id="lbl_img1" class="lbl_img1" for="imgb1"><img name="imgPreview1" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi1" class="img4 col-11 col-sm-11 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb1" name="imgb1" accept="image/png, image/jpeg" onchange="previewImagem1()">

          <label id="lbl_img2" class="lbl_img2" for="imgb2"><img name="imgPreview2" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi2" class="img4 col-11 col-sm-11 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb2" name="imgb2" accept="image/png, image/jpeg" onchange="previewImagem2()">

          <label id="lbl_img3" class="lbl_img3" for="imgb3"><img name="imgPreview3" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi3" class="img4 col-11 col-sm-11 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb3" name="imgb3" accept="image/png, image/jpeg" onchange="previewImagem3()">

          <label id="lbl_img3" class="lbl_img4" for="imgb4"><img name="imgPreview4" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi4" class="img4 col-11 col-sm-11 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb4" name="imgb4" accept="image/png, image/jpeg" onchange="previewImagem4()">

          <label id="lbl_img5" class="lbl_img5" for="imgb5"><img name="imgPreview5" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi5" class="img4 col-11 col-sm-11 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb5" name="imgb5" accept="image/png, image/jpeg" onchange="previewImagem5()">
        </div>

          <?php
            foreach ($vulner as $li => $list) { ?>

              <input type="hidden" id="vulner" name="vulner" value="<?php echo $list; ?>" readonly="readonly">

            <?php
            }
          ?>

        <div class="row divcatuni divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <select name="categoriaLista" id="categoriaLista" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($categorias as $li2 => $l2) {
                foreach ($l2 as $li2 => $list2) { ?>
                  <option value="<?php if ($list2->id_categoria_sup != null) { echo $list2->id_categoria; } else { echo ''; } ?>" <?php if ($list2->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list2->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-2 col-sm-2 col-md-2 col-lg-1 col-xl-1">
           <input type="text" id="quantidade" name="quantidade" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista" id="uniLista" class="uniLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unidades as $li3 => $l3) {
                foreach ($l3 as $lis3 => $list3) { ?>
                  <option value="<?php echo $list3->id_unidade; ?>">
                    <?php echo $list3->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

        </div>

        <div class="divenviar col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
          <input type="submit" id="enviar" name="enviar" value="Enviar" class="btn btn-primary botao2 col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></input>
        </div>

      </fieldset>
    </form>
  </div>
    

</body>
</html>