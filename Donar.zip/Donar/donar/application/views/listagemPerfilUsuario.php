<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/listagemPerfilUsuario.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });

  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <?php if($this->session->flashdata('senha_erradaa1')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('senha_erradaa1'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('senha_erradaa2')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('senha_erradaa2'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('usuario_atualizado')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('usuario_atualizado'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('ava_cadastrado')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('ava_cadastrado'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('erro_form')) { ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <?php echo $this->session->flashdata('erro_form'); ?>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php } ?>

  <div class="container-fluid row divprincipal corfonte fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="box col-10 col-sm-10 col-md-10 col-lg-7 col-xl-7">

      <form method="post" class="form-horizontal" action="<?php echo base_url('/ListagemPerfilUsuario/atualizarExcluir'); ?>">

      <?php
        foreach ($infusuario as $li => $l) {
          foreach ($l as $li => $list) { ?>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <img src="<?php echo base_url("/upload_img/$list->nome_img_perfil"); ?>" class="img4 col-7 col-sm-7 col-md-6 col-lg-3 col-xl-3"/>

              <div class="divtavaliador col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
                <?php
                  if ((((!$this->session->userdata('id_avaliador')) && (!$this->session->userdata('id_adm'))) && empty($avaliador)) && empty($usava)) { ?>
                    
                    <input type="submit" id="tavaliador" name="tavaliador" class="btn btn-primary corfonte2 fonte3 text-center col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 botao20" value="Tornar-se um avaliador"></input>

                  <?php
                  }

                ?>
                </div>

                <div class="diveditarexcluir col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                  <input type="submit" id="editar" value="" name="editar" class="img img5 col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" src="<?php echo base_url("/assets/img/editar.png"); ?>"></input>
                  <input type="submit" id="excluir" name="excluir" class="img img6 col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4" value="" src="<?php echo base_url("/assets/img/excluir.png"); ?>"></input>
                </div>

            </div>

            <input type="hidden" id="nome_img_perfil" name="nome_img_perfil" value="<?php echo $list->nome_img_perfil; ?>" readonly="readonly">

            <input type="hidden" id="nome_usuario" name="nome_usuario" value="<?php echo $list->nome_usuario; ?>" readonly="readonly">

            <input type="hidden" id="email" name="email" value="<?php echo $list->email; ?>" readonly="readonly">

            <input type="hidden" id="telefone_usuario" name="telefone_usuario" value="<?php echo $list->telefone_usuario; ?>" readonly="readonly">

            <input type="hidden" id="nome_rua_usuario" name="nome_rua_usuario" value="<?php echo $list->nome_rua_usuario; ?>" readonly="readonly">

            <input type="hidden" id="numero_rua_usuario" name="numero_rua_usuario" value="<?php echo $list->numero_rua_usuario; ?>" readonly="readonly">

            <input type="hidden" id="cep_usuario" name="cep_usuario" value="<?php echo $list->cep_usuario; ?>" readonly="readonly">


            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Nome: '.$list->nome_usuario; ?></p>
            </div>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Email: '.$list->email; ?></p>
            </div>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Número de telefone para contato: '.$list->telefone_usuario; ?></p>
            </div>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Localização: '.$list->nome_rua_usuario.', '.$list->numero_rua_usuario.' - ';

          }
        }

        foreach ($bairro as $li2 => $l2) {
          foreach ($l2 as $li2 => $list2) {
            echo $list2->nome_bairro.', '; ?>

            <input type="hidden" id="nome_bairro" name="nome_bairro" value="<?php echo $list2->nome_bairro; ?>" readonly="readonly">

          <?php
          }
        }

        foreach ($cidade as $li3 => $l3) {
          foreach ($l3 as $li3 => $list3) {
            echo $list3->nome_cidade.' - '.$list3->sigla_estado.', '; ?>

            <input type="hidden" id="nome_cidade" name="nome_cidade" value="<?php echo $list3->nome_cidade; ?>" readonly="readonly">

            <input type="hidden" id="sigla_estado" name="sigla_estado" value="<?php echo $list3->sigla_estado; ?>" readonly="readonly">

          <?php
          }
        }

        foreach ($infusuario as $li5 => $l5) {
          foreach ($l5 as $li5 => $list5) {
            echo $list5->cep_usuario; ?>
              
              </p>
            </div>

          <?php
          }
        }

      ?>

      </form>
      
    </div>
  </div>
    

</body>
</html>