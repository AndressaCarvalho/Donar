<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/detalhesVulnerDenunciada.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });
  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <div class="container-fluid row divprincipal corfonte col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="box col-10 col-sm-10 col-md-10 col-lg-10 col-xl-10">
     
      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        
        <?php
        foreach ($denuncia as $li5 => $l5) {
          foreach ($l5 as $lis5 => $list5) {
            
            if ($list5->data_denuncia_vulner) {
              $dia = substr($list5->data_denuncia_vulner, -2);
              $mes = substr($list5->data_denuncia_vulner, 5, 2);
              $ano = substr($list5->data_denuncia_vulner, 0, 4);
              $horario = substr($list5->horario_denuncia_vulner, 0, 5); ?>

              <p class="datahora"><?php echo $dia.'-'.$mes.'-'.$ano.' às '.$horario; ?></p>
            
            <?php
            }

          }
        } ?>

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p class="fonte1 titulovulner">Situação de vulnerabilidade social</p>
      </div>

      <div class="row divs rowimg col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        
      <?php

        $aux1 = false;
        foreach ($imagensv as $li6 => $l6) {
          foreach ($l6 as $lis6 => $list6) {
           
            if ($list6->nome_img_vulner) {
              $aux1 = true;
              ?>
              
              <img src="<?php echo base_url("/upload_img/$list6->nome_img_vulner"); ?>" class="imglist col-7 col-sm-7 col-md-5 col-lg-2 col-xl-2"></img>
            
            <?php
            }

          }
        }

        
        if ($aux1 == false) { ?>
          
          <p class="semimg fonte2">Nenhuma imagem disponível...</p>        
        
        <?php
        }

        ?>

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

        <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php
          foreach ($vulner as $li7 => $l7) {
            foreach ($l7 as $lis7 => $list7) {
              
              if ($list7->titulo_vulner) { ?>
                <p class="fonte2"><?php echo 'Título: '.$list7->titulo_vulner; ?></p>
              <?php
              } ?>
        </div>

        <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <?php
              if ($list7->descricao_vulner) { ?>
                <p class="fonte2"><?php echo 'Descrição: '.$list7->descricao_vulner; ?></p>
              <?php
              }

            }
          } ?>
        </div>

        <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <?php
          foreach ($bairro as $li9 => $l9) {
            foreach ($l9 as $lis9 => $list9) { ?>

              <p class="fonte2"><?php echo 'Localização: '.$list9->nome_bairro.', ';

            }
          }

          foreach ($cidade as $li8 => $l8) {
            foreach ($l8 as $lis8 => $list8) {
              
              echo $list8->nome_cidade.' - '.$list8->sigla_estado; ?></p>
            
            <?php
            }
          } ?>

        </div>


        <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <p class="fonte2">Categorias:

            <?php
            foreach ($itensv as $li => $l) {
              foreach ($l as $lis => $list) {

                foreach ($categoriasv as $li2 => $l2) {
                  foreach ($l2 as $li2 => $list2) {
                    if ($list->id_categoria == $list2->id_categoria) {
                      echo ' '.$list2->nome_categoria.' ';

                      echo '('.$list->quantidade_vulner;

                      foreach ($unidadesv as $li4 => $l4) {
                        foreach ($l4 as $li4 => $list4) {
                          if ($list->id_unidade == $list4->id_unidade) {
                            echo ' '.$list4->nome_unidade.');';
                            break;
                          }
                          
                        }
                      }

                      break;
                      
                    }
                    
                  }
                }

              }
            }
            ?>

          </p>

        </div>
      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>


      <div class="row divs divdet col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p class="fonte1 titulomotivacao">Motivo da denúncia</p>

        <?php
        foreach ($motivacao as $li23 => $l23) {
          foreach ($l23 as $lis23 => $list23) {

            if ($list23->motivacao) { ?>

              <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <p class="fonte2"><?php echo $list23->motivacao; ?></p>
              </div>

            <?php
            }

          }
        }
        ?>

        <?php
        foreach ($denuncia as $li24 => $l24) {
          foreach ($l24 as $lis24 => $list24) {

            if (!is_null($list24->detalhamento_denuncia_vulner)) { ?>

              <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <p class="fonte2"><?php echo 'Detalhamento: '.$list24->detalhamento_denuncia_vulner; ?></p>
              </div>

            <?php
            }

          }
        }
        ?>

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>


      <div class="row divs divbotao col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        
        <?php
        foreach ($infdenunciado as $li16 => $l16) {
          foreach ($l16 as $lis16 => $list16) {

            if ($list16->id_usuario) { ?>

                <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p class="fonte1 titulodenunciado">Dados do denunciado (usuário que cadastrou a situação de vulnerabilidade social)</p>
                </div>

                <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <img src="<?php echo base_url("/upload_img/$list16->nome_img_perfil"); ?>" class="img4 col-7 col-sm-7 col-md-6 col-lg-3 col-xl-3"/>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Nome: '.$list16->nome_usuario; ?></p>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Email: '.$list16->email; ?></p>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Número de telefone para contato: '.$list16->telefone_usuario; ?></p>
                </div>

            <?php
            }

          }
        } ?>

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>


      <div class="row divs divbotao col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        
        <?php
        foreach ($infavaliador as $li19 => $l19) {
          foreach ($l19 as $lis19 => $list19) {

            if ($list19->id_usuario) { ?>

                <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p class="fonte1 tituloavaliador">Dados do avaliador da situação de vulnerabilidade social</p>
                </div>

                <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <img src="<?php echo base_url("/upload_img/$list19->nome_img_perfil"); ?>" class="img4 col-7 col-sm-7 col-md-6 col-lg-3 col-xl-3"/>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Nome: '.$list19->nome_usuario; ?></p>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Email: '.$list19->email; ?></p>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Número de telefone para contato: '.$list19->telefone_usuario; ?></p>
                </div>

            <?php
            }

          }
        } ?>

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>

      <div class="row divs divbotao col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php
        foreach ($infdenunciador as $li17 => $l17) {
          foreach ($l17 as $lis17 => $list17) {

            if ($list17->id_usuario) { ?>

                <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p class="fonte1 titulodenunciador">Dados do denunciador</p>
                </div>

                <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <img src="<?php echo base_url("/upload_img/$list17->nome_img_perfil"); ?>" class="img4 col-7 col-sm-7 col-md-6 col-lg-3 col-xl-3"/>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Nome: '.$list17->nome_usuario; ?></p>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Email: '.$list17->email; ?></p>
                </div>

                <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <p><?php echo 'Número de telefone para contato: '.$list17->telefone_usuario; ?></p>
                </div>

            <?php
            }

          }
        } ?>
      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>

      <div class="row divs divbotao col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      
        <?php
          foreach ($denuncia as $li15 => $l15) {
            foreach ($l15 as $lis15 => $list15) {

              if ($list15->id_denuncia_vulner) { ?>

                <form method="post" action="<?php echo base_url("/ListagemVulnerDenunciada/confirmarNegarDenunciaVulner"); ?>" class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <input type="hidden" id="dvulner" name="dvulner" value="<?php echo $list15->id_denuncia_vulner; ?>" readonly="readonly">

              <?php
              }

            }
          }

          foreach ($infavaliador as $li20 => $l20) {
            foreach ($l20 as $lis20 => $list20) {

              if ($list20->id_usuario) { ?>
                
                <input type="hidden" id="avaliador" name="avaliador" value="<?php echo $list20->id_usuario; ?>" readonly="readonly">

              <?php
              }

            }
          }

          foreach ($vulner2 as $li22 => $list22) { ?>
              
            <input type="hidden" id="vulner" name="vulner" value="<?php echo $list22; ?>" readonly="readonly">

            <?php
          }

          foreach ($infdenunciado as $li18 => $l18) {
            foreach ($l18 as $lis18 => $list18) {

              if ($list18->id_usuario) { ?>
                
                  <input type="hidden" id="usuario" name="usuario" value="<?php echo $list18->id_usuario; ?>" readonly="readonly">
                  <div class="divbusava col-11 col-sm-11 col-md-10 col-lg-3 col-xl-3">
                    <input type="submit" id="busava" name="busava" value="Banir usuário e avaliador" class="btn btn-primary botao1 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"></input>
                  </div>
                  <div class="divnbusava col-12 col-sm-12 col-md-9 col-lg-4 col-xl-4">
                    <input type="submit" id="nbusava" name="nbusava" value="Negar banimento ao usuário e ao avaliador" class="btn btn-primary botao20 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"></input>
                  </div>

                </form>

              <?php
              }

            }
          } ?>

      </div>

    </div>
  </div>
    

</body>
</html>