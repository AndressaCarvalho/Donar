<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/DataTables-1.10.20/js/jquery.dataTables.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/DataTables-1.10.20/js/dataTables.bootstrap4.min.js"); ?>"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/DataTables/DataTables-1.10.20/css/dataTables.bootstrap4.min.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/DataTables/DataTables-1.10.20/css/dataTables.bootstrap.css"); ?>">

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/listagemVulnerCadastrada.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });





    $(document).ready(function() {
      $('#table_id').DataTable( {
          "language": {
              "sEmptyTable": "Nenhum registro encontrado",
              "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
              "sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
              "sInfoFiltered": "(Filtrados de _MAX_ registros)",
              "sInfoPostFix": "",
              "sInfoThousands": ".",
              "sLengthMenu": "_MENU_ resultados por página",
              "sLoadingRecords": "Carregando...",
              "sProcessing": "Processando...",
              "sZeroRecords": "Nenhum registro encontrado",
              "sSearch": "Pesquisar",
              "oPaginate": {
                  "sNext": "Próximo",
                  "sPrevious": "Anterior",
                  "sFirst": "Primeiro",
                  "sLast": "Último"
              },
              "oAria": {
                  "sSortAscending": ": Ordenar colunas de forma ascendente",
                  "sSortDescending": ": Ordenar colunas de forma descendente"
              },
              "select": {
                  "rows": {
                      "_": "Selecionado %d linhas",
                      "0": "Nenhuma linha selecionada",
                      "1": "Selecionado 1 linha"
                  }
              }
          }
      } );
    } );


    $('#table_id').DataTable({
        "columnDefs": [
            { "orderable": false, "targets": [0, 1, 2, 3] }
        ]
    });
  </script>

</head>
<body>

  <style type="text/css">
    .dataTables_filter {
      display: none;
    }

    table#table_id.dataTable tbody tr {
      background-color: white;
    }
     
    table#table_id.dataTable tbody tr .sorting_1 {
      background-color: white;
    }

    table#table_id.dataTable thead .sorting, 
    table#table_id.dataTable thead .sorting_asc, 
    table#table_id.dataTable thead .sorting_desc {
      display: none;
    }
  </style>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <?php if($this->session->flashdata('senha_erradaa3')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('senha_erradaa3'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('vulner_excluida')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('vulner_excluida'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('erro_form')) { ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <?php echo $this->session->flashdata('erro_form'); ?>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php } ?>

  <div class="container-fluid divprincipal col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

    <table id="table_id" class="table table-striped table-bordered" style="width: 100%">
      <thead>
        <tr>
          <th scope="col"></th>
          <th scope="col"></th>
          <th scope="col"></th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>

    <?php
      if (!$this->session->userdata('retorno_inexistente4')) {

        $aux1 = false;

        foreach ($vulners as $li => $l) {
          foreach ($l as $lis => $list) { ?>

            <tr>

              <?php

                foreach ($imgs as $li2 => $l2) {
                  foreach ($l2 as $lis2 => $list2) {

                    if ($list->id_vulner == $list2->id_vulner) { ?>

                      <td align="center" style="vertical-align: middle">
                        <img src="<?php echo base_url("/upload_img/$list2->nome_img_vulner"); ?>" class="imglist"></img>
                      </td>

                      <?php

                      $aux1 = true;
                        break;
                    } else {
                      $aux1 = false;
                    }

                  }
                }

                if ($aux1 == false) { ?>
                    
                  <td align="center" style="vertical-align: middle">                  
                    <img src="<?php echo base_url("/upload_img/defaultdoacao.png"); ?>" class="imglist"></img>
                  </td>
                                      
                  <?php
                }


                $dia = substr($list->data_vulner, -2);
                $mes = substr($list->data_vulner, 5, 2);
                $ano = substr($list->data_vulner, 0, 4);
                $horario = substr($list->horario_vulner, 0, 5);


                ?>
                  
                  <td align="center" style="vertical-align: middle">                     
                    <span class="titulo"><?php echo $list->titulo_vulner; ?></span>
                  </td>

                  <td align="center" style="vertical-align: middle"> 
                    <?php echo $dia.'-'.$mes.'-'.$ano.' às '.$horario; ?>
                  </td>
                                    
                </div>

                <td style="vertical-align: middle" align="center">
                  <form method="post" action="<?php echo base_url("/ListagemVulnerCadastrada/detalhesVulnerCadastrada"); ?>">
                    <input type="hidden" id="vulner" name="vulner" value="<?php echo $list->id_vulner; ?>" readonly="readonly">
                    <div>
                      <input type="image" id="detalhes" name="detalhes" class="detalhes" src="<?php echo base_url("/assets/img/detalhes.png"); ?>"></input>
                    </div>
                  </form>
                </td>

              </tr>

            <?php


          }
        } ?>

          </tbody>
        </table>

      <?php
      } else { ?>
        <span class="semretorno"><?php echo $this->session->userdata('retorno_inexistente4'); ?></span>
      <?php
      }
  ?>
  </div>
    

</body>
</html>