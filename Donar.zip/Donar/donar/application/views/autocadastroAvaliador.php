<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/autocadastroAvaliador.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });


    //Para monstrar a imagens
    function previewImagem1() {
      var imagem = document.querySelector('input[name=imgb1]').files[0];
      var preview = document.querySelector('img[name=imgPreview1]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem2() {
      var imagem = document.querySelector('input[name=imgb2]').files[0];
      var preview = document.querySelector('img[name=imgPreview2]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <?php if($this->session->flashdata('sem_imgs')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('sem_imgs'); ?>
    </div>
  <?php } ?>

  <div class="container-fluid row divprincipal corfonte fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <form class="box form-horizontal col-12 col-sm-12 col-md-12 col-lg-7 col-xl-7" method="post" action="<?php echo base_url("AutocadastroAvaliador"); ?>" enctype="multipart/form-data">
      <fieldset>

        <legend class="fonte1 corfonte">Cadastrar-se como avaliador</legend>

        <span class="titulo1 row">Imagem da carteira de identidade (frente e verso)</span>
        <div class="row divs rowimagens col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="row divimg">
            <label id="lbl_img1" class="lbl_img1" for="imgb1"><img name="imgPreview1" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi1" class="img4 col-11 col-sm-11 col-md-10 col-lg-12 col-xl-12"/></label>
            <input type="file" id="imgb1" name="imgb1" accept="image/png, image/jpeg" onchange="previewImagem1()">
          </div>
        </div>

        <span class="row titulo2">Imagem do comprovante de residência</span>
        <div class="row divs rowimagens col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="row divimg">
            <label id="lbl_img2" class="lbl_img2" for="imgb2"><img name="imgPreview2" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi2" class="img4 col-11 col-sm-11 col-md-10 col-lg-12 col-xl-12"/></label>
            <input type="file" id="imgb2" name="imgb2" accept="image/png, image/jpeg" onchange="previewImagem2()">
          </div>
        </div>

        <div class="divenviar col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
          <input type="submit" id="enviar" name="enviar" value="Enviar" class="btn btn-primary col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></input>
        </div>

      </fieldset>
    </form>
  </div>
    

</body>
</html>