<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/cadastroDenunciaVulner1.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });
  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <div class="container-fluid row divprincipal corfonte fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <form class="box form-horizontal col-11 col-sm-11 col-md-11 col-lg-7 col-xl-7" method="post" action="<?php echo base_url("CadastroDenunciaVulner1"); ?>">
      <fieldset>

        <legend class="fonte1 corfonte text-center">Denunciar</legend>

          <?php
            foreach ($vulner as $li => $list) { ?>

              <input type="hidden" id="vulner" name="vulner" value="<?php echo $list; ?>" readonly="readonly">

            <?php
            }
          ?>

        <div class="row divs">

          <select name="motivoLista" id="motivoLista" class="motivoLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Motivo
            </option>
            <?php
              foreach ($motivacoes as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_motivacao; ?>">
                    <?php echo $list->motivacao; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>
        </div>

        <div class="row divs">

          <div class="form-group detalhamento fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="detalhamento">Detalhamento do motivo da denúncia</label>
            <div class="input-group inputBox2">
              <textarea id="detalhamento" name="detalhamento" rows="5" maxlength="254" class="form-control input-md"></textarea>
              
            </div>
          </div>

        </div>

        <div class="divenviar col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
          <input type="submit" id="enviar" name="enviar" value="Enviar" class="btn btn-primary botao2 col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4"></input>
        </div>

      </fieldset>
    </form>
  </div>
    

</body>
</html>