<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/atualizacaoPerfilUsuario.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });


    //Para monstrar a imagens
    function previewImagem1() {
      var imagem = document.querySelector('input[name=imgb1]').files[0];
      var preview = document.querySelector('img[name=imgPreview1]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    //Para a máscara do CEP
    function mascara1(t, mask){
      var i = t.value.length;
      var saida = mask.substring(1,0);
      var texto = mask.substring(i)
      if (texto.substring(0,1) != saida){
        t.value += texto.substring(0,1);
      }
    }

    //Para a máscara do número de telefone
    function mascara2(numTelefone){
      if(numTelefone.value.length == 2)
        numTelefone.value = numTelefone.value + ' '; //quando o campo já tiver 3 caracteres (um parênteses e 2 números) o script irá inserir mais um parênteses, fechando assim o código de área.
     
      if(numTelefone.value.length == 8)
        numTelefone.value = numTelefone.value + '-'; //quando o campo já tiver 8 caracteres, o script irá inserir um tracinho, para melhor visualização do telefone.
      
    }

    //Para encontrar o endereço
    function limpa_formulário_cep() {
      //Limpa valores do formulário de cep.
      document.getElementById('rua').value = ("");
      document.getElementById('bairro').value = ("");
      document.getElementById('cidade').value = ("");
      document.getElementById('uf').value = ("");
    }

    function meu_callback(conteudo) {
      if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('rua').value = (conteudo.logradouro);
        document.getElementById('bairro').value = (conteudo.bairro);
        document.getElementById('cidade').value = (conteudo.localidade);
        document.getElementById('uf').value = (conteudo.uf);
      } //end if.
      else {
        //CEP não Encontrado.
        limpa_formulário_cep();
        alert("CEP não encontrado.");
      }
    }

    function pesquisacep(valor) {

      //Nova variável "cep" somente com dígitos.
      var cep = valor.replace(/\D/g, '');

      //Verifica se campo cep possui valor informado.
      if (cep != "") {

        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;

        //Valida o formato do CEP.
        if (validacep.test(cep)) {

          //Preenche os campos com "..." enquanto consulta webservice.
          document.getElementById('rua').value = "...";
          document.getElementById('bairro').value = "...";
          document.getElementById('cidade').value = "...";
          document.getElementById('uf').value = "...";

          //Cria um elemento javascript.
          var script = document.createElement('script');

          //Sincroniza com o callback.
          script.src = 'https://viacep.com.br/ws/' + cep + '/json/?callback=meu_callback';

          //Insere script no documento e carrega o conteúdo.
          document.body.appendChild(script);

        } //end if.
        else {
          //cep é inválido.
          limpa_formulário_cep();
          alert("Formato de CEP inválido.");
        }
      } //end if.
      else {
        //cep sem valor, limpa formulário.
        limpa_formulário_cep();
      }
    };

  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <div class="container-fluid row divprincipal">

    <form class="box form-horizontal col-12 col-sm-10 col-md-8 col-lg-8 col-xl-8" method="post" action="<?php echo base_url("/AtualizacaoPerfilUsuario"); ?>" enctype="multipart/form-data">
      <fieldset>

        <legend class="fonte1 corfonte text-center">Atualizar perfil</legend>

        <div class="row">
          <label id="lbl_img1" class="lbl_img1" for="imgb1"><img name="imgPreview1" src="<?php echo base_url("/upload_img/$nome_img_perfil"); ?>" id="imgi1" class="img4 col-10 col-sm-10 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb1" name="imgb1" accept="image/png, image/jpeg" onchange="previewImagem1()">
        </div>

        <div class="row">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="nome">Nome</label> 
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/usuario.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="nome" name="nome" value="<?php echo $nomes[0]; ?>" maxlength="40" class="form-control input-md" required="required" minlength="2" pattern="^[a-zA-Z][a-zA-Z-_\.]{1,20}$">
              
            </div>
          </div>


          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="sobrenome">Sobrenome</label>
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/usuario.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="sobrenome" name="sobrenome" value="<?php echo $nomes[1]; ?>" maxlength="60" class="form-control input-md" required="required" minlength="2" pattern="^[a-zA-Z][a-zA-Z-_\.]{1,20}$">
              
            </div>
          </div>


        </div>

        <div class="row">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="email">E-mail</label> 
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/envelope.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="email" name="email" value="<?php echo $email; ?>" maxlength="254" class="form-control input-md input1" required="required" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" minlength="7">
              
            </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="numTelefone">Número de telefone</label>
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/phone.png"); ?>" class="img1"></img></span>
              </div>
              <input type="tel" id="numTelefone" name="numTelefone" value="<?php echo $telefone_usuario; ?>" maxlength="13" onkeypress="mascara2(this)" class="form-control input-md" required="required" minlength="13">
              
            </div>
            <p class="help-block corfonte2 fonte3">DDD e celular</p>
          </div>
        </div>

        <div class="row">
          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="senha">Nova senha</label> 
              <div class="input-group inputBox2">
                <div class="input-group-prepend">
                  <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/cadeado.png"); ?>" class="img1"></img></span>
                </div>
                <input type="password" id="senha" name="senha" maxlength="12" class="form-control input-md input1" minlength="6">
                
              </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="confirmarSenha">Confirmar a nova senha</label>
              <div class="input-group inputBox2">
                <div class="input-group-prepend">
                  <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/cadeado.png"); ?>" class="img1"></img></span>
                </div>
                <input type="password" id="confirmarSenha" name="confirmarSenha" maxlength="12" minlength="6" class="form-control input-md">
                
              </div>
          </div>
        </div>

        <div class="row">
            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
              <label class="corfonte" for="numRua">Número da casa</label> 
                <div class="input-group inputBox2">
                  <div class="input-group-prepend">
                    <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="numRua" name="numRua" value="<?php echo $numero_rua_usuario; ?>" maxlength="5" class="form-control input-md input1" required="required" minlength="1">
                  
                </div>
            </div>

            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <label class="corfonte" for="cep">CEP</label>
                <div class="input-group inputBox2">
                  <div class="input-group-prepend">
                    <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="cep" name="cep" value="<?php echo $cep_usuario; ?>" maxlength="9" onkeypress="mascara1(this, '#####-###')" minlength="9" onblur="pesquisacep(this.value);" class="form-control input-md" required="required">
                  
                </div>
                <p class="help-block corfonte2 fonte3">Digite o CEP para a busca de endereço</p>
            </div>
          </div>

          <div class="row">
            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
              <label class="corfonte" for="rua">Rua</label> 
                <div class="input-group inputBox2">
                  <div class="input-group-prepend">
                    <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="rua" name="rua" value="<?php echo $nome_rua_usuario; ?>" maxlength="100" readonly="readonly" class="form-control input-md input1" required="required">
                  
                </div>
            </div>

            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <label class="corfonte" for="bairro">Bairro</label>
                <div class="input-group inputBox2">
                  <div class="input-group-prepend">
                    <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="bairro" name="bairro" value="<?php echo $nome_bairro; ?>" maxlength="100" readonly="readonly" class="form-control input-md" required="required">
                  
                </div>
              </div>
          </div>

          <div class="row">
            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
              <label class="corfonte" for="cidade">Cidade</label> 
                <div class="input-group inputBox2">
                  <div class="input-group-prepend">
                    <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="cidade" name="cidade" value="<?php echo $nome_cidade; ?>" maxlength="200" readonly="readonly" class="form-control input-md input1" required="required">
                  
                </div>
            </div>

            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <label class="corfonte" for="estado">Estado</label>
                <div class="input-group inputBox2">
                  <div class="input-group-prepend">
                    <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="uf" name="uf" value="<?php echo $sigla_estado; ?>" maxlength="2" readonly="readonly" class="form-control input-md" required="required">
                  
                </div>
              </div>
          </div>

        <div class="form-group fonte2">
          <div class="divenviar row">
            <input type="submit" id="enviar" name="enviar" class="btn btn-primary corfonte text-center col-6 col-sm-6 col-md-6 col-lg-3 col-xl-3" value="Enviar"></input>
          </div>
        </div>

      </fieldset>
    </form>
  
  </div>    

</body>
</html>