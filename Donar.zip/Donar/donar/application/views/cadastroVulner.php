<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/cadastroVulner.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">

    //Para o menu
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });   
       
    });


    //Para adicionar um novo campo de imagem (teste)
    $(document).ready(function() {
        $('#imgi1').change(function(){
            $('#imgb1').append('<span> A </span>')
        })
    });

    //Para deixar uma imagem visível (teste)
    $(document).ready(function() {
        $('#imgi1').change(function(){
            $('#imgi2').show()
        })
    });


    //Para monstrar a imagens
    function previewImagem1() {
      var imagem = document.querySelector('input[name=imgb1]').files[0];
      var preview = document.querySelector('img[name=imgPreview1]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem2() {
      var imagem = document.querySelector('input[name=imgb2]').files[0];
      var preview = document.querySelector('img[name=imgPreview2]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem3() {
      var imagem = document.querySelector('input[name=imgb3]').files[0];
      var preview = document.querySelector('img[name=imgPreview3]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem4() {
      var imagem = document.querySelector('input[name=imgb4]').files[0];
      var preview = document.querySelector('img[name=imgPreview4]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem5() {
      var imagem = document.querySelector('input[name=imgb5]').files[0];
      var preview = document.querySelector('img[name=imgPreview5]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }


    //Para a máscara do CEP
    function mascara1(t, mask){
      var i = t.value.length;
      var saida = mask.substring(1,0);
      var texto = mask.substring(i)
      if (texto.substring(0,1) != saida){
        t.value += texto.substring(0,1);
      }
    }

    //Para a máscara do número de telefone
    function mascara2(numTelefone){
      if(numTelefone.value.length == 2)
        numTelefone.value = numTelefone.value + ' '; //quando o campo já tiver 3 caracteres (um parênteses e 2 números) o script irá inserir mais um parênteses, fechando assim o código de área.
     
      if(numTelefone.value.length == 8)
        numTelefone.value = numTelefone.value + '-'; //quando o campo já tiver 8 caracteres, o script irá inserir um tracinho, para melhor visualização do telefone.
      
    }

    //Para encontrar o endereço
    function limpa_formulário_cep() {
      //Limpa valores do formulário de cep.
      document.getElementById('rua').value = ("");
      document.getElementById('bairro').value = ("");
      document.getElementById('cidade').value = ("");
      document.getElementById('uf').value = ("");
    }

    function meu_callback(conteudo) {
      if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('rua').value = (conteudo.logradouro);
        document.getElementById('bairro').value = (conteudo.bairro);
        document.getElementById('cidade').value = (conteudo.localidade);
        document.getElementById('uf').value = (conteudo.uf);
      } //end if.
      else {
        //CEP não Encontrado.
        limpa_formulário_cep();
        alert("CEP não encontrado.");
      }
    }

    function pesquisacep(valor) {

      //Nova variável "cep" somente com dígitos.
      var cep = valor.replace(/\D/g, '');

      //Verifica se campo cep possui valor informado.
      if (cep != "") {

        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;

        //Valida o formato do CEP.
        if (validacep.test(cep)) {

          //Preenche os campos com "..." enquanto consulta webservice.
          document.getElementById('rua').value = "...";
          document.getElementById('bairro').value = "...";
          document.getElementById('cidade').value = "...";
          document.getElementById('uf').value = "...";

          //Cria um elemento javascript.
          var script = document.createElement('script');

          //Sincroniza com o callback.
          script.src = 'https://viacep.com.br/ws/' + cep + '/json/?callback=meu_callback';

          //Insere script no documento e carrega o conteúdo.
          document.body.appendChild(script);

        } //end if.
        else {
          //cep é inválido.
          limpa_formulário_cep();
          alert("Formato de CEP inválido.");
        }
      } //end if.
      else {
        //cep sem valor, limpa formulário.
        limpa_formulário_cep();
      }
    };

  </script>

</head>
<body>
  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <?php if($this->session->flashdata('categoria_inexistente')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('categoria_inexistente'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('unidade_inexistente')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('unidade_inexistente'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('quantidade_inexistente')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('quantidade_inexistente'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('avaliador_inexistente')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('avaliador_inexistente'); ?>
    </div>
  <?php } ?>

  <?php if($this->session->flashdata('erro_form')) { ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <?php echo $this->session->flashdata('erro_form'); ?>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php } ?>

  <div class="container-fluid row divprincipal col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"> 
    <form class="box form-horizontal col-12 col-sm-12 col-md-12 col-lg-10 col-xl-10" method="post" action="<?php echo base_url("CadastroVulner/cadastrarVulner"); ?>" enctype="multipart/form-data">
      <fieldset>

        <legend class="fonte1 corfonte text-center">Cadastro de uma situação de vulnerabilidade social</legend>

        <div class="row rowimagens col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <label id="lbl_img1" class="lbl_img1" for="imgb1"><img name="imgPreview1" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi1" class="img4 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb1" name="imgb1" accept="image/png, image/jpeg" onchange="previewImagem1()">

          <label id="lbl_img2" class="lbl_img2" for="imgb2"><img name="imgPreview2" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi2" class="img4 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb2" name="imgb2" accept="image/png, image/jpeg" onchange="previewImagem2()">

          <label id="lbl_img3" class="lbl_img3" for="imgb3"><img name="imgPreview3" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi3" class="img4 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb3" name="imgb3" accept="image/png, image/jpeg" onchange="previewImagem3()">

          <label id="lbl_img3" class="lbl_img4" for="imgb4"><img name="imgPreview4" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi4" class="img4 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb4" name="imgb4" accept="image/png, image/jpeg" onchange="previewImagem4()">

          <label id="lbl_img5" class="lbl_img5" for="imgb5"><img name="imgPreview5" src="<?php echo base_url("/assets/img/addimg.png"); ?>" id="imgi5" class="img4 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/></label>
          <input type="file" id="imgb5" name="imgb5" accept="image/png, image/jpeg" onchange="previewImagem5()">
        </div>

        <div class="row rowdadosgerais">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="numTelefone">Número de telefone para contato</label>
              <div class="input-group inputBox2">
                <div class="input-group-prepend">
                  <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/phone.png"); ?>" class="img1"></img></span>
                </div>
                <input type="text" id="numTelefone" name="numTelefone" maxlength="13" class="form-control input-md" onkeypress="mascara2(this)" required="required" minlength="13">

              </div>
              <p class="help-block corfonte2 fonte3">DDD e celular</p>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="titulo">Título</label> 
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/title.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="titulo" name="titulo" maxlength="40" class="form-control input-md" required="required" minlength="10">
              
            </div>
          </div>

        </div>

        <div class="row">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="descricao">Descrição</label>
            <div class="input-group inputBox2">
              <textarea id="descricao" name="descricao" rows="5" maxlength="200" class="form-control input-md" required="required" minlength="40"></textarea>
              
            </div>
          </div>

        </div>


        <div class="row rowCat1">

          <select name="categoriaLista1" id="categoriaLista1" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade1" name="quantidade1" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista1" id="uniLista1" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
          <div class="espaco">  
          </div>


          <select name="categoriaLista2" id="categoriaLista2" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade2" name="quantidade2" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista2" id="uniLista2" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
        </div>


        <div class="row rowCat2">

          <select name="categoriaLista3" id="categoriaLista3" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade3" name="quantidade3" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista3" id="uniLista3" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
          <div class="espaco">  
          </div>


          <select name="categoriaLista4" id="categoriaLista4" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade4" name="quantidade4" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista4" id="uniLista4" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
        </div>


        <div class="row rowCat3">

          <select name="categoriaLista5" id="categoriaLista5" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade5" name="quantidade5" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista5" id="uniLista5" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
          <div class="espaco">  
          </div>


          <select name="categoriaLista6" id="categoriaLista6" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade6" name="quantidade6" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista6" id="uniLista6" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
        </div>


        <div class="row rowCat4">

          <select name="categoriaLista7" id="categoriaLista7" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade7" name="quantidade7" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista7" id="uniLista7" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
          <div class="espaco">  
          </div>

          <select name="categoriaLista8" id="categoriaLista8" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade8" name="quantidade8" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista8" id="uniLista8" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
        </div>


        <div class="row rowCat5">

          <select name="categoriaLista9" id="categoriaLista9" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade9" name="quantidade9" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista9" id="uniLista9" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="espaco">  
          </div>

          <select name="categoriaLista10" id="categoriaLista10" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Categoria
            </option>
            <?php
              foreach ($cats as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php if ($list->id_categoria_sup != null) { echo $list->id_categoria; } else { echo ''; } ?>" <?php if ($list->id_categoria_sup == null) { echo "disabled"; }?>>
                    <?php echo $list->nome_categoria; ?>
                  </option> 
          <?php }
              }
            ?>
          </select>

          <div class="inputBox2 col-3 col-sm-3 col-md-3 col-lg-1 col-xl-1">
           <input type="text" id="quantidade10" name="quantidade10" maxlength="5" class="form-control inputBox2 input-md">
          </div>

          <select name="uniLista10" id="uniLista10" class="categoriaLista col-4 col-sm-4 col-md-4 col-lg-2 col-xl-2">
            <option selected disabled hidden value="">
              Unidade
            </option>
            <?php
              foreach ($unis as $li => $l) {
                foreach ($l as $lis => $list) { ?>
                  <option value="<?php echo $list->id_unidade; ?>">
                    <?php echo $list->nome_unidade; ?>
                  </option> 
          <?php }
              }
            ?>
          </select> 
          
          
        </div>


        <div class="row rowEndereco">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="numRua">Número da casa</label>
              <div class="input-group inputBox2">
                <div class="input-group-prepend">
                  <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                </div>
                <input type="text" id="numRua" name="numRua" maxlength="5" class="form-control input-md" required="required" minlength="1">
                
              </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="cep">CEP</label> 
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="cep" name="cep" maxlength="9" onkeypress="mascara1(this, '#####-###')" minlength="9" onblur="pesquisacep(this.value);" class="form-control input-md" required="required">
              
            </div>
            <p class="help-block corfonte2 fonte3">Digite o CEP para a busca de endereço</p>
          </div>

        </div>

        <div class="row">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="rua">Rua</label>
              <div class="input-group inputBox2">
                <div class="input-group-prepend">
                  <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                </div>
                <input type="text" id="rua" name="rua" maxlength="100" readonly="readonly" class="form-control input-md" required="required">
                
              </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="bairro">Bairro</label> 
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="bairro" name="bairro" maxlength="9" readonly="readonly" class="form-control input-md" required="required">
              
            </div>
          </div>

        </div>

        <div class="row">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="cidade">Cidade</label>
              <div class="input-group inputBox2">
                <div class="input-group-prepend">
                  <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                </div>
                <input type="text" id="cidade" name="cidade" maxlength="200" readonly="readonly" class="form-control input-md" required="required">
                
              </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="uf">Estado</label> 
            <div class="input-group inputBox2">
              <div class="input-group-prepend">
                <span class="input-group-text2"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="uf" name="uf" maxlength="2" readonly="readonly" class="form-control input-md" required="required">
              
            </div>
          </div>

        </div>

        <div class="form-group fonte2">
          <div class="rowbotao col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <input type="submit" id="enviar" name="enviar" class="btn btn-primary corfonte text-center col-6 col-sm-6 col-md-6 col-lg-3 col-xl-3 botao20" value="Enviar"></input>
          </div>
        </div>
      </fieldset>
    </form>
  </div>
    

</body>
</html>