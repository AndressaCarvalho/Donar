<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/cadastroUsuario.css"); ?>">
  
  <script type="text/javascript">
    
    //Para a máscara do CEP
    function mascara1(t, mask){
      var i = t.value.length;
      var saida = mask.substring(1,0);
      var texto = mask.substring(i)
      if (texto.substring(0,1) != saida){
        t.value += texto.substring(0,1);
      }
    }

    //Para a máscara do número de telefone
    function mascara2(numTelefone){
      if(numTelefone.value.length == 2)
        numTelefone.value = numTelefone.value + ' '; //quando o campo já tiver 3 caracteres (um parênteses e 2 números) o script irá inserir mais um parênteses, fechando assim o código de área.
     
      if(numTelefone.value.length == 8)
        numTelefone.value = numTelefone.value + '-'; //quando o campo já tiver 8 caracteres, o script irá inserir um tracinho, para melhor visualização do telefone.
      
    }

    //Para encontrar o endereço
    function limpa_formulário_cep() {
      //Limpa valores do formulário de cep.
      document.getElementById('rua').value = ("");
      document.getElementById('bairro').value = ("");
      document.getElementById('cidade').value = ("");
      document.getElementById('uf').value = ("");
    }

    function meu_callback(conteudo) {
      if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('rua').value = (conteudo.logradouro);
        document.getElementById('bairro').value = (conteudo.bairro);
        document.getElementById('cidade').value = (conteudo.localidade);
        document.getElementById('uf').value = (conteudo.uf);
      } //end if.
      else {
        //CEP não Encontrado.
        limpa_formulário_cep();
        alert("CEP não encontrado.");
      }
    }

    function pesquisacep(valor) {

      //Nova variável "cep" somente com dígitos.
      var cep = valor.replace(/\D/g, '');

      //Verifica se campo cep possui valor informado.
      if (cep != "") {

        //Expressão regular para validar o CEP.
        var validacep = /^[0-9]{8}$/;

        //Valida o formato do CEP.
        if (validacep.test(cep)) {

          //Preenche os campos com "..." enquanto consulta webservice.
          document.getElementById('rua').value = "...";
          document.getElementById('bairro').value = "...";
          document.getElementById('cidade').value = "...";
          document.getElementById('uf').value = "...";

          //Cria um elemento javascript.
          var script = document.createElement('script');

          //Sincroniza com o callback.
          script.src = 'https://viacep.com.br/ws/' + cep + '/json/?callback=meu_callback';

          //Insere script no documento e carrega o conteúdo.
          document.body.appendChild(script);

        } //end if.
        else {
          //cep é inválido.
          limpa_formulário_cep();
          alert("Formato de CEP inválido.");
        }
      } //end if.
      else {
        //cep sem valor, limpa formulário.
        limpa_formulário_cep();
      }
    };
  </script>

</head>
<body>

  <div class="container-fluid row">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php if($this->session->flashdata('usuario_existente')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('usuario_existente'); ?>
    </div>
  <?php } ?>


  <?php echo validation_errors('<div class="alert alert-warning alert-dismissible fade show" role="alert">',
    '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    </div>'
  ); ?>
  
  <div class="container-fluid row divprincipal">

    <img src="<?php echo base_url("/assets/img/voluntario.png"); ?>" class="img2 col-xl-2 d-none d-xl-block"></img>

    <form class="box form-horizontal col-12 col-sm-10 col-md-8 col-lg-8 col-xl-8" method="post" action="<?php echo base_url("/CadastroUsuario/cadastrarUsuario"); ?>" enctype="multipart/form-data">
      <fieldset>

        <legend class="fonte1 corfonte text-center">Cadastro</legend>
        
        <div class="row">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="nome">Nome</label> 
            <div class="input-group inputBox">
              <div class="input-group-prepend">
                <span class="input-group-text"><img src="<?php echo base_url("/assets/img/usuario.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="nome" name="nome" maxlength="40" class="form-control input-md" required="required" minlength="2" pattern="^[a-zA-Z][a-zA-Z-_\.]{1,20}$" value="<?php echo set_value('nome'); ?>">
              
            </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="sobrenome">Sobrenome</label>
            <div class="input-group inputBox">
              <div class="input-group-prepend">
                <span class="input-group-text"><img src="<?php echo base_url("/assets/img/usuario.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="sobrenome" name="sobrenome" maxlength="60" class="form-control input-md" required="required" minlength="2" pattern="^[a-zA-Z][a-zA-Z-_\.]{1,20}$" value="<?php echo set_value('sobrenome'); ?>">
              
            </div>
          </div>

        </div>

        <div class="row">

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="email">E-mail</label> 
            <div class="input-group inputBox">
              <div class="input-group-prepend">
                <span class="input-group-text"><img src="<?php echo base_url("/assets/img/envelope.png"); ?>" class="img1"></img></span>
              </div>
              <input type="text" id="email" name="email" maxlength="254" class="form-control input-md input1" required="required" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" minlength="7" value="<?php echo set_value('email'); ?>">
              
            </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="numTelefone">Número de telefone</label>
            <div class="input-group inputBox">
              <div class="input-group-prepend">
                <span class="input-group-text"><img src="<?php echo base_url("/assets/img/phone.png"); ?>" class="img1"></img></span>
              </div>
              <input type="tel" id="numTelefone" name="numTelefone" maxlength="13" onkeypress="mascara2(this)" class="form-control input-md" required="required" minlength="13" value="<?php echo set_value('numTelefone'); ?>">
              
            </div>
            <p class="help-block corfonte2 fonte3">DDD e celular</p>
          </div>
        </div>

        <div class="row">
          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="senha">Senha</label> 
              <div class="input-group inputBox">
                <div class="input-group-prepend">
                  <span class="input-group-text"><img src="<?php echo base_url("/assets/img/cadeado.png"); ?>" class="img1"></img></span>
                </div>
                <input type="password" id="senha" name="senha" maxlength="12" class="form-control input-md input1" required="required" minlength="6" value="<?php echo set_value('senha'); ?>">
                
              </div>
          </div>

          <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <label class="corfonte" for="confirmarSenha">Confirmar a senha</label>
              <div class="input-group inputBox">
                <div class="input-group-prepend">
                  <span class="input-group-text"><img src="<?php echo base_url("/assets/img/cadeado.png"); ?>" class="img1"></img></span>
                </div>
                <input type="password" id="confirmarSenha" name="confirmarSenha" maxlength="12" class="form-control input-md" required="required" minlength="6" value="<?php echo set_value('confirmarSenha'); ?>">
                
              </div>
          </div>
        </div>

        <div class="row">
            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
              <label class="corfonte" for="numRua">Número da casa</label> 
                <div class="input-group inputBox">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="numRua" name="numRua" maxlength="5" class="form-control input-md input1" required="required" minlength="1" value="<?php echo set_value('numRua'); ?>">
                  
                </div>
            </div>

            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <label class="corfonte" for="cep">CEP</label>
                <div class="input-group inputBox">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="cep" name="cep" maxlength="9" onkeypress="mascara1(this, '#####-###')" minlength="9" onblur="pesquisacep(this.value);" class="form-control input-md" required="required" value="<?php echo set_value('cep'); ?>">
                  
                </div>
                <p class="help-block corfonte2 fonte3">Digite o CEP para a busca de endereço</p>
            </div>
          </div>

          <div class="row">
            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
              <label class="corfonte" for="rua">Rua</label> 
                <div class="input-group inputBox">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="rua" name="rua" maxlength="100" readonly="readonly" class="form-control input-md input1" required="required" value="<?php echo set_value('rua'); ?>">
                  
                </div>
            </div>

            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <label class="corfonte" for="bairro">Bairro</label>
                <div class="input-group inputBox">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="bairro" name="bairro" maxlength="100" readonly="readonly" class="form-control input-md" required="required" value="<?php echo set_value('bairro'); ?>">
                  
                </div>
              </div>
          </div>

          <div class="row">
            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
              <label class="corfonte" for="cidade">Cidade</label> 
                <div class="input-group inputBox">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="cidade" name="cidade" maxlength="200" readonly="readonly" class="form-control input-md input1" required="required" value="<?php echo set_value('cidade'); ?>">
                  
                </div>
            </div>

            <div class="form-group fonte2 col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <label class="corfonte" for="estado">Estado</label>
                <div class="input-group inputBox">
                  <div class="input-group-prepend">
                    <span class="input-group-text"><img src="<?php echo base_url("/assets/img/localizacao.png"); ?>" class="img1"></img></span>
                  </div>
                  <input type="text" id="uf" name="uf" maxlength="2" readonly="readonly" class="form-control input-md" required="required" value="<?php echo set_value('uf'); ?>">
                  
                </div>
              </div>
          </div>

        <div class="form-group fonte2">
          <div>
            <input type="submit" id="enviar" name="enviar" class="btn btn-primary corfonte text-center col-10 col-sm-10 col-md-8 col-lg-2 col-xl-2 botao" value="Enviar"></input>
          </div>
        </div>
      </fieldset>
    </form>
  
  </div>

</body>
</html>
