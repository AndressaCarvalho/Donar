<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/redefinicaoSenha.css"); ?>">

  </head>

<body>
  <div class="container-fluid row">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
   if($this->session->flashdata('usuario_inexistente')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('usuario_inexistente'); ?>
    </div>
  <?php } ?>

  <?php echo validation_errors('<div class="alert alert-warning alert-dismissible fade show" role="alert">',
    '<button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    </div>'
  ); ?>

  <div class="container-fluid row divprincipal">
    <form class="box form-horizontal col-12 col-sm-10 col-md-8 col-lg-6 col-xl-4" action="<?php echo base_url("/RedefinicaoSenha/enviarEmail"); ?>" method="post">
      <fieldset>

        <legend class="fonte1 corfonte text-center">E-mail para redefinir a senha</legend>

        <div class="form-group fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <label class="corfonte" for="email">E-mail</label> 
          <div class="input-group col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 inputBox">
            <div class="input-group-prepend">
              <span class="input-group-text"><img src="<?php echo base_url("/assets/img/envelope.png"); ?>" class="img1"></img></span>
            </div>
            <input type="text" id="email" name="email" onblur="validaEmail();" maxlength="254" class="form-control input-md" required="required" value="<?php echo set_value('email'); ?>">
            
          </div>
        </div>


        <div class="form-group fonte2">
          <div>
            <input type="submit" id="enviar" name="enviar" class="btn btn-primary corfonte text-center col-4 col-sm-4 col-md-3 col-lg-3 col-xl-3 botao" value="Enviar"></input>
          </div>
        </div>
      </fieldset>
    </form>

    <img src="<?php echo base_url("/assets/img/imagemFundo.png"); ?>" class="img2 col-xl-8 d-none d-xl-block"></img>

  </div>

</body>
</html>