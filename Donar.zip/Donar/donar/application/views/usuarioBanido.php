<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url('/assets/img/logo.png'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/usuarioBanido.css'); ?>">
  </head>
<body>
	
	<div class="container-fluid row divprincipal fonte1">
		<div class="box1 col-1 col-sm-1 col-md-1 col-lg-3 col-xl-3">
			
		</div>
		
		<div class="box2 col-10 col-sm-10 col-md-10 col-lg-6 col-xl-6">
			<div class="box6 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
				<img name="img" src="<?php echo base_url('/assets/img/alert.png'); ?>" class="img1 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"/>
			</div>

			<div class="box4 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 fonte2 corfonte1 text-center">
				<?php
					foreach ($motivo as $li1 => $l1) {
                    	foreach ($l1 as $lis1 => $list1) {
                    		echo 'Usuário banido por motivo de: '.$list1->motivo_banido;
                    	}
                    }
				?>
			</div>

			<div class="box7 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 fonte2 corfonte1 text-center">
				<?php
                    foreach ($detalhamento as $li2 => $l2) {
                    	foreach ($l2 as $lis2 => $list2) {
                    		echo 'Detalhamento do banimento: '.$list2->detalhamento_banido;
                    	}
                    }
				?>
			</div>

			<div class="box5 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 corfonte1">
				<form method="post" class="form-horizontal col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" action="<?php echo base_url('/Login'); ?>">
					<div class="form-group fonte">
					  <div>
					    <input type="submit" id="voltar" name="voltar" class="btn btn-primary corfonte2 text-center col-4 col-sm-4 col-md-3 col-lg-2 col-xl-2 botao" value="Voltar"></input>
					  </div>
					</div>
				</form>
			</div>
		</div>

		<div class="box3 col-1 col-sm-1 col-md-1 col-lg-3 col-xl-3">
			
		</div>

	</div>

</body>
</html>