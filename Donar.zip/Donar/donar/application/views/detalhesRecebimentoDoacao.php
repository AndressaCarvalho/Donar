<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/detalhesRecebimentoDoacao.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });
  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <div class="container-fluid row divprincipal corfonte col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="box col-10 col-sm-10 col-md-10 col-lg-10 col-xl-10">
     
      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        
        <?php
        foreach ($doacao as $li5 => $l5) {
          foreach ($l5 as $lis5 => $list5) {
            
            if ($list5->data_doacao) {
              $dia = substr($list5->data_doacao, -2);
              $mes = substr($list5->data_doacao, 5, 2);
              $ano = substr($list5->data_doacao, 0, 4);
              $horario = substr($list5->horario_doacao, 0, 5); ?>

              <p class="datahora"><?php echo $dia.'-'.$mes.'-'.$ano.' às '.$horario; ?></p>
            
            <?php
            }

          }
        } ?>

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p class="fonte1 titulovulner">Situação de vulnerabilidade social</p>
      </div>

      <div class="row divs rowimg col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <?php

        $aux1 = false;
        foreach ($imagensv as $li6 => $l6) {
          foreach ($l6 as $lis6 => $list6) {
           
            if ($list6->nome_img_vulner) {
              $aux1 = true;
              ?>
              
              <img src="<?php echo base_url("/upload_img/$list6->nome_img_vulner"); ?>" class="imglist col-7 col-sm-7 col-md-5 col-lg-2 col-xl-2"></img>
            
            <?php
            }

          }
        }

        
        if ($aux1 == false) { ?>
          
          <p class="semimg fonte2">Nenhuma imagem disponível...</p>        
        
        <?php
        }

        ?>

      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <?php
        foreach ($vulner as $li7 => $l7) {
          foreach ($l7 as $lis7 => $list7) {
            
            if ($list7->titulo_vulner) { ?>
              <p><?php echo 'Título: '.$list7->titulo_vulner; ?></p>
            <?php
            } ?>
      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <?php
            if ($list7->descricao_vulner) { ?>
              <p><?php echo 'Descrição: '.$list7->descricao_vulner; ?></p>
            <?php
            }

          ?>
      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p><?php echo 'Localização: '.$list7->nome_rua_vulner.', '.$list7->numero_rua_vulner.' - ';

          }
        }

        foreach ($bairro as $li9 => $l9) {
          foreach ($l9 as $lis9 => $list9) {

            echo 'Localização: '.$list9->nome_bairro.', ';

          }
        }

        foreach ($cidade as $li8 => $l8) {
          foreach ($l8 as $lis8 => $list8) {
            
            echo $list8->nome_cidade.' - '.$list8->sigla_estado.', '; ?>
          
          <?php
          }
        }

      foreach ($vulner as $li5 => $l5) {
          foreach ($l5 as $li5 => $list5) {
            echo $list5->cep_vulner; ?>
              
              </p>
            </div>

          <?php
          }
        }

        ?>


      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p>Categorias:

          <?php
          foreach ($itensv as $li => $l) {
            foreach ($l as $lis => $list) {

              foreach ($categoriasv as $li2 => $l2) {
                foreach ($l2 as $li2 => $list2) {
                  if ($list->id_categoria == $list2->id_categoria) {
                    echo ' '.$list2->nome_categoria.' ';

                    echo '('.$list->quantidade_vulner;

                    foreach ($unidadesv as $li4 => $l4) {
                      foreach ($l4 as $li4 => $list4) {
                        if ($list->id_unidade == $list4->id_unidade) {
                          echo ' '.$list4->nome_unidade.');';
                          break;
                        }
                        
                      }
                    }

                    break;
                    
                  }
                  
                }
              }

            }
          }
          ?>

        </p>   

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>

      <div class="row divs rowimg col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p class="fonte1 titulodoacao">Doação</p>
      </div>

      <div class="row divs rowimg col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <?php

        $aux2 = false;
        foreach ($imagensd as $li11 => $l11) {
          foreach ($l11 as $lis11 => $list11) {
           
            if ($list11->nome_img_doacao) {
              $aux2 = true;
              ?>
              
              <img src="<?php echo base_url("/upload_img/$list11->nome_img_doacao"); ?>" class="imglist col-7 col-sm-7 col-md-5 col-lg-2 col-xl-2"></img>
            
            <?php
            }

          }
        }

        if ($aux2 == false) { ?>
          
          <p class="semimg fonte2">Nenhuma imagem disponível...</p>        
        
        <?php
        }

        ?>

      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php
        foreach ($bairro2 as $li9 => $l9) {
          foreach ($l9 as $lis9 => $list9) { ?>

            <p><?php echo 'Localização: '.$list9->nome_bairro.', ';

          }
        }

        foreach ($cidade2 as $li8 => $l8) {
          foreach ($l8 as $lis8 => $list8) {
            
            echo $list8->nome_cidade.' - '.$list8->sigla_estado; ?></p>
          
          <?php
          }
        } ?>

      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p>Categorias:

          <?php
          foreach ($itensd as $li12 => $l12) {
            foreach ($l12 as $lis12 => $list12) {

              foreach ($categoriasd as $li13 => $l13) {
                foreach ($l13 as $li13 => $list13) {
                  if ($list12->id_categoria == $list13->id_categoria) {
                    echo ' '.$list13->nome_categoria.' ';

                    echo '('.$list12->quantidade_doacao;

                    foreach ($unidadesd as $li14 => $l14) {
                      foreach ($l14 as $li14 => $list14) {
                        if ($list12->id_unidade == $list14->id_unidade) {
                          echo ' '.$list14->nome_unidade.');';
                          break;
                        }
                        
                      }
                    }

                    break;
                    
                  }
                  
                }
              }

            }
          }
          ?>

        </p>    

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>

      <div class="row divs divbotao col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <?php
        foreach ($vulner as $li10 => $l10) {
          foreach ($l10 as $lis10 => $list10) {

            if ($list10->id_vulner) { ?>

              <form method="post" action="<?php echo base_url("/ListagemRecebimentoDoacao/aceitarRecusarDoacao"); ?>" class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <input type="hidden" id="vulner" name="vulner" value="<?php echo $list10->id_vulner; ?>" readonly="readonly">
            
            <?php
            }

          }
        }

        foreach ($doacao as $li15 => $l15) {
          foreach ($l15 as $lis15 => $list15) {

            if ($list15->id_doacao) {
              if (!$condoacao1 && !$condoacao2) { ?>

                <input type="hidden" id="doacao" name="doacao" value="<?php echo $list15->id_doacao; ?>" readonly="readonly">
                <div class="divadoacao col-10 col-sm-10 col-md-10 col-lg-2 col-xl-2">
                  <input type="submit" id="adoacao" name="adoacao" value="Aceitar doação" class="btn btn-primary botao1 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"></input>
                </div>
                <div class="divrdoacao col-10 col-sm-10 col-md-10 col-lg-2 col-xl-2">
                  <input type="submit" id="rdoacao" name="rdoacao" value="Recusar doação" class="btn btn-primary botao20 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"></input>
                </div>
              
              <?php
              } ?>

              </form>

            <?php
            }

          }
        }

        ?>

      </div>

    </div>
  </div>
    

</body>
</html>