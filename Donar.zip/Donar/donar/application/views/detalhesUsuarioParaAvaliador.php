<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/detalhesUsuarioParaAvaliador.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });

  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>


  <div class="container-fluid row divprincipal corfonte fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="box col-10 col-sm-10 col-md-10 col-lg-7 col-xl-7">

      <form method="post" class="form-horizontal" action="<?php echo base_url('/ListagemUsuarioParaAvaliador/aceitarRecusarAvaliador'); ?>">

      <?php
      foreach ($infusuario as $li => $l) {
        foreach ($l as $li => $list) { ?>

          <?php
            foreach ($infava as $li5 => $l5) {
              foreach ($l5 as $lis5 => $list5) {
                
                if ($list5->data_avaliador) {
                  $dia = substr($list5->data_avaliador, -2);
                  $mes = substr($list5->data_avaliador, 5, 2);
                  $ano = substr($list5->data_avaliador, 0, 4);
                  $horario = substr($list5->horario_avaliador, 0, 5); ?>

                  <span class="datahora"><?php echo $dia.'-'.$mes.'-'.$ano.' às '.$horario; ?></span>

                  <input type="hidden" id="data" name="data" value="<?php echo $list5->data_avaliador; ?>" readonly="readonly">
                  <input type="hidden" id="horario" name="horario" value="<?php echo $list5->horario_avaliador; ?>" readonly="readonly">
                
                <?php
                }

              }
            }
        }
      } ?>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p class="fonte1 titulousuario">Dados do usuário</p>
      </div>

      <?php
        foreach ($infusuario as $li => $l) {
          foreach ($l as $li => $list) { ?>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <img src="<?php echo base_url("/upload_img/$list->nome_img_perfil"); ?>" class="img4 col-7 col-sm-7 col-md-6 col-lg-3 col-xl-3"/>
            </div>

            <input type="hidden" id="usuario" name="usuario" value="<?php echo $list->id_usuario; ?>" readonly="readonly">

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Nome: '.$list->nome_usuario; ?></p>
            </div>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Email: '.$list->email; ?></p>
            </div>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Número de telefone para contato: '.$list->telefone_usuario; ?></p>
            </div>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Localização: '.$list->nome_rua_usuario.', '.$list->numero_rua_usuario.' - ';

          }
        }

        foreach ($bairro as $li2 => $l2) {
          foreach ($l2 as $li2 => $list2) {
            echo $list2->nome_bairro.', '; ?>

          <?php
          }
        }

        foreach ($cidade as $li3 => $l3) {
          foreach ($l3 as $li3 => $list3) {
            echo $list3->nome_cidade.' - '.$list3->sigla_estado.', '; ?>

          <?php
          }
        }

        foreach ($infusuario as $li5 => $l5) {
          foreach ($l5 as $li5 => $list5) {
            echo $list5->cep_usuario; ?>
              
              </p>
            </div>

          <?php
          }
        }

        foreach ($infava as $li6 => $l6) {
          foreach ($l6 as $lis6 => $list6) {
            
            if ($list6->nome_img_identidade) { ?>

              <div class="row divs divimgs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <img src="<?php echo base_url("/upload_img/$list6->nome_img_identidade"); ?>" class="imgus1 col-11 col-sm-11 col-md-8 col-lg-5 col-xl-5"/>
                <img src="<?php echo base_url("/upload_img/$list6->nome_img_cresidencia"); ?>" class="imgus2 col-11 col-sm-11 col-md-8 col-lg-5 col-xl-5"/>
              </div>
            
            <?php
            }

          }
        } ?>


      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>

      <div class="row divs divbotao col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="divaceitar col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
          <input type="submit" id="aceitar" name="aceitar" value="Aceitar como avaliador" class="btn btn-primary botao1 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"></input>
        </div>
        <div class="divrecusar col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
          <input type="submit" id="recusar" name="recusar" value="Recusar como avaliador" class="btn btn-primary botao20 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"></input>
        </div>

      </div>

      </form>
      
    </div>
  </div>
    

</body>
</html>