<div class="page-wrapper chiller-theme toggled">
    <a id="show-sidebar" class="btn btn-primary botao" href="#">
      <i class="fas fa-bars"></i>
    </a>
    <nav id="sidebar" class="sidebar-wrapper">
      <div class="sidebar-content">
        <div class="sidebar-brand">
          <span>Menu</span>
          <div id="close-sidebar">
            <i class="fas fa-times"></i>
          </div>
        </div>
        <div class="sidebar-header">
          <div class="user-pic">
            <a href="<?php echo base_url("/ListagemPerfilUsuario"); ?>">
              <img src="<?php if($this->session->userdata('perfil_usuario')) {
                  echo $this->session->userdata('perfil_usuario');
                } ?>" class="img3"></img>
            </a>
          </div>
          <div class="user-info">
            <span class="user-name">
              <?php
                if($this->session->userdata('nome_usuario')) {
                  echo $this->session->userdata('nome_usuario');
                } ?>

            </span>
              <div class="user-status">
                <span>Avaliador</span>
              </div>
          </div>
        </div>
        
        <div class="sidebar-menu">
          <ul>
            <li class="header-menu">
              <a href="<?php echo base_url("/ListagemVulner"); ?>">
                <img name="img2" src="<?php echo base_url("/assets/img/page.png"); ?>" class="img2 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/>
                Página inicial
              </a>
            </li>

            <li class="sidebar-dropdown">
              <a href="#">
                <img name="img2" src="<?php echo base_url("/assets/img/cadastrar.png"); ?>" class="img2 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/>
                <span>Cadastrar</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="<?php echo base_url("/CadastroVulner"); ?>">Situação de vulnerabilidade social
                    </a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="sidebar-dropdown">
              <a href="#">
                <img name="img2" src="<?php echo base_url("/assets/img/listar.png"); ?>" class="img2 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/>
                <span>Listar</span>
              </a>
              <div class="sidebar-submenu">
                <ul>
                  <li>
                    <a href="<?php echo base_url("/ListagemVulnerCadastrada"); ?>">
                      Situações de vulnerabilidade social cadastradas
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url("/ListagemDoacaoCadastrada"); ?>">
                      Doações cadastradas
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url("/ListagemRecebimentoDoacao"); ?>">
                      Doações a serem recebidas
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url("/ListagemVulnerParaAvaliacao"); ?>">
                      Situações de vulnerabilidade social pendentes de avaliação
                    </a>
                  </li>
                </ul>
              </div>
            </li>

            <li class="header-menu">
              <a href="<?php echo base_url("/Donar/logout"); ?>">
                <img name="img2" src="<?php echo base_url("/assets/img/sair.png"); ?>" class="img2 col-8 col-sm-8 col-md-10 col-lg-12 col-xl-12"/>
                Sair
              </a>
            </li>
          </ul>
        </div>

      </div>
   
    </nav>
  </div>