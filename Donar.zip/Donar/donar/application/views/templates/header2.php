<div class="row divform2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
  <form class="form-horizontal form1 col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6" method="post" action="<?php echo base_url("/ListagemVulner/buscaPersonalizadaTitulo"); ?>">
    <div class="input-group inputBox col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <input type="text" id="procurarTexto" name="procurarTexto" maxlength="40" class="form-control input-md" placeholder="Digite o título">
        <div class="input-group-prepend divprocurar">
          <input type="image" name="procurar" class="procurar" src="<?php echo base_url("/assets/img/search.png"); ?>">
          </input>
        </div>
    </div>
  </form>

  <form class="form-horizontal form2 col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6" method="post" action="<?php echo base_url("/ListagemVulner/buscaPersonalizadaCategoria"); ?>">
    <select name="categorias" class="categorias col-10 col-sm-12 col-md-12 col-lg-5 col-xl-5">
      <option selected disabled hidden>
        Categorias
      </option>
      <?php
          foreach ($cats3 as $li => $l) {
            foreach ($l as $lis => $list) { ?>
              <option value="<?php echo $list->id_categoria; ?>">
                <?php echo $list->nome_categoria; ?>
              </option>
      <?php }
          }
        ?>
    </select>
    <select name="subcategorias" class="subcategorias col-10 col-sm-12 col-md-12 col-lg-5 col-xl-5">
      <option selected disabled hidden>
        Subcategorias
      </option>
      <?php
          foreach ($cats2 as $li => $l) {
            foreach ($l as $lis => $list) { ?>
              <option value="<?php if ($list->id_categoria_sup != NULL) { echo $list->id_categoria; } else { echo NULL; } ?>" <?php if ($list->id_categoria_sup == NULL) { echo "disabled"; } ?>>
                <?php if ($list->id_categoria_sup != NULL) { echo $list->nome_categoria; } ?>
              </option> 
      <?php }
          }
        ?>
    </select>
    <input type="submit" id="ir" name="ir" class="btn btn-primary corfonte fonte2 text-center col-4 col-sm-4 col-md-4 col-lg-1 col-xl-1 botao2" value="Ir"></input>
  </form>
</div>