<div class="row divd col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
  <div class="col-4 col-sm-2 col-md-2 col-lg-1 col-xl-2">
    <img src="<?php echo base_url("/assets/img/logo.png"); ?>" class="imglogod"></img>
  </div>
  <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5 divformd">
    <form class="form-horizontal formd" method="post" action="<?php echo base_url("Donar/carregar"); ?>">

      <button type="button" id="sobre" name="sobre" class="btn btn-primary corfonte fonte2 text-center col-8 col-sm-8 col-md-8 col-lg-4 col-xl-3 botaod1" data-toggle="modal" data-target="#exampleModalScrollable">
        Sobre
      </button>

      <!-- Modal -->
      <div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true" class="fonte2">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalScrollableTitle">Sobre</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>“Donar” é a aplicação Web sem fins lucrativos, que conecta cidadãos que estão em condição de vulnerabilidade social, e usuários que disponibilizam ajuda. Desta forma, o sistema possibilita que uma situação de necessidade sofrida por uma pessoa seja explanada, com o objetivo de facilitar o oferecimento de materiais e/ou serviços.</p>
              <p>Há a contribuição de avaliadores, voluntários selecionados que serão responsáveis pela verificação prévia e presencial do estado comunicado, a fim confirmar a veracidade deste. Assim que o avaliador der o seu parecer acerca da situação (que informa itens que contemplam a necessidade de cada pessoa), doações poderão ser realizadas.</p> <br>

              <p>É possível tornar-se um avaliador fornecendo as devidas informações aos administradores, que entraram em contato para uma análise presencial.</p> <br><br><br>

              <small>Um usuário está sujeito à banimento caso cadastre publicações inverídicas ou de cunho impróprio. Este termo estende-se à avaliadores que não exercerem corretamente a sua função.</small>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary fechar" data-dismiss="modal">Fechar</button>
            </div>
          </div>
        </div>
      </div>

      <input type="submit" id="cadastro" name="cadastro" class="btn btn-primary corfonte fonte2 text-center col-8 col-sm-8 col-md-8 col-lg-4 col-xl-3 botaod2" value="Cadastre-se"></input>

      <input type="submit" id="entrar" name="entrar" class="btn btn-primary corfonte fonte2 text-center col-8 col-sm-8 col-md-8 col-lg-4 col-xl-3 botaod3" value="Entrar"></input>
    
    </form>
  </div>
</div>