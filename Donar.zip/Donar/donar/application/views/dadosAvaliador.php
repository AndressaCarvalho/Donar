<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/dadosAvaliador.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });


    //Para monstrar a imagens
    function previewImagem1() {
      var imagem = document.querySelector('input[name=imgb1]').files[0];
      var preview = document.querySelector('img[name=imgPreview1]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem2() {
      var imagem = document.querySelector('input[name=imgb2]').files[0];
      var preview = document.querySelector('img[name=imgPreview2]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem3() {
      var imagem = document.querySelector('input[name=imgb3]').files[0];
      var preview = document.querySelector('img[name=imgPreview3]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem4() {
      var imagem = document.querySelector('input[name=imgb4]').files[0];
      var preview = document.querySelector('img[name=imgPreview4]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

    function previewImagem5() {
      var imagem = document.querySelector('input[name=imgb5]').files[0];
      var preview = document.querySelector('img[name=imgPreview5]');
            
      var reader = new FileReader();
            
      reader.onloadend = function () {
        preview.src = reader.result;
      }
            
      if(imagem){
        reader.readAsDataURL(imagem);
      }
    }

  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <?php if($this->session->flashdata('vulner_cadastrada')) { ?>
    <div class="alert alert-warning" role="alert">
      <?php echo $this->session->flashdata('vulner_cadastrada'); ?>
    </div>
  <?php } ?>

  <div class="container-fluid row divprincipal corfonte fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="box col-10 col-sm-10 col-md-10 col-lg-7 col-xl-7">

      <div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <span class="row titulo1 divst fonte1 corfonte text-center">Dados do avaliador</span>
      </div>

      <?php
        foreach ($infusuario as $li => $l) {
          foreach ($l as $li => $list) { ?>

            <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <img src="<?php echo base_url("/upload_img/$list->nome_img_perfil"); ?>" class="img4 col-7 col-sm-7 col-md-6 col-lg-3 col-xl-3"/>
            </div>

            <div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Nome: '.$list->nome_usuario; ?></p>
            </div>

            <div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Email: '.$list->email; ?></p>
            </div>

            <div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Número de telefone para contato: '.$list->telefone_usuario; ?></p>
            </div>

            <div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <p><?php echo 'Localização: ';

          }
        }

        foreach ($bairro as $li2 => $l2) {
          foreach ($l2 as $li2 => $list2) {
            echo $list2->nome_bairro.', ';
          }
        }

        foreach ($cidade as $li3 => $list3) {
          echo $list3->nome_cidade.' - '.$list3->sigla_estado;
        }

      ?>


      <form method="post" class="form-horizontal col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" action="<?php echo base_url('/CadastroVulner'); ?>">
        <div class="divvoltar divs">
          <input type="submit" id="voltar" name="voltar" class="btn btn-primary corfonte2 text-center col-6 col-sm-6 col-md-5 col-lg-2 col-xl-2 botao20" value="Voltar"></input>
        </div>
      </form>
      
    </div>
  </div>
    

</body>
</html>