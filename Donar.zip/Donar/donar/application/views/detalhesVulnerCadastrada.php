<!doctype html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Donar</title>
  <link rel="icon" type="image/x-icon" href="<?php echo base_url("/assets/img/logo.png"); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link href="<?php echo base_url("/assets/fontawesome-5.11.2/css/all.css"); ?>" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url("/assets/bootstrap-4.3.1/css/bootstrap.min.css"); ?>">
  <script src="<?php echo base_url("/assets/jquery/jquery-3.3.1.slim.min.js"); ?>"></script>
  <script type="text/javascript" charset="utf8" src="<?php echo base_url("/assets/DataTables/jQuery-3.3.1/jquery-3.3.1.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/ajax/popper.min.js"); ?>"></script>
  <script src="<?php echo base_url("/assets/bootstrap-4.3.1/js/bootstrap.min.js"); ?>"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/detalhesVulnerCadastrada.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/header.css"); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url("/assets/css/menu.css"); ?>">

  <script type="text/javascript">
    jQuery(function ($) {

      $(".sidebar-dropdown > a").click(function() {
      $(".sidebar-submenu").slideUp(200);
      if (
        $(this)
          .parent()
          .hasClass("active")
      ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .parent()
          .removeClass("active");
      } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
          .next(".sidebar-submenu")
          .slideDown(200);
        $(this)
          .parent()
          .addClass("active");
      }
    });

    $("#close-sidebar").click(function() {
      $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
      $(".page-wrapper").addClass("toggled");
    });  
       
    });
  </script>

</head>
<body>

  <div class="container-fluid row divheader1">
    <?php
      $this->load->view('templates/header1');
    ?>
  </div>

  <?php
    if ($this->session->userdata('id_adm')) {
      $this->load->view('templates/menu3');
    } else if ($this->session->userdata('id_avaliador')){
      $this->load->view('templates/menu2');
    } else {
      $this->load->view('templates/menu1');
    }
  ?>

  <div class="container-fluid row divprincipal corfonte col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="box col-10 col-sm-10 col-md-10 col-lg-10 col-xl-10">
     
      <div class="row divs div1 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        
        <?php
        foreach ($vulner as $li5 => $l5) {
          foreach ($l5 as $lis5 => $list5) {

            if ($situacao && $situacao2) { ?>
                
              <span>Avaliação: realizada <br>
              Situação: aceita</span>
              
            <?php

            } elseif ($situacao && !$situacao2) { ?>
                
              <span>Avaliação: realizada <br>
              Situação: não aceita</span>
              
            <?php

            } elseif (!$situacao && !$situacao2) { ?>
                
              <p>Avaliação: ainda não realizada</p>

            <?php
            }
            
            if ($list5->data_vulner) {
              $dia = substr($list5->data_vulner, -2);
              $mes = substr($list5->data_vulner, 5, 2);
              $ano = substr($list5->data_vulner, 0, 4);
              $horario = substr($list5->horario_vulner, 0, 5); ?>

              <p class="datahora"><?php echo $dia.'-'.$mes.'-'.$ano.' às '.$horario; ?></p>

              <form method="post" action="<?php echo base_url("/AtualizacaoVulnerCadastrada"); ?>" class="col-12 col-sm-12 col-md-12 col-lg-1 col-xl-1">
                <input type="hidden" id="vulner" name="vulner" value="<?php echo $list5->id_vulner; ?>" readonly="readonly">
                <div class="divexcluir col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <input type="submit" id="excluir" name="excluir" class="img img6 col-3 col-sm-3 col-md-3 col-lg-12 col-xl-12" value="" src="<?php echo base_url("/assets/img/excluir.png"); ?>"></input>
                </div>
              </form>
            
            <?php
            }

          }
        } ?>

      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p class="fonte1 titulovulner">Situação de vulnerabilidade social</p>
      </div>

      <div class="row divs rowimg col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <?php

        $aux1 = false;
        foreach ($imagensv as $li6 => $l6) {
          foreach ($l6 as $lis6 => $list6) {
           
            if ($list6->nome_img_vulner) {
              $aux1 = true;
              ?>
              
              <img src="<?php echo base_url("/upload_img/$list6->nome_img_vulner"); ?>" class="imglist col-8 col-sm-8 col-md-5 col-lg-2 col-xl-2"></img>
            
            <?php
            }

          }
        }

        
        if ($aux1 == false) { ?>
          
          <p class="semimg fonte2">Nenhuma imagem disponível...</p>        
        
        <?php
        }

        ?>

      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
      <?php
        foreach ($vulner as $li7 => $l7) {
          foreach ($l7 as $lis7 => $list7) {
            
            if ($list7->titulo_vulner) { ?>
              <p><?php echo 'Título: '.$list7->titulo_vulner; ?></p>
            <?php
            } ?>
      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <?php
            if ($list7->descricao_vulner) { ?>
              <p><?php echo 'Descrição: '.$list7->descricao_vulner; ?></p>
            <?php
            }

           ?>
      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p><?php echo 'Localização: '.$list7->nome_rua_vulner.', '.$list7->numero_rua_vulner.' - ';

          }
        }
        foreach ($bairro as $li9 => $l9) {
          foreach ($l9 as $lis9 => $list9) {

            echo $list9->nome_bairro.', ';

          }
        }

        foreach ($cidade as $li8 => $l8) {
          foreach ($l8 as $lis8 => $list8) {
            
            echo $list8->nome_cidade.' - '.$list8->sigla_estado.', '; ?>
          
          <?php
          }
        }

        foreach ($vulner as $li5 => $l5) {
          foreach ($l5 as $li5 => $list5) {
            echo $list5->cep_vulner; ?>
              
              </p>
            </div>

          <?php
          }
        }

        ?>

      


      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p>Categorias:

          <?php
          foreach ($itensv as $li => $l) {
            foreach ($l as $lis => $list) {

              foreach ($categoriasv as $li2 => $l2) {
                foreach ($l2 as $li2 => $list2) {
                  if ($list->id_categoria == $list2->id_categoria) {
                    echo ' '.$list2->nome_categoria.' ';

                    echo '('.$list->quantidade_vulner;

                    foreach ($unidadesv as $li4 => $l4) {
                      foreach ($l4 as $li4 => $list4) {
                        if ($list->id_unidade == $list4->id_unidade) {
                          echo ' '.$list4->nome_unidade.');';
                          break;
                        }
                        
                      }
                    }

                    break;
                    
                  }
                  
                }
              }

            }
          }
          ?>

        </p>
        
      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <hr class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2 text-center">
      </div>

      <div class="row divs col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p class="fonte1 titulodoacao">Doações</p>
      </div>

      <div class="row divs fonte2 col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <p>Já doado:

          <?php
          foreach ($itensd as $li12 => $l12) {
            foreach ($l12 as $lis12 => $list12) {

              foreach ($categoriasd as $li13 => $l13) {
                foreach ($l13 as $li13 => $list13) {
                  if ($list12->id_categoria == $list13->id_categoria) {
                    echo ' '.$list13->nome_categoria.' ';

                    echo '('.$list12->quantidade_doacao;

                    foreach ($unidadesd as $li14 => $l14) {
                      foreach ($l14 as $li14 => $list14) {
                        if ($list12->id_unidade == $list14->id_unidade) {
                          echo ' '.$list14->nome_unidade.');';
                          break;
                        }
                        
                      }
                    }

                    break;
                    
                  }
                  
                }
              }

            }
          }
          ?>

        </p>
        

      </div>

    </div>
  </div>
    

</body>
</html>