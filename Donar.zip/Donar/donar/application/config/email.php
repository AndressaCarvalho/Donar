<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config = Array('smtp_host' => 'localhost',
	            'smtp_port' => 25,
	            'smtp_user' => 'donar@localhost',
	            'mailtype'  => 'html',
	            'charset' => 'utf-8',
	            'newline'   => "\r\n",
	            'wordwrap' => TRUE);