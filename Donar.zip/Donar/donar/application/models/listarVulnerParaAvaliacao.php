<?php

class listarVulnerParaAvaliacao extends CI_Model {
	


	public function __construct() {
		parent::__construct();
	}

	public function selecionarVulner1($vi) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('visivel', $vi);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulnerParaAvaliacao($vul, $ava, $usu) {
		$this->db->select('id_avaliacao, id_vulner');
		$this->db->from('tb_avaliacao');
		$this->db->where('id_vulner', $vul);
		$this->db->where('avaliada', $ava);
		$this->db->where('id_avaliador', $usu);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner1($vul) {
		$this->db->select('id_vulner, nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarVulner2($vul) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, horario_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulner3($vu) {
		$this->db->select('id_vulner, visivel, telefone_vulner, titulo_vulner, data_vulner, descricao_vulner, horario_vulner, numero_rua_vulner, nome_rua_vulner, cep_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vu);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner2($vul) {
		$this->db->select('nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($ci) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $ci);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarVulnerItem($vul) {
		$this->db->select('id_vulner_item, quantidade_vulner, id_unidade, id_categoria');
		$this->db->from('tb_vulner_item');
		$this->db->where('id_vulner', $vul);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarCategoria($ca) {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria', $ca);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade($un) {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->where('id_unidade', $un);
		$unidade = $this->db->get();
		return $unidade->result();
	}

}