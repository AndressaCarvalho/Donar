<?php

class listarVulnerDenunciada extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function selecionarVulner1($aval) {
		$this->db->select('id_denuncia_vulner, data_denuncia_vulner, horario_denuncia_vulner, id_vulner');
		$this->db->from('tb_denuncia_vulner');
		$this->db->where('avaliada', $aval);
		$this->db->order_by('id_denuncia_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner1($vul) {
		$this->db->select('id_vulner, nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarVulner2($vul) {
		$this->db->select('id_vulner, titulo_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vul);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarDenuncia($denun) {
		$this->db->select('id_denuncia_vulner, data_denuncia_vulner, horario_denuncia_vulner, detalhamento_denuncia_vulner, id_motivacao');
		$this->db->from('tb_denuncia_vulner');
		$this->db->where('id_denuncia_vulner', $denun);
		$denuncia = $this->db->get();
		return $denuncia->result();
	}

	public function selecionarVulner3($vu) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, descricao_vulner, horario_vulner, id_bairro_cidade, id_usuario');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vu);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner($vul) {
		$this->db->select('nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($ci) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $ci);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarVulnerItem($vul) {
		$this->db->select('id_vulner_item, quantidade_vulner, id_unidade, id_categoria');
		$this->db->from('tb_vulner_item');
		$this->db->where('id_vulner', $vul);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarCategoria($ca) {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria', $ca);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade($un) {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->where('id_unidade', $un);
		$unidade = $this->db->get();
		return $unidade->result();
	}

	public function selecionarUsuario($usu) {
		$this->db->select('id_usuario, nome_usuario, email, telefone_usuario, nome_img_perfil');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarAvaliacao($vul) {
		$this->db->select('id_avaliador');
		$this->db->from('tb_avaliacao');
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_avaliacao', 'DESC');
		$this->db->limit(1);
		$ava = $this->db->get();
		return $ava->result();
	}

	public function selecionarDenunciador1($denun) {
		$this->db->select('id_usuario');
		$this->db->from('tb_denuncia_vulner');
		$this->db->where('id_denuncia_vulner', $denun);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function atualizarBanirUsuario($denun, $aval) {
		$this->db->set('avaliada', $aval);
		$this->db->where('id_denuncia_vulner', $denun);
		$this->db->update('tb_denuncia_vulner');
	}

	public function atualizarVulner($vul, $visi) {
		$this->db->set('visivel', $visi);
		$this->db->where('id_vulner', $vul);
		$this->db->update('tb_vulnerabilidade');
	}

	public function selecionarMotivacao($mot) {
		$this->db->select('motivacao');
		$this->db->from('tb_motivacao');
		$this->db->where('id_motivacao', $mot);
		$motivacao = $this->db->get();
		return $motivacao->result();
	}

}