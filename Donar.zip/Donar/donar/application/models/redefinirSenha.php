<?php

class redefinirSenha extends CI_Model {
	public $id_usuario;
	public $email;
	public $senha;

	public function __construct() {
		parent::__construct();
	}

	public function selecionarIDUsuario($em) {
		$this->db->select('id_usuario');
		$this->db->from('tb_usuario');
		$this->db->where('email', $em);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function atualizacaoSenhaUsuario($sem, $em) {
		$this->db->where('email', $em);
		$this->db->set('senha', $sem);
		$usuario = $this->db->update('tb_usuario');
		return $usuario;
	}
}