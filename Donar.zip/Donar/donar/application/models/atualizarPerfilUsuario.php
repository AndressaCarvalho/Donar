<?php

class atualizarPerfilUsuario extends CI_Model {
	public $id_bairro_cidade;

	public $id_cidade;
	public $nome_cidade;
	public $sigla_estado;
	
	public $nome_bairro;

	public $id_usuario;
	public $nome_usuario;
	public $email;
	public $senha;
	public $telefone_usuario;
	public $nome_img_perfil;
	public $numero_rua_usuario;
	public $nome_rua_usuario;
	public $cep_usuario;


	public function __construct() {
		parent::__construct();
	}

	public function selecionarPorSenha($usu, $se) {
		$this->db->select('email');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$this->db->where('senha', $se);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarIDBairroCidade($bai, $cid) {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('nome_bairro', $bai);
		$this->db->where('id_cidade', $cid);
		$bairrocidade = $this->db->get();
		return $bairrocidade->result();
	}

	public function selecionarIDCidade($cid) {
		$this->db->select('id_cidade');
		$this->db->from('tb_cidade');
		$this->db->where('nome_cidade', $cid);
		$cidade = $this->db->get();
		return $cidade->result();
	}

	public function inserirCidade() {
		$dados = array("nome_cidade" => $this->nome_cidade, "sigla_estado" => $this->sigla_estado);

		$this->db->insert('tb_cidade', $dados);
	}

	public function inserirBairroCidade() {
		$dados = array("nome_bairro" => $this->nome_bairro, "id_cidade" => $this->id_cidade);

		$this->db->insert('tb_bairro_cidade', $dados);
	}

	public function atualizarUsuario1($us, $i, $e, $n, $s, $t, $numr, $nomr, $c, $bc) {
		$this->db->set('nome_usuario', $n);
		$this->db->set('email', $e);
		$this->db->set('telefone_usuario', $t);
		$this->db->set('senha', $s);
		$this->db->set('nome_img_perfil', $i);
		$this->db->set('numero_rua_usuario', $numr);
		$this->db->set('nome_rua_usuario', $nomr);
		$this->db->set('cep_usuario', $c);
		$this->db->set('id_bairro_cidade', $bc);
		$this->db->where('id_usuario', $us);
		$this->db->update('tb_usuario');
	}

	public function atualizarUsuario2($us, $e, $n, $s, $t, $numr, $nomr, $c, $bc) {
		$this->db->set('nome_usuario', $n);
		$this->db->set('email', $e);
		$this->db->set('telefone_usuario', $t);
		$this->db->set('senha', $s);
		$this->db->set('numero_rua_usuario', $numr);
		$this->db->set('nome_rua_usuario', $nomr);
		$this->db->set('cep_usuario', $c);
		$this->db->set('id_bairro_cidade', $bc);
		$this->db->where('id_usuario', $us);
		$this->db->update('tb_usuario');
	}

	public function atualizarUsuario3($us, $i, $e, $n, $t, $numr, $nomr, $c, $bc) {
		$this->db->set('nome_usuario', $n);
		$this->db->set('email', $e);
		$this->db->set('telefone_usuario', $t);
		$this->db->set('nome_img_perfil', $i);
		$this->db->set('numero_rua_usuario', $numr);
		$this->db->set('nome_rua_usuario', $nomr);
		$this->db->set('cep_usuario', $c);
		$this->db->set('id_bairro_cidade', $bc);
		$this->db->where('id_usuario', $us);
		$this->db->update('tb_usuario');
	}

	public function atualizarUsuario4($us, $e, $n, $t, $numr, $nomr, $c, $bc) {
		$this->db->set('nome_usuario', $n);
		$this->db->set('email', $e);
		$this->db->set('telefone_usuario', $t);
		$this->db->set('numero_rua_usuario', $numr);
		$this->db->set('nome_rua_usuario', $nomr);
		$this->db->set('cep_usuario', $c);
		$this->db->set('id_bairro_cidade', $bc);
		$this->db->where('id_usuario', $us);
		$this->db->update('tb_usuario');
	}

	public function desativarUsuario($sit, $us) {
		$this->db->set('ativo', $sit);
		$this->db->where('id_usuario', $us);
		$this->db->update('tb_usuario');
	}

	public function selecionarVulner1($vi, $us) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('visivel', $vi);
		$this->db->where('id_usuario', $us);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function atualizarVulnerInvisivel($vi, $vul) {
		$this->db->set('visivel', $vi);
		$this->db->where('id_vulner', $vul);
		$this->db->update('tb_vulnerabilidade');
	}

}