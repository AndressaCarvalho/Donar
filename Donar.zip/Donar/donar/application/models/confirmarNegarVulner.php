<?php

class confirmarNegarVulner extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function confirmarVVulner($sit, $vul) {
		$this->db->set('visivel', $sit);
		$this->db->where('id_vulner', $vul);
		$this->db->update('tb_vulnerabilidade');
	}

	public function confirmarAvaliacaoVulner($sit1, $sit2, $vul, $usu) {
		$this->db->set('avaliada', $sit1);
		$this->db->where('avaliada', $sit2);
		$this->db->where('id_vulner', $vul);
		$this->db->where('id_avaliador', $usu);
		$this->db->update('tb_avaliacao');
	}

}