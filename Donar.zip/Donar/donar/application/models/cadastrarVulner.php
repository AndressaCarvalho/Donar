<?php

class cadastrarVulner extends CI_Model {
	public $id_categoria;
	public $nome_categoria;
	public $id_categoria_sup;

	public $id_cidade;
	public $nome_cidade;
	public $sigla_estado;
	
	public $nome_bairro;

	public $id_bairro_cidade;

	public $id_vulner;
	public $visivel;
	public $telefone_vulner;
	public $titulo_vulner;
	public $data_vulner;
	public $horario_vulner;
	public $descricao_vulner;
	public $numero_rua_vulner;
	public $nome_rua_vulner;
	public $cep_vulner;
	public $id_usuario;

	public $id_vulner_imagem;
	public $nome_img_vulner;

	public $id_unidade;
	public $nome_unidade;

	public $id_vulner_item;
	public $quantidade_vulner;

	public $nome_usuario;
	public $email;
	public $telefone_usuario;
	public $senha;
	public $adm;
	public $avaliador;
	public $nome_img_perfil;
	public $numero_rua_usuario;
	public $nome_rua_usuario;
	public $cep_usuario;

	public $id_avaliacao;
	public $avaliada;
	public $id_avaliador;

	
	public function __construct() {
		parent::__construct();
	}

	public function selecionarCategoria() {
		$this->db->select('id_categoria, nome_categoria, id_categoria_sup');
		$this->db->from('tb_categoria');
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarCategoriaN1() {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria_sup', NULL);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade() {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->order_by('id_unidade', 'ASC');
		$unidade = $this->db->get();
		return $unidade->result();
	}

	public function selecionarIDBairroCidade($bai, $cid) {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('nome_bairro', $bai);
		$this->db->where('id_cidade', $cid);
		$bairrocidade = $this->db->get();
		return $bairrocidade->result();
	}

	public function selecionarIDCidade($cid) {
		$this->db->select('id_cidade');
		$this->db->from('tb_cidade');
		$this->db->where('nome_cidade', $cid);
		$cidade = $this->db->get();
		return $cidade->result();
	}


	public function inserirCidade() {
		$dados = array("nome_cidade" => $this->nome_cidade, "sigla_estado" => $this->sigla_estado);

		$this->db->insert('tb_cidade', $dados);
	}

	public function inserirBairroCidade() {
		$dados = array("nome_bairro" => $this->nome_bairro, "id_cidade" => $this->id_cidade);

		$this->db->insert('tb_bairro_cidade', $dados);
	}

	public function inserirVulner() {
		$dados = array("visivel" => $this->visivel, "telefone_vulner" => $this->telefone_vulner, "titulo_vulner" => $this->titulo_vulner, "data_vulner" => $this->data_vulner, "horario_vulner" => $this->horario_vulner, "descricao_vulner" => $this->descricao_vulner, "numero_rua_vulner" => $this->numero_rua_vulner, "nome_rua_vulner" => $this->nome_rua_vulner, "cep_vulner" => $this->cep_vulner, "id_usuario" => $this->id_usuario, "id_bairro_cidade" => $this->id_bairro_cidade);

		$this->db->insert('tb_vulnerabilidade', $dados);
	}

	public function selecionarIDVulner($hor, $us, $da) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('horario_vulner', $hor);
		$this->db->where('id_usuario', $us);
		$this->db->where('data_vulner', $da);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function inserirVulnerImagem() {
		$dados = array("nome_img_vulner" => $this->nome_img_vulner, "id_vulner" => $this->id_vulner);

		$this->db->insert('tb_vulner_imagem', $dados);
	}

	public function inserirVulnerItem() {
		$dados = array("id_vulner" => $this->id_vulner,  "id_categoria" => $this->id_categoria, "quantidade_vulner" => $this->quantidade_vulner, "id_unidade" => $this->id_unidade);

		$this->db->insert('tb_vulner_item', $dados);
	}

	public function selecionarAvaUsuarioRand($ava, $sit, $usu) {
		$this->db->select('id_usuario');
		$this->db->from('tb_usuario');
		$this->db->where('avaliador', $ava);
		$this->db->where('ativo', $sit);
		$this->db->where('id_usuario !=', $usu);
		$this->db->order_by('id_usuario', 'RANDOM');
		$this->db->limit(1);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarLocalAva($ava) {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $ava);
		$local = $this->db->get();
		return $local->result();
	}

	public function deletarVulner($vul) {
		$this->db->where('id_vulner', $vul);
		$this->db->delete('tb_vulnerabilidade');
	}

	public function deletarItemVulner($vul) {
		$this->db->where('id_vulner', $vul);
		$this->db->delete('tb_vulner_item');
	}

	public function deletarImagemVulner($vul) {
		$this->db->where('id_vulner', $vul);
		$this->db->delete('tb_vulner_imagem');
	}

	public function selecionarLocalCidade($bc) {
		$this->db->select('id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function inserirAvaliacao() {
		$dados = array("avaliada" => $this->avaliada, "id_vulner" => $this->id_vulner, "id_avaliador" => $this->id_avaliador);

		$this->db->insert('tb_avaliacao', $dados);
	}

	public function selecionarAvaDados($ava) {
		$this->db->select('nome_usuario, email, telefone_usuario, nome_img_perfil, id_bairro_cidade');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $ava);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('id_cidade, nome_bairro');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($cid) {
		$this->db->select('id_cidade, nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $cid);
		$local = $this->db->get();
		return $local->result();
	}

}