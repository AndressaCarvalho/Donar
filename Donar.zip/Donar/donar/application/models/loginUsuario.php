<?php

class loginUsuario extends CI_Model {
	public $id_usuario;
	public $senha;
	public $adm;
	public $avaliador;
	public $id_motivo_banido;
	public $motivo_banido;
	public $detalhamento_banido;
	public $nome_usuario;
	public $nome_img_perfil;

	public function __construct() {
		parent::__construct();
	}

	public function selecionarIDUsuario($em) {
		$this->db->select('id_usuario');
		$this->db->from('tb_usuario');
		$this->db->where('email', $em);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarMotivoUsuarioBanido($uid) {
		$this->db->select('id_motivo_banido');
		$this->db->from('tb_banido');
		$this->db->where('id_usuario', $uid);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarMotivoUsuarioBanido2($uid) {
		$this->db->select('detalhamento_banido');
		$this->db->from('tb_banido');
		$this->db->where('id_usuario', $uid);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarMotivoBanido($idumb) {
		$this->db->select('motivo_banido');
		$this->db->from('tb_motivo_banido');
		$this->db->where('id_motivo_banido', $idumb);
		$motivo = $this->db->get();
		return $motivo->result();
	}

	public function selecionarUsuarioAtivo($em, $sit) {
		$this->db->select('ativo');
		$this->db->from('tb_usuario');
		$this->db->where('email', $em);
		$this->db->where('ativo', $sit);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarSenhaUsuario($em) {
		$this->db->select('senha');
		$this->db->from('tb_usuario');
		$this->db->where('email', $em);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarAtorUsuarioAdm($em) {
		$this->db->select('adm');
		$this->db->from('tb_usuario');
		$this->db->where('email', $em);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarAtorUsuarioAvaliador($em) {
		$this->db->select('avaliador');
		$this->db->from('tb_usuario');
		$this->db->where('email', $em);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarNomeUsuario($id) {
		$this->db->select('nome_usuario');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $id);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarFotoUsuario($id) {
		$this->db->select('nome_img_perfil');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $id);
		$usuario = $this->db->get();
		return $usuario->result();
	}

}