<?php

class confirmarNegarDoacao extends CI_Model {
	public $id_doacao;
	
	public $id_usuario;
	public $id_motivacao;
	public $motivacao;

	public $id_vulner;


	public function __construct() {
		parent::__construct();
	}

	public function confirmarDoacaoDoador($sit, $doa) {
		$this->db->set('doado_doador', $sit);
		$this->db->where('id_doacao', $doa);
		$this->db->update('tb_vulner_doacao');
	}

	public function negarDoacaoDoador($sit, $doa) {
		$this->db->set('doado_doador', $sit);
		$this->db->where('id_doacao', $doa);
		$this->db->update('tb_vulner_doacao');
	}

	public function selecionarSituacao($sit1, $sit2, $doa) {
		$this->db->select('id_vulner_doacao');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_doacao', $doa);
		$this->db->where('doado_doador', $sit1);
		$this->db->where('doado_receptor', $sit2);
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function horarioDiaDoacao($hora, $dia, $doa) {
		$this->db->set('horario_confirmacao_doacao', $hora);
		$this->db->set('data_confirmacao_doacao', $dia);
		$this->db->where('id_doacao', $doa);
		$this->db->update('tb_vulner_doacao');
	}

}