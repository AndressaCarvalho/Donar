<?php

class listarVulnerCadastrada extends CI_Model {
	


	public function __construct() {
		parent::__construct();
	}

	public function selecionarVulner1($usu) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_usuario', $usu);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner1($vul) {
		$this->db->select('id_vulner, nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarVulner2($vul) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, horario_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulner3($vu) {
		$this->db->select('id_vulner, visivel, telefone_vulner, titulo_vulner, data_vulner, descricao_vulner, horario_vulner, numero_rua_vulner, nome_rua_vulner, cep_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vu);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner2($vul) {
		$this->db->select('nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($ci) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $ci);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarVulnerItem($vul) {
		$this->db->select('id_vulner_item, quantidade_vulner, id_unidade, id_categoria');
		$this->db->from('tb_vulner_item');
		$this->db->where('id_vulner', $vul);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarCategoria($ca) {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria', $ca);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade($un) {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->where('id_unidade', $un);
		$unidade = $this->db->get();
		return $unidade->result();
	}

	public function selecionarVulnerDoacao2() {
		$this->db->select('id_vulner, id_doacao, id_vulner_doacao, doado_doador, doado_receptor');
		$this->db->from('tb_vulner_doacao');
		$this->db->order_by('id_vulner_doacao', 'DESC');
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function selecionarDoacao1($vul) {
		$this->db->select('id_doacao, ');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_vulner_doacao', 'DESC');
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function selecionarDoacaoItem($do) {
		$this->db->select('id_doacao_item, id_doacao, quantidade_doacao, id_unidade, id_categoria');
		$this->db->from('tb_doacao_item');
		$this->db->where('id_doacao', $do);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarAvaVulner($vul, $si) {
		$this->db->select('id_avaliacao');
		$this->db->from('tb_avaliacao');
		$this->db->where('id_vulner', $vul);
		$this->db->where('avaliada', $si);
		$sit = $this->db->get();
		return $sit->result();
	}

	public function selecionarViVulner($vul, $si) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vul);
		$this->db->where('visivel', $si);
		$sit = $this->db->get();
		return $sit->result();
	}

	public function selecionarCategoriaLista() {
		$this->db->select('id_categoria, nome_categoria, id_categoria_sup');
		$this->db->from('tb_categoria');
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidadeLista() {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->order_by('id_unidade', 'ASC');
		$unidade = $this->db->get();
		return $unidade->result();
	}


}