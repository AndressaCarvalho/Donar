<?php

class listarDoacaoDenunciada extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function selecionarDoacao1($aval) {
		$this->db->select('id_denuncia_doacao, data_denuncia_doacao, horario_denuncia_doacao, id_doacao');
		$this->db->from('tb_denuncia_doacao');
		$this->db->where('avaliada', $aval);
		$this->db->order_by('id_denuncia_doacao', 'DESC');
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function selecionarImagemDoacao1($doa) {
		$this->db->select('id_doacao, nome_img_doacao');
		$this->db->from('tb_doacao_imagem');
		$this->db->where('id_doacao', $doa);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarVulner1($doa) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_doacao', $doa);
		$this->db->order_by('id_vulner_doacao', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulner2($vul) {
		$this->db->select('id_vulner, titulo_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulnerDoacao($doa) {
		$this->db->select('id_vulner, id_doacao');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_doacao', $doa);
		$this->db->order_by('id_vulner_doacao', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulner3($vu) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, descricao_vulner, horario_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vu);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner($vul) {
		$this->db->select('nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($ci) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $ci);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarVulnerItem($vul) {
		$this->db->select('id_vulner_item, quantidade_vulner, id_unidade, id_categoria');
		$this->db->from('tb_vulner_item');
		$this->db->where('id_vulner', $vul);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarCategoria($ca) {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria', $ca);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade($un) {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->where('id_unidade', $un);
		$unidade = $this->db->get();
		return $unidade->result();
	}

	public function selecionarDoacao2($doac) {
		$this->db->select('id_doacao, id_usuario, data_doacao, horario_doacao');
		$this->db->from('tb_doacao');
		$this->db->where('id_doacao', $doac);
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function selecionarDoacaoItem($do) {
		$this->db->select('id_doacao_item, quantidade_doacao, id_unidade, id_categoria');
		$this->db->from('tb_doacao_item');
		$this->db->where('id_doacao', $do);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarUsuario($usu) {
		$this->db->select('id_usuario, nome_usuario, email, telefone_usuario, nome_img_perfil');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarDenunciador1($denun) {
		$this->db->select('id_usuario');
		$this->db->from('tb_denuncia_doacao');
		$this->db->where('id_denuncia_doacao', $denun);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarDenuncia($denun) {
		$this->db->select('id_denuncia_doacao, data_denuncia_doacao, horario_denuncia_doacao, detalhamento_denuncia_doacao, id_motivacao');
		$this->db->from('tb_denuncia_doacao');
		$this->db->where('id_denuncia_doacao', $denun);
		$denuncia = $this->db->get();
		return $denuncia->result();
	}

	public function atualizarBanirDoador($denun, $aval) {
		$this->db->set('avaliada', $aval);
		$this->db->where('id_denuncia_doacao', $denun);
		$this->db->update('tb_denuncia_doacao');
	}

	public function selecionarMotivacao($mot) {
		$this->db->select('motivacao');
		$this->db->from('tb_motivacao');
		$this->db->where('id_motivacao', $mot);
		$motivacao = $this->db->get();
		return $motivacao->result();
	}

	public function atualizarVulners($usu, $visi) {
		$this->db->set('visivel', $visi);
		$this->db->where('id_usuario', $usu);
		$this->db->update('tb_vulnerabilidade');
	}

}