<?php

class listarVulner extends CI_Model {
	public $id_categoria;
	public $nome_categoria;
	public $id_categoria_sup;

	public $id_bairro_cidade;
	public $id_cidade;
	public $id_bairro;

	public function __construct() {
		parent::__construct();
	}

	public function selecionarCategoria1() {
		$this->db->select('id_categoria, nome_categoria, id_categoria_sup');
		$this->db->from('tb_categoria');
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarCategoriaN1() {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria_sup', NULL);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarVulner1($vi, $bc) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, horario_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('visivel', $vi);
		$this->db->where('id_bairro_cidade', $bc);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner1($vul) {
		$this->db->select('id_vulner_imagem, id_vulner, nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarLocal1($bc) {
		$this->db->select('id_bairro_cidade, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarLocal2($c) {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_cidade', $c);
		$this->db->order_by('id_bairro_cidade', 'DESC');
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarLocal3() {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_bairro_cidade');
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarUsuario($us) {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $us);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarVulner3($vu) {
		$this->db->select('id_vulner, visivel, telefone_vulner, titulo_vulner, data_vulner, descricao_vulner, horario_vulner, numero_rua_vulner, nome_rua_vulner, cep_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vu);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarAvaVulner($vul, $si) {
		$this->db->select('id_avaliacao');
		$this->db->from('tb_avaliacao');
		$this->db->where('id_vulner', $vul);
		$this->db->where('avaliada', $si);
		$sit = $this->db->get();
		return $sit->result();
	}

	public function selecionarImagemVulner2($vul) {
		$this->db->select('nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarBairro($bai) {
		$this->db->select('nome_bairro');
		$this->db->from('tb_bairro');
		$this->db->where('id_bairro', $bai);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($ci) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $ci);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarVulnerItem($vul) {
		$this->db->select('id_vulner_item, quantidade_vulner, id_unidade, id_categoria');
		$this->db->from('tb_vulner_item');
		$this->db->where('id_vulner', $vul);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarCategoria($ca) {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria', $ca);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade($un) {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->where('id_unidade', $un);
		$unidade = $this->db->get();
		return $unidade->result();
	}

	public function selecionarVulnerDoacao2() {
		$this->db->select('id_vulner, id_doacao, id_vulner_doacao, doado_doador, doado_receptor');
		$this->db->from('tb_vulner_doacao');
		$this->db->order_by('id_vulner_doacao', 'DESC');
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function selecionarDoacaoItem($do) {
		$this->db->select('id_doacao_item, id_doacao, quantidade_doacao, id_unidade, id_categoria');
		$this->db->from('tb_doacao_item');
		$this->db->where('id_doacao', $do);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarVulner2($usu) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_usuario', $usu);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarDoacao($usu) {
		$this->db->select('id_doacao');
		$this->db->from('tb_doacao');
		$this->db->where('id_usuario', $usu);
		$this->db->order_by('id_doacao', 'DESC');
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function selecionarVulnerDoacao1($doa, $dd) {
		$this->db->select('id_vulner_doacao');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_doacao', $doa);
		$this->db->where('doado_doador', $dd);
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function selecionarVulnerDoacao3($vul, $dr) {
		$this->db->select('id_vulner_doacao');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_vulner', $vul);
		$this->db->where('doado_receptor', $dr);
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function selecionarVulnerCategoria($cat) {
		$this->db->select('id_vulner');
		$this->db->distinct();
		$this->db->from('tb_vulner_item');
		$this->db->where('id_categoria', $cat);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulner4($vi, $vul) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, horario_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('visivel', $vi);
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarSubcategoria($cat) {
		$this->db->select('tb_vulner_item.id_vulner');
		$this->db->distinct();
		$this->db->from('tb_vulner_item');
		$this->db->join('tb_categoria', 'tb_categoria.id_categoria = tb_vulner_item.id_categoria');
		$this->db->where('tb_categoria.id_categoria_sup', $cat);
		$this->db->order_by('tb_vulner_item.id_vulner', 'DESC');
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarVulner5($vi, $titu) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, horario_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('visivel', $vi);
		$this->db->like('titulo_vulner', $titu);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

}