<?php

class listarRecebimentoDoacao extends CI_Model {

	public $id_vulner;
	public $id_usuario;


	public function __construct() {
		parent::__construct();
	}

	public function selecionarVulner1($usu, $vul) {
		$this->db->select('id_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_usuario', $usu);
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarVulnerDoacao1($vd) {
		$this->db->select('id_vulner, id_doacao');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_vulner_doacao', $vd);
		$this->db->order_by('id_vulner_doacao', 'DESC');
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function selecionarImagemDoacao1($doa) {
		$this->db->select('id_doacao, nome_img_doacao');
		$this->db->from('tb_doacao_imagem');
		$this->db->where('id_doacao', $doa);
		$this->db->order_by('id_doacao_imagem', 'DESC');
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarVulner2($vul) {
		$this->db->select('id_vulner, titulo_vulner');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vul);
		$this->db->order_by('id_vulner', 'DESC');
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarDoacao1($do) {
		$this->db->select('id_doacao, data_doacao, horario_doacao, id_usuario');
		$this->db->from('tb_doacao');
		$this->db->where('id_doacao', $do);
		$this->db->order_by('id_doacao', 'DESC');
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function selecionarVulnerDoacao2() {
		$this->db->select('id_vulner, id_doacao, id_vulner_doacao');
		$this->db->from('tb_vulner_doacao');
		$this->db->order_by('id_vulner_doacao', 'DESC');
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function selecionarVulner3($vu) {
		$this->db->select('id_vulner, titulo_vulner, data_vulner, descricao_vulner, horario_vulner, numero_rua_vulner, nome_rua_vulner, cep_vulner, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vu);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarImagemVulner($vul) {
		$this->db->select('nome_img_vulner');
		$this->db->from('tb_vulner_imagem');
		$this->db->where('id_vulner', $vul);
		$img = $this->db->get();
		return $img->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($ci) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $ci);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarVulnerItem($vul) {
		$this->db->select('id_vulner_item, quantidade_vulner, id_unidade, id_categoria');
		$this->db->from('tb_vulner_item');
		$this->db->where('id_vulner', $vul);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarCategoria($ca) {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria', $ca);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade($un) {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->where('id_unidade', $un);
		$unidade = $this->db->get();
		return $unidade->result();
	}

	public function selecionarDoacao2($doac) {
		$this->db->select('id_doacao, data_doacao, horario_doacao');
		$this->db->from('tb_doacao');
		$this->db->where('id_doacao', $doac);
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function selecionarDoacaoItem($do) {
		$this->db->select('id_doacao_item, quantidade_doacao, id_unidade, id_categoria');
		$this->db->from('tb_doacao_item');
		$this->db->where('id_doacao', $do);
		$item = $this->db->get();
		return $item->result();
	}

	public function selecionarVulnerDoacao3($si, $do) {
		$this->db->select('doado_doador');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_doacao', $do);
		$this->db->where('doado_receptor', $si);
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function selecionarUsuarioDoacao($doac) {
		$this->db->select('id_usuario');
		$this->db->from('tb_doacao');
		$this->db->where('id_doacao', $doac);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarUsuario($usu) {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$usuario = $this->db->get();
		return $usuario->result();
	}

}