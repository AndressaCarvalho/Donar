<?php

class autocadastrarAvaliador extends CI_Model {

	public $id_usuario;
	public $id_avaliador;
	public $nome_img_identidade;
	public $nome_img_cresidencia;
	public $descricao_recusa;
	public $data_avaliador;
	public $horario_avaliador;


	public function __construct() {
		parent::__construct();
	}

	public function inserirAvaliador() {
		$dados = array("id_usuario" => $this->id_usuario, "nome_img_identidade" => $this->nome_img_identidade, "nome_img_cresidencia" => $this->nome_img_cresidencia, "descricao_recusa" => $this->descricao_recusa, "data_avaliador" => $this->data_avaliador, "horario_avaliador" => $this->horario_avaliador);

		$this->db->insert('tb_avaliador', $dados);
	}

}