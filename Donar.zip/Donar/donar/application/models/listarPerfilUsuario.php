<?php

class listarPerfilUsuario extends CI_Model {
	public $id_bairro_cidade;

	public $id_cidade;
	public $nome_cidade;
	public $sigla_estado;
	
	public $id_bairro;
	public $nome_bairro;

	public $id_usuario;
	public $nome_usuario;
	public $email;
	public $telefone_usuario;
	public $nome_img_perfil;
	public $numero_rua_usuario;
	public $nome_rua_usuario;
	public $cep_usuario;

	public $id_avaliador;


	public function __construct() {
		parent::__construct();
	}

	public function selecionarUsuario($usu) {
		$this->db->select('nome_usuario, email, telefone_usuario, nome_img_perfil, numero_rua_usuario, nome_rua_usuario, cep_usuario, id_bairro_cidade');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($cid) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $cid);
		$cidade = $this->db->get();
		return $cidade->result();
	}

	public function selecionarAvaliador($us) {
		$this->db->select('id_avaliador');
		$this->db->from('tb_avaliador');
		$this->db->where('id_usuario', $us);
		$avaliador = $this->db->get();
		return $avaliador->result();
	}

	public function selecionarAvaliadorUsuario($us, $sit) {
		$this->db->select('avaliador');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $us);
		$this->db->where('avaliador', $sit);
		$avaliador = $this->db->get();
		return $avaliador->result();
	}

}