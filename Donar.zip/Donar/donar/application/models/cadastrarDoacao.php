<?php

class cadastrarDoacao extends CI_Model {
	public $id_doacao;
	public $id_usuario;
	public $data_doacao;
	public $horario_doacao;
	
	public $id_doacao_imagem;
	public $nome_img_doacao;

	public $id_categoria;
	public $nome_categoria;
	public $id_categoria_sup;

	public $id_unidade;
	public $nome_unidade;

	public $id_doacao_item;
	public $quantidade_doacao;

	public $id_vulner;
	public $doado_doador;
	public $doado_receptor;
	public $descricao_rejeicao_receptor;
	public $data_confirmacao_doacao;
	public $horario_confirmacao_doacao;

	public $telefone_vulner;
	public $numero_rua_vulner;
	public $nome_rua_vulner;
	public $cep_vulner;

	public $id_cidade;
	public $nome_cidade;
	public $sigla_estado;
	
	public $nome_bairro;

	public $id_bairro_cidade;

	public $nome_usuario;
	public $email;
	public $nome_img_perfil;

	
	public function __construct() {
		parent::__construct();
	}

	public function selecionarCategoria() {
		$this->db->select('id_categoria, nome_categoria, id_categoria_sup');
		$this->db->from('tb_categoria');
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function selecionarUnidade() {
		$this->db->select('id_unidade, nome_unidade');
		$this->db->from('tb_unidade');
		$this->db->order_by('id_unidade', 'ASC');
		$unidade = $this->db->get();
		return $unidade->result();
	}

	public function inserirDoacao() {
		$dados = array("id_usuario" => $this->id_usuario, "data_doacao" => $this->data_doacao, "horario_doacao" => $this->horario_doacao);

		$this->db->insert('tb_doacao', $dados);
	}

	public function selecionarIDDoacao($hor, $us, $da) {
		$this->db->select('id_doacao');
		$this->db->from('tb_doacao');
		$this->db->where('horario_doacao', $hor);
		$this->db->where('id_usuario', $us);
		$this->db->where('data_doacao', $da);
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function inserirDoacaoImagem() {
		$dados = array("nome_img_doacao" => $this->nome_img_doacao, "id_doacao" => $this->id_doacao);

		$this->db->insert('tb_doacao_imagem', $dados);
	}

	public function inserirDoacaoItem() {
		$dados = array("id_doacao" => $this->id_doacao,  "id_categoria" => $this->id_categoria, "quantidade_doacao" => $this->quantidade_doacao, "id_unidade" => $this->id_unidade);

		$this->db->insert('tb_doacao_item', $dados);
	}

	public function inserirVulnerDoacao() {
		$dados = array("id_vulner" => $this->id_vulner, "id_doacao" => $this->id_doacao,  "doado_doador" => $this->doado_doador, "doado_receptor" => $this->doado_receptor, "descricao_rejeicao_receptor" => $this->descricao_rejeicao_receptor, "data_confirmacao_doacao" => $this->data_confirmacao_doacao, "horario_confirmacao_doacao" => $this->horario_confirmacao_doacao);

		$this->db->insert('tb_vulner_doacao', $dados);
	}

	public function selecionarVulner($vul) {
		$this->db->select('telefone_vulner, numero_rua_vulner, nome_rua_vulner, cep_vulner, id_usuario, id_bairro_cidade');
		$this->db->from('tb_vulnerabilidade');
		$this->db->where('id_vulner', $vul);
		$vulner = $this->db->get();
		return $vulner->result();
	}

	public function selecionarUsuario($us) {
		$this->db->select('nome_usuario, email, nome_img_perfil');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $us);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($cid) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $cid);
		$cidade = $this->db->get();
		return $cidade->result();
	}

}