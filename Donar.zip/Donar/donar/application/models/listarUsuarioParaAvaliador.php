<?php

class listarUsuarioParaAvaliador extends CI_Model {

	public function __construct() {
		parent::__construct();
	}


	public function selecionarAva1($desc) {
		$this->db->select('*');
		$this->db->from('tb_avaliador');
		$this->db->where('descricao_recusa', $desc);
		$this->db->order_by('id_avaliador', 'DESC');
		$ava = $this->db->get();
		return $ava->result();
	}

	public function selecionarNAva($usu, $ava) {
		$this->db->select('id_usuario, nome_usuario, nome_img_perfil');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$this->db->where('avaliador', $ava);
		$usava = $this->db->get();
		return $usava->result();
	}

	public function selecionarAva2($usu) {
		$this->db->select('id_usuario, data_avaliador, horario_avaliador');
		$this->db->from('tb_avaliador');
		$this->db->where('id_usuario', $usu);
		$ava = $this->db->get();
		return $ava->result();
	}

	public function selecionarUsuario($usu) {
		$this->db->select('id_usuario, nome_usuario, email, telefone_usuario, nome_img_perfil, numero_rua_usuario, nome_rua_usuario, cep_usuario, id_bairro_cidade');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($cid) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $cid);
		$cidade = $this->db->get();
		return $cidade->result();
	}

	public function selecionarUsuario2($usu) {
		$this->db->select('nome_img_identidade, nome_img_cresidencia, data_avaliador, horario_avaliador');
		$this->db->from('tb_avaliador');
		$this->db->where('id_usuario', $usu);
		$usuario = $this->db->get();
		return $usuario->result();
	}

}