<?php

class aceitarRecusarUsuarioAvaliador extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function atualizarUsuario($usu, $ava) {
		$this->db->set('avaliador', $ava);
		$this->db->where('id_usuario', $usu);
		$this->db->update('tb_usuario');
	}

	public function deletarAvaliador($usu) {
		$this->db->where('id_usuario', $usu);
		$this->db->delete('tb_avaliador');
	}

	public function atualizarUsuarioRecusaAvaliador($usu, $dat, $hor, $det) {
		$this->db->set('descricao_recusa', $det);
		$this->db->where('id_usuario', $usu);
		$this->db->where('data_avaliador', $dat);
		$this->db->where('horario_avaliador', $hor);
		$this->db->update('tb_avaliador');
	}

}