<?php

class cadastrarCategoriaUnidadeMotivacao extends CI_Model {
	public $nome_unidade;
	public $motivo_banido;
	public $motivacao;
	public $nome_categoria;
	public $id_categoria_sup;

	public function __construct() {
		parent::__construct();
	}

	public function cadastrarUnidade() {
		$dados = array("nome_unidade" => $this->nome_unidade);

		$this->db->insert('tb_unidade', $dados);
	}

	public function cadastrarMotivoBanido() {
		$dados = array("motivo_banido" => $this->motivo_banido);

		$this->db->insert('tb_motivo_banido', $dados);
	}

	public function cadastrarMotivoDenuncia() {
		$dados = array("motivacao" => $this->motivacao);

		$this->db->insert('tb_motivacao', $dados);
	}

	public function selecionarCategoria() {
		$this->db->select('id_categoria, nome_categoria');
		$this->db->from('tb_categoria');
		$this->db->where('id_categoria_sup', NULL);
		$categoria = $this->db->get();
		return $categoria->result();
	}

	public function cadastrarCategoria() {
		$dados = array("nome_categoria" => $this->nome_categoria, "id_categoria_sup" => $this->id_categoria_sup);

		$this->db->insert('tb_categoria', $dados);
	}

}