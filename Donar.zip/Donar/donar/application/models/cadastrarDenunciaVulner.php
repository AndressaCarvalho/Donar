<?php

class cadastrarDenunciaVulner extends CI_Model {
	public $id_denuncia_vulner;
	public $id_vulner;
	public $id_usuario;
	public $id_motivacao;
	public $data_denuncia_vulner;
	public $horario_denuncia_vulner;
	public $detalhamento_denuncia_vulner;

	public function __construct() {
		parent::__construct();
	}

	public function selecionarMotivacao() {
		$this->db->select('id_motivacao, motivacao');
		$this->db->from('tb_motivacao');
		$motivacao = $this->db->get();
		return $motivacao->result();
	}

	public function inserirDenunciaVulner() {
		$dados = array( "data_denuncia_vulner" => $this->data_denuncia_vulner, "horario_denuncia_vulner" => $this->horario_denuncia_vulner, "detalhamento_denuncia_vulner" => $this->detalhamento_denuncia_vulner, "id_vulner" => $this->id_vulner, "id_usuario" => $this->id_usuario, "id_motivacao" => $this->id_motivacao);

		$this->db->insert('tb_denuncia_vulner', $dados);
	}

}