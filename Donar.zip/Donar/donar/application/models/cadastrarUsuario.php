<?php

class cadastrarUsuario extends CI_Model {
	public $id_bairro_cidade;

	public $id_cidade;
	public $nome_cidade;
	public $sigla_estado;
	
	public $nome_bairro;

	public $id_usuario;
	public $nome_usuario;
	public $email;
	public $telefone_usuario;
	public $senha;
	public $adm = false;
	public $avaliador = false;
	public $nome_img_perfil;
	public $numero_rua_usuario;
	public $nome_rua_usuario;
	public $cep_usuario;
	public $ativo;


	public function __construct() {
		parent::__construct();
	}

	public function selecionarIDBairroCidade($bai, $cid) {
		$this->db->select('id_bairro_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('nome_bairro', $bai);
		$this->db->where('id_cidade', $cid);
		$bairrocidade = $this->db->get();
		return $bairrocidade->result();
	}

	public function selecionarIDCidade($cid) {
		$this->db->select('id_cidade');
		$this->db->from('tb_cidade');
		$this->db->where('nome_cidade', $cid);
		$cidade = $this->db->get();
		return $cidade->result();
	}

	public function inserirCidade() {
		$dados = array("nome_cidade" => $this->nome_cidade, "sigla_estado" => $this->sigla_estado);

		$this->db->insert('tb_cidade', $dados);
	}

	public function inserirBairroCidade() {
		$dados = array("id_cidade" => $this->id_cidade, "nome_bairro" => $this->nome_bairro);

		$this->db->insert('tb_bairro_cidade', $dados);
	}

	public function selecionarIDUsuario($em) {
		$this->db->select('id_usuario');
		$this->db->from('tb_usuario');
		$this->db->where('email', $em);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function inserirUsuario() {
		$dados = array("nome_usuario" => $this->nome_usuario, "email" => $this->email, "telefone_usuario" => $this->telefone_usuario, "senha" => $this->senha, "adm" => $this->adm, "avaliador" => $this->avaliador, "nome_img_perfil" => $this->nome_img_perfil, "numero_rua_usuario" => $this->numero_rua_usuario, "nome_rua_usuario" => $this->nome_rua_usuario, "cep_usuario" => $this->cep_usuario, "id_bairro_cidade" => $this->id_bairro_cidade, "ativo" => $this->ativo);

		$this->db->insert('tb_usuario', $dados);
	}

	public function selecionarNomeUsuario($id) {
		$this->db->select('nome_usuario');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $id);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarFotoUsuario($id) {
		$this->db->select('nome_img_perfil');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $id);
		$usuario = $this->db->get();
		return $usuario->result();
	}

}