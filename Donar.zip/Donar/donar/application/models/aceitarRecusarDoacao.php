<?php

class aceitarRecusarDoacao extends CI_Model {


	public function __construct() {
		parent::__construct();
	}

	public function aceitarDoacaoReceptor($sit, $doa) {
		$this->db->set('doado_receptor', $sit);
		$this->db->where('id_doacao', $doa);
		$this->db->update('tb_vulner_doacao');
	}

	public function selecionarSituacao($sit1, $sit2, $doa) {
		$this->db->select('id_vulner_doacao');
		$this->db->from('tb_vulner_doacao');
		$this->db->where('id_doacao', $doa);
		$this->db->where('doado_doador', $sit1);
		$this->db->where('doado_receptor', $sit2);
		$vulnerdoacao = $this->db->get();
		return $vulnerdoacao->result();
	}

	public function horarioDiaDoacao($hora, $dia, $doa) {
		$this->db->set('horario_confirmacao_doacao', $hora);
		$this->db->set('data_confirmacao_doacao', $dia);
		$this->db->where('id_doacao', $doa);
		$this->db->update('tb_vulner_doacao');
	}

	public function selecionarDoacao($doa) {
		$this->db->select('id_usuario');
		$this->db->from('tb_doacao');
		$this->db->where('id_doacao', $doa);
		$doacao = $this->db->get();
		return $doacao->result();
	}

	public function selecionarUsuario($us) {
		$this->db->select('nome_usuario, email, nome_img_perfil, telefone_usuario, numero_rua_usuario, nome_rua_usuario, cep_usuario, id_bairro_cidade');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $us);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function selecionarLocal($bc) {
		$this->db->select('nome_bairro, id_cidade');
		$this->db->from('tb_bairro_cidade');
		$this->db->where('id_bairro_cidade', $bc);
		$local = $this->db->get();
		return $local->result();
	}

	public function selecionarCidade($cid) {
		$this->db->select('nome_cidade, sigla_estado');
		$this->db->from('tb_cidade');
		$this->db->where('id_cidade', $cid);
		$cidade = $this->db->get();
		return $cidade->result();
	}

	public function recusarDoacaoReceptor($sit, $doa) {
		$this->db->set('doado_receptor', $sit);
		$this->db->where('id_doacao', $doa);
		$this->db->update('tb_vulner_doacao');
	}

	public function rejeicaoDoacaoReceptor($det, $vul, $doa) {
		$this->db->set('descricao_rejeicao_receptor', $det);
		$this->db->where('id_vulner', $vul);
		$this->db->where('id_doacao', $doa);
		$this->db->update('tb_vulner_doacao');
	}

}