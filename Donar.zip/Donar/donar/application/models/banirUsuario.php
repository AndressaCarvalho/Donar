<?php

class banirUsuario extends CI_Model {
	public $data_banido;
	public $detalhamento_banido;
	public $id_usuario;
	public $id_motivo_banido;

	public function __construct() {
		parent::__construct();
	}

	public function selecionarMotivo() {
		$this->db->select('id_motivo_banido, motivo_banido');
		$this->db->from('tb_motivo_banido');
		$motivo = $this->db->get();
		return $motivo->result();
	}

	public function banirUsuario() {
		$dados = array("data_banido" => $this->data_banido, "detalhamento_banido" => $this->detalhamento_banido, "id_usuario" => $this->id_usuario, "id_motivo_banido" => $this->id_motivo_banido);

		$this->db->insert('tb_banido', $dados);
	}

	public function atualizarUsuario($usu, $ati) {
		$this->db->set('ativo', $ati);
		$this->db->where('id_usuario', $usu);
		$this->db->update('tb_usuario');
	}

}