<?php

class cadastrarDenunciaDoacao extends CI_Model {
	public $id_denuncia_doacao;
	public $id_doacao;
	public $id_usuario;
	public $id_motivacao;
	public $data_denuncia_doacao;
	public $horario_denuncia_doacao;
	public $detalhamento_denuncia_doacao;
	public $avaliada;

	public function __construct() {
		parent::__construct();
	}

	public function selecionarMotivacao() {
		$this->db->select('id_motivacao, motivacao');
		$this->db->from('tb_motivacao');
		$motivacao = $this->db->get();
		return $motivacao->result();
	}

	public function inserirDenunciaDoacao() {
		$dados = array( "data_denuncia_doacao" => $this->data_denuncia_doacao, "horario_denuncia_doacao" => $this->horario_denuncia_doacao, "detalhamento_denuncia_doacao" => $this->detalhamento_denuncia_doacao, "id_doacao" => $this->id_doacao, "id_usuario" => $this->id_usuario, "id_motivacao" => $this->id_motivacao, "avaliada" => $this->avaliada);

		$this->db->insert('tb_denuncia_doacao', $dados);
	}

}