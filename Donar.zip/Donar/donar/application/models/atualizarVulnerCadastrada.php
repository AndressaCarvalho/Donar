<?php

class atualizarVulnerCadastrada extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function selecionarPorSenha($usu, $se) {
		$this->db->select('email');
		$this->db->from('tb_usuario');
		$this->db->where('id_usuario', $usu);
		$this->db->where('senha', $se);
		$usuario = $this->db->get();
		return $usuario->result();
	}

	public function atualizarVulnerInvisivel($vi, $vul) {
		$this->db->set('visivel', $vi);
		$this->db->where('id_vulner', $vul);
		$this->db->update('tb_vulnerabilidade');
	}

}