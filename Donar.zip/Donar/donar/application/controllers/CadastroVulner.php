<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CadastroVulner extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->load->model('cadastrarVulner');
			$cat['lista'] = ($this->cadastrarVulner->selecionarCategoria());
			$uni['lista2'] = ($this->cadastrarVulner->selecionarUnidade());

			$dados = array('cats' => $cat,'unis' => $uni);

			$this->load->view('cadastroVulner', $dados);

		} else {
			redirect('Donar','refresh');
		}

	}

	public function cadastrarVulner()
	{
		$this->form_validation->set_rules('numTelefone', 'Número de telefone', 'required|max_length[13]|min_length[13]|trim');
        $this->form_validation->set_rules('titulo', 'Título', 'required|max_length[40]|min_length[10]|trim');
        $this->form_validation->set_rules('descricao', 'Descrição', 'required|max_length[200]|min_length[40]|trim');
        $this->form_validation->set_rules('numRua', 'Número da casa', 'required|max_length[5]|min_length[1]|trim');
        $this->form_validation->set_rules('cep', 'CEP', 'required|max_length[9]|min_length[9]|trim');
        $this->form_validation->set_rules('rua', 'Rua', 'required|max_length[100]');
        $this->form_validation->set_rules('bairro', 'Bairro', 'required|max_length[100]');
        $this->form_validation->set_rules('cidade', 'Cidade', 'required|max_length[200]');
        $this->form_validation->set_rules('uf', 'Estado', 'required|max_length[2]');
        $this->form_validation->set_rules('quantidade1', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade2', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade3', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade4', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade5', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade6', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade7', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade8', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade9', 'Quantidade', 'numeric|max_length[5]|trim');
        $this->form_validation->set_rules('quantidade10', 'Quantidade', 'numeric|max_length[5]|trim');

        if ($this->form_validation->run() == TRUE) {
			$this->load->model('cadastrarVulner');


			$numTelefone = trim($_POST['numTelefone']);
			$titulo = trim($_POST['titulo']);
			$descricao = trim($_POST['descricao']);
			$numRua = trim($_POST['numRua']);
			$cep = $_POST['cep'];
			$nomeRua = $_POST['rua'];
			$estado = $_POST['uf'];
			$cidade = $_POST['cidade'];
			$bairro = $_POST['bairro'];

			date_default_timezone_set('America/Sao_Paulo');
			$data = date('Y-m-d');
			$horario = date('H:i:s');
			
			$vis = false;

			$cid = ($this->cadastrarVulner->selecionarIDCidade($cidade));
			if ($cid) {
				$cid = ($this->cadastrarVulner->selecionarIDCidade($cidade))[0]->id_cidade;
			} else {
				$cid = 0;
			}

			$baicid = ($this->cadastrarVulner->selecionarIDBairroCidade($bairro, $cid));



			$catPreenchida = false;
			$catvalor1 = false;
			$catvalor2 = false;
			$catvalor3 = false;
			$catvalor4 = false;
			$catvalor5 = false;
			$catvalor6 = false;
			$catvalor7 = false;
			$catvalor8 = false;
			$catvalor9 = false;
			$catvalor10 = false;
			if (isset($_POST['categoriaLista1'])) {
				$catPreenchida = true;
				$catvalor1 = true;
			}
			if (isset($_POST['categoriaLista2'])) {
				$catPreenchida = true;
				$catvalor2 = true;
			}
			if (isset($_POST['categoriaLista3'])) {
				$catPreenchida = true;
				$catvalor3 = true;
			}
			if (isset($_POST['categoriaLista4'])) {
				$catPreenchida = true;
				$catvalor4 = true;
			}
			if (isset($_POST['categoriaLista5'])) {
				$catPreenchida = true;
				$catvalor5 = true;
			}
			if (isset($_POST['categoriaLista6'])) {
				$catPreenchida = true;
				$catvalor6 = true;
			}
			if (isset($_POST['categoriaLista7'])) {
				$catPreenchida = true;
				$catvalor7 = true;
			}
			if (isset($_POST['categoriaLista8'])) {
				$catPreenchida = true;
				$catvalor8 = true;
			}
			if (isset($_POST['categoriaLista9'])) {
				$catPreenchida = true;
				$catvalor9 = true;
			}
			if (isset($_POST['categoriaLista10'])) {
				$catPreenchida = true;
				$catvalor10 = true;
			}

			if ($catPreenchida == true) {
				if (($_POST['quantidade1'] != "") && (!isset($_POST['uniLista1']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade1'] == "") && (isset($_POST['uniLista1']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade2'] != "") && (!isset($_POST['uniLista2']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade2'] == "") && (isset($_POST['uniLista2']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade3'] != "") && (!isset($_POST['uniLista3']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade3'] == "") && (isset($_POST['uniLista3']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade4'] != "") && (!isset($_POST['uniLista4']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade4'] == "") && (isset($_POST['uniLista4']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade5'] != "") && (!isset($_POST['uniLista5']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade5'] == "") && (isset($_POST['uniLista5']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade6'] != "") && (!isset($_POST['uniLista6']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade6'] == "") && (isset($_POST['uniLista6']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade7'] != "") && (!isset($_POST['uniLista7']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade7'] == "") && (isset($_POST['uniLista7']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade8'] != "") && (!isset($_POST['uniLista8']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade8'] == "") && (isset($_POST['uniLista8']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade9'] != "") && (!isset($_POST['uniLista9']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade9'] == "") && (isset($_POST['uniLista9']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade10'] != "") && (!isset($_POST['uniLista10']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('CadastroVulner','refresh');
				}
				else if (($_POST['quantidade10'] == "") && (isset($_POST['uniLista10']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('CadastroVulner','refresh');
				}


				else {
					if (!$baicid) {

						if ($cid == 0) {
							$this->cadastrarVulner->nome_cidade = $cidade;
							$this->cadastrarVulner->sigla_estado = $estado;
							$this->cadastrarVulner->inserirCidade();

							$cid = ($this->cadastrarVulner->selecionarIDCidade($cidade))[0]->id_cidade;
						}

						$this->cadastrarVulner->nome_bairro = $bairro;
						$this->cadastrarVulner->id_cidade = $cid;
						$this->cadastrarVulner->inserirBairroCidade();



						$baicid = ($this->cadastrarVulner->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

						$id_user = $this->session->userdata('id_usuario');

						$this->cadastrarVulner->visivel = $vis;
						$this->cadastrarVulner->telefone_vulner = $numTelefone;
						$this->cadastrarVulner->titulo_vulner = $titulo;
						$this->cadastrarVulner->data_vulner = $data;
						$this->cadastrarVulner->horario_vulner = $horario;
						$this->cadastrarVulner->descricao_vulner = $descricao;
						$this->cadastrarVulner->numero_rua_vulner = $numRua;
						$this->cadastrarVulner->nome_rua_vulner = $nomeRua;
						$this->cadastrarVulner->cep_vulner = $cep;
						$this->cadastrarVulner->id_usuario = $id_user;
						$this->cadastrarVulner->id_bairro_cidade = $baicid;
						$this->cadastrarVulner->inserirVulner();

						$vulnerid = ($this->cadastrarVulner->selecionarIDVulner($horario, $id_user, $data))[0]->id_vulner;


						$aux1 = false;
						$ax3 = 0;
						while ($aux1 == false) {
							$ax1 = true;
							$ax2 = true;
							$us = ($this->cadastrarVulner->selecionarAvaUsuarioRand($ax1, $ax2, $id_user));

							if (!empty($us)) {
								$us = ($this->cadastrarVulner->selecionarAvaUsuarioRand($ax1, $ax2, $id_user))[0]->id_usuario;

								$bcava = ($this->cadastrarVulner->selecionarLocalAva($us))[0]->id_bairro_cidade;

								$cidava = ($this->cadastrarVulner->selecionarLocalCidade($bcava))[0]->id_cidade;

								if ($cidava == $cid) {
									$this->cadastrarVulner->avaliada = false;
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_avaliador = $us;
									$this->cadastrarVulner->inserirAvaliacao();

									$aux1 = true;
								} else {
									$aux1 = false;
									$ax3++;

									if ($ax3 == 3) {
										$this->cadastrarVulner->deletarItemVulner($vulnerid);
										$this->cadastrarVulner->deletarImagemVulner($vulnerid);
										$this->cadastrarVulner->deletarVulner($vulnerid);
										break;
									}
								}
							} else {
								$this->cadastrarVulner->deletarItemVulner($vulnerid);
								$this->cadastrarVulner->deletarImagemVulner($vulnerid);
								$this->cadastrarVulner->deletarVulner($vulnerid);
								$aux1 = false;
								break;
							}
						}

						if ($aux1 != false) {
							if (!empty($_FILES['imgb1']['name'])) {
								$img1 = time().$_FILES['imgb1']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb1']['tmp_name'], $diretorio.$img1);

								$this->cadastrarVulner->nome_img_vulner = $img1;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb2']['name'])) {
								$img2 = time().$_FILES['imgb2']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb2']['tmp_name'], $diretorio.$img2);

								$this->cadastrarVulner->nome_img_vulner = $img2;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb3']['name'])) {
								$img3 = time().$_FILES['imgb3']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb3']['tmp_name'], $diretorio.$img3);

								$this->cadastrarVulner->nome_img_vulner = $img3;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb4']['name'])) {
								$img4 = time().$_FILES['imgb4']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb4']['tmp_name'], $diretorio.$img4);

								$this->cadastrarVulner->nome_img_vulner = $img4;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb5']['name'])) {
								$img5 = time().$_FILES['imgb5']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb5']['tmp_name'], $diretorio.$img5);

								$this->cadastrarVulner->nome_img_vulner = $img5;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}

							if ($catvalor1 == true) {
								if (($_POST['quantidade1'] != "") && (isset($_POST['uniLista1']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista1'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade1']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista1'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade1'] == "") && (!isset($_POST['uniLista1']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista1'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor2 == true) {
								if (($_POST['quantidade2'] != "") && (isset($_POST['uniLista2']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista2'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade2']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista2'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade2'] == "") && (!isset($_POST['uniLista2']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista2'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor3 == true) {
								if (($_POST['quantidade3'] != "") && (isset($_POST['uniLista3']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista3'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade3']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista3'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade3'] == "") && (!isset($_POST['uniLista3']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista3'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor4 == true) {
								if (($_POST['quantidade4'] != "") && (isset($_POST['uniLista4']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista4'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade4']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista4'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade4'] == "") && (!isset($_POST['uniLista4']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista4'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor5 == true) {
								if (($_POST['quantidade5'] != "") && (isset($_POST['uniLista5']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista5'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade5']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista5'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade5'] == "") && (!isset($_POST['uniLista5']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista5'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor6 == true) {
								if (($_POST['quantidade6'] != "") && (isset($_POST['uniLista6']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista6'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade6']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista6'];
									$this->cadastrarVulner->inserirVulnerItem();


								}
								
								if (($_POST['quantidade6'] == "") && (!isset($_POST['uniLista6']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista6'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor7 == true) {
								if (($_POST['quantidade7'] != "") && (isset($_POST['uniLista7']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista7'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade7']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista7'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade7'] == "") && (!isset($_POST['uniLista7']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista7'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor8 == true) {
								if (($_POST['quantidade8'] != "") && (isset($_POST['uniLista8']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista8'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade8']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista8'];
									$this->cadastrarVulner->inserirVulnerItem();
								}
								
								if (($_POST['quantidade8'] == "") && (!isset($_POST['uniLista8']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista8'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor9 == true) {
								if (($_POST['quantidade9'] != "") && (isset($_POST['uniLista9']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista9'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade9']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista9'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade9'] == "") && (!isset($_POST['uniLista9']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista9'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor10 == true) {
								if (($_POST['quantidade10'] != "") && (isset($_POST['uniLista10']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista10'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade10']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista10'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade10'] == "") && (!isset($_POST['uniLista10']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista10'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							$infusuario['lista1'] = ($this->cadastrarVulner->selecionarAvaDados($us));

							foreach ($infusuario as $li => $l) {
								foreach ($l as $li => $list) {

									if ($list->id_bairro_cidade) {
										$inflocal['lista2'] = ($this->cadastrarVulner->selecionarLocal($list->id_bairro_cidade));
									}

								}
							}

							foreach ($inflocal as $li2 => $l2) {
								foreach ($l2 as $li2 => $list2) {

									if ($list2->id_cidade) {
										$cidade = ($this->cadastrarVulner->selecionarCidade($list2->id_cidade));
									}
								}
							}

							$dados = array('infusuario' => $infusuario, 'bairro' => $inflocal,'cidade' => $cidade);
							$this->session->set_flashdata('vulner_cadastrada','A situação de vulnerabilidade social foi cadastrada com sucesso! Abaixo estão as informações sobre o seu avaliador');
							$this->load->view('dadosAvaliador', $dados);

						} else {
							$this->session->set_flashdata('avaliador_inexistente','Não há nenhum avaliador disponível neste momento. Tente cadastrar a situação de vulnerabilidade social mais tarde');
							redirect('CadastroVulner','refresh');
						}

					} else {
						$baicid = ($this->cadastrarVulner->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

						$id_user = $this->session->userdata('id_usuario');

						$this->cadastrarVulner->visivel = $vis;
						$this->cadastrarVulner->telefone_vulner = $numTelefone;
						$this->cadastrarVulner->titulo_vulner = $titulo;
						$this->cadastrarVulner->data_vulner = $data;
						$this->cadastrarVulner->horario_vulner = $horario;
						$this->cadastrarVulner->descricao_vulner = $descricao;
						$this->cadastrarVulner->numero_rua_vulner = $numRua;
						$this->cadastrarVulner->nome_rua_vulner = $nomeRua;
						$this->cadastrarVulner->cep_vulner = $cep;
						$this->cadastrarVulner->id_usuario = $id_user;
						$this->cadastrarVulner->id_bairro_cidade = $baicid;
						$this->cadastrarVulner->inserirVulner();

						$vulnerid = ($this->cadastrarVulner->selecionarIDVulner($horario, $id_user, $data))[0]->id_vulner;


						$aux1 = false;
						$ax3 = 0;
						while ($aux1 == false) {
							$ax1 = true;
							$ax2 = true;
							$us = ($this->cadastrarVulner->selecionarAvaUsuarioRand($ax1, $ax2, $id_user));

							if (!empty($us)) {
								$us = ($this->cadastrarVulner->selecionarAvaUsuarioRand($ax1, $ax2, $id_user))[0]->id_usuario;

								$bcava = ($this->cadastrarVulner->selecionarLocalAva($us))[0]->id_bairro_cidade;

								$cidava = ($this->cadastrarVulner->selecionarLocalCidade($bcava))[0]->id_cidade;	

								if ($cidava == $cid) {
									$this->cadastrarVulner->avaliada = false;
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_avaliador = $us;
									$this->cadastrarVulner->inserirAvaliacao();

									$aux1 = true;
								} else {
									$aux1 = false;
									$ax3++;

									if ($ax3 == 3) {
										$this->cadastrarVulner->deletarItemVulner($vulnerid);
										$this->cadastrarVulner->deletarImagemVulner($vulnerid);
										$this->cadastrarVulner->deletarVulner($vulnerid);
										break;
									}
								}
							} else {
								$this->cadastrarVulner->deletarItemVulner($vulnerid);
								$this->cadastrarVulner->deletarImagemVulner($vulnerid);
								$this->cadastrarVulner->deletarVulner($vulnerid);
								$aux1 = false;
								break;
							}
						}

						if ($aux1 != false) {
							if (!empty($_FILES['imgb1']['name'])) {
								$img1 = time().$_FILES['imgb1']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb1']['tmp_name'], $diretorio.$img1);

								$this->cadastrarVulner->nome_img_vulner = $img1;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb2']['name'])) {
								$img2 = time().$_FILES['imgb2']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb2']['tmp_name'], $diretorio.$img2);

								$this->cadastrarVulner->nome_img_vulner = $img2;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb3']['name'])) {
								$img3 = time().$_FILES['imgb3']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb3']['tmp_name'], $diretorio.$img3);

								$this->cadastrarVulner->nome_img_vulner = $img3;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb4']['name'])) {
								$img4 = time().$_FILES['imgb4']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb4']['tmp_name'], $diretorio.$img4);

								$this->cadastrarVulner->nome_img_vulner = $img4;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}
							if (!empty($_FILES['imgb5']['name'])) {
								$img5 = time().$_FILES['imgb5']['name'];
								$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
								move_uploaded_file($_FILES['imgb5']['tmp_name'], $diretorio.$img5);

								$this->cadastrarVulner->nome_img_vulner = $img5;
								$this->cadastrarVulner->id_vulner = $vulnerid;
								$this->cadastrarVulner->inserirVulnerImagem();
							}

							if ($catvalor1 == true) {
								if (($_POST['quantidade1'] != "") && (isset($_POST['uniLista1']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista1'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade1']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista1'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade1'] == "") && (!isset($_POST['uniLista1']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista1'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor2 == true) {
								if (($_POST['quantidade2'] != "") && (isset($_POST['uniLista2']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista2'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade2']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista2'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade2'] == "") && (!isset($_POST['uniLista2']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista2'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor3 == true) {
								if (($_POST['quantidade3'] != "") && (isset($_POST['uniLista3']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista3'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade3']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista3'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade3'] == "") && (!isset($_POST['uniLista3']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista3'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();
								}
							}

							if ($catvalor4 == true) {
								if (($_POST['quantidade4'] != "") && (isset($_POST['uniLista4']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista4'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade4']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista4'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade4'] == "") && (!isset($_POST['uniLista4']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista4'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor5 == true) {
								if (($_POST['quantidade5'] != "") && (isset($_POST['uniLista5']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista5'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade5']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista5'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade5'] == "") && (!isset($_POST['uniLista5']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista5'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor6 == true) {
								if (($_POST['quantidade6'] != "") && (isset($_POST['uniLista6']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista6'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade6']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista6'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade6'] == "") && (!isset($_POST['uniLista6']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista6'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor7 == true) {
								if (($_POST['quantidade7'] != "") && (isset($_POST['uniLista7']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista7'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade7']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista7'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade7'] == "") && (!isset($_POST['uniLista7']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista7'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor8 == true) {
								if (($_POST['quantidade8'] != "") && (isset($_POST['uniLista8']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista8'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade8']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista8'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade8'] == "") && (!isset($_POST['uniLista8']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista8'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor9 == true) {
								if (($_POST['quantidade9'] != "") && (isset($_POST['uniLista9']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista9'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade9']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista9'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade9'] == "") && (!isset($_POST['uniLista9']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista9'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}

							if ($catvalor10 == true) {
								if (($_POST['quantidade10'] != "") && (isset($_POST['uniLista10']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista10'];
									$this->cadastrarVulner->quantidade_vulner = trim($_POST['quantidade10']);
									$this->cadastrarVulner->id_unidade = $_POST['uniLista10'];
									$this->cadastrarVulner->inserirVulnerItem();

								}
								
								if (($_POST['quantidade10'] == "") && (!isset($_POST['uniLista10']))) {
									$this->cadastrarVulner->id_vulner = $vulnerid;
									$this->cadastrarVulner->id_categoria = $_POST['categoriaLista10'];
									$this->cadastrarVulner->quantidade_vulner = null;
									$this->cadastrarVulner->id_unidade = null;
									$this->cadastrarVulner->inserirVulnerItem();

								}
							}


							$infusuario['lista1'] = ($this->cadastrarVulner->selecionarAvaDados($us));

							foreach ($infusuario as $li => $l) {
								foreach ($l as $li => $list) {

									if ($list->id_bairro_cidade) {
										$inflocal['lista2'] = ($this->cadastrarVulner->selecionarLocal($list->id_bairro_cidade));
									}

								}
							}

							foreach ($inflocal as $li2 => $l2) {
								foreach ($l2 as $li2 => $list2) {

									if ($list2->id_cidade) {
										$cidade = ($this->cadastrarVulner->selecionarCidade($list2->id_cidade));
									}
								}
							}

							$dados = array('infusuario' => $infusuario, 'bairro' => $inflocal,'cidade' => $cidade);
							$this->session->set_flashdata('vulner_cadastrada','A situação de vulnerabilidade social foi cadastrada com sucesso! Abaixo estão as informações sobre o seu avaliador');
							$this->load->view('dadosAvaliador', $dados);

						} else {
							$this->session->set_flashdata('avaliador_inexistente','Não há nenhum avaliador disponível neste momento. Tente cadastrar a situação de vulnerabilidade social mais tarde');
							redirect('CadastroVulner','refresh');
						}
					}
				}


			} else {
				$this->session->set_flashdata('categoria_inexistente','Selecione pelo menos uma categoria');
				redirect('CadastroVulner','refresh');
			}

		} else {
			$this->session->set_flashdata('erro_form', 'Erro de validação no formulário, tente de novo');
			redirect('CadastroVulner','refresh');
		}

	}

}