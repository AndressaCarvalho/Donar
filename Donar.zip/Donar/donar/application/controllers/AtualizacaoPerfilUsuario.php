<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AtualizacaoPerfilUsuario extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->form_validation->set_rules('nome', 'Nome', 'required|max_length[40]|min_length[2]|trim|alpha');
			$this->form_validation->set_rules('sobrenome', 'Sobrenome', 'required|max_length[60]|min_length[2]|trim|alpha');
			$this->form_validation->set_rules('email', 'Email', 'required|max_length[254]|min_length[7]|trim|valid_email');
			$this->form_validation->set_rules('numTelefone', 'Número de telefone', 'required|max_length[13]|min_length[13]|trim');
	        $this->form_validation->set_rules('senha', 'Senha', 'max_length[12]|min_length[6]');
	        $this->form_validation->set_rules('confirmarSenha', 'Confirmar a senha', 'max_length[12]|min_length[6]|matches[senha]');
	        $this->form_validation->set_rules('numRua', 'Número da casa', 'required|max_length[5]|min_length[1]|trim');
	        $this->form_validation->set_rules('cep', 'CEP', 'required|max_length[9]|min_length[9]|trim');
	        $this->form_validation->set_rules('rua', 'Rua', 'required|max_length[100]');
	        $this->form_validation->set_rules('bairro', 'Bairro', 'required|max_length[100]');
	        $this->form_validation->set_rules('cidade', 'Cidade', 'required|max_length[200]');
	        $this->form_validation->set_rules('uf', 'Estado', 'required|max_length[2]');

	        if ($this->form_validation->run() == TRUE) {

				$estado = $_POST['uf'];
				$cidade = $_POST['cidade'];
				$bairro = $_POST['bairro'];

				if (!empty($_FILES['imgb1']['name'])) {
					$imgPerfil1 = time().$_FILES['imgb1']['name'];
					$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
					$imgPerfil2 = $diretorio.$imgPerfil1;
					move_uploaded_file($_FILES['imgb1']['tmp_name'], $diretorio.$imgPerfil1);
				} else {
					$imgPerfil1 = '';
					$imgPerfil2 = '';
				}

				$email = trim($_POST['email']);
				$primeiroNome = trim($_POST['nome']);
				$sobrenome1 = trim($_POST['sobrenome']);
				$sobrenome2 = str_replace(' ', '.', $sobrenome1);
				$nome = $primeiroNome.' '.$sobrenome2;
				$numTelefone = $_POST['numTelefone'];

				if (!empty($_POST['senha'])) {
					$senha = md5($_POST['senha']);
				} else {
					$senha = '';
				}
				
				$numRua = trim($_POST['numRua']);
				$cep = $_POST['cep'];
				$nomeRua = $_POST['rua'];

				if (!empty($senha)) {
					$dados = array('img1' => $imgPerfil1,'img2' => $imgPerfil2, 'nome' => $nome, 'email' => $email, 'telefone' => $numTelefone, 'nome_rua' => $nomeRua, 'numero_rua' => $numRua, 'cep' => $cep, 'bairro' => $bairro, 'cidade' => $cidade, 'estado' => $estado, 'senha' => $senha);

					$this->load->view('confirmarSenhaUsuario1', $dados);
				} else {
					$dados = array('img1' => $imgPerfil1,'img2' => $imgPerfil2, 'nome' => $nome, 'email' => $email, 'telefone' => $numTelefone, 'nome_rua' => $nomeRua, 'numero_rua' => $numRua, 'cep' => $cep, 'bairro' => $bairro, 'cidade' => $cidade, 'estado' => $estado);

					$this->load->view('confirmarSenhaUsuario2', $dados);
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no formulário, tente de novo');
				redirect('ListagemPerfilUsuario','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}


	public function atualizarPerfilUsuarioCSenha() {
		if ($this->session->userdata('id_usuario')) {
			$this->form_validation->set_rules('senhaa', 'Senha', 'required|max_length[12]|min_length[6]');

			if ($this->form_validation->run() == TRUE) {

				$this->load->model('atualizarPerfilUsuario');

				$senhaa = md5($_POST['senhaa']);
				$usuario = $this->session->userdata('id_usuario');

				$eusuario = ($this->atualizarPerfilUsuario->selecionarPorSenha($usuario, $senhaa));

				if ($eusuario) {
					$estado = $_POST['estado'];
					$cidade = $_POST['cidade'];
					$bairro = $_POST['bairro'];
					$senha = $_POST['senha'];

					$img = $_POST['img1'];

					$email = $_POST['email'];
					$nome = $_POST['nome'];
					$numTelefone = $_POST['telefone'];
					$numRua = $_POST['numero_rua'];
					$cep = $_POST['cep'];
					$nomeRua = $_POST['nome_rua'];


					$cid = ($this->atualizarPerfilUsuario->selecionarIDCidade($cidade));
					if ($cid) {
						$cid = ($this->atualizarPerfilUsuario->selecionarIDCidade($cidade))[0]->id_cidade;
					} else {
						$cid = 0;
					}

					
					$baicid = ($this->atualizarPerfilUsuario->selecionarIDBairroCidade($bairro, $cid));


					if (!$baicid) {


						if ($cid == 0) {
							$this->atualizarPerfilUsuario->nome_cidade = $cidade;
							$this->atualizarPerfilUsuario->sigla_estado = $estado;
							$this->atualizarPerfilUsuario->inserirCidade();

							$cid = ($this->atualizarPerfilUsuario->selecionarIDCidade($cidade))[0]->id_cidade;
						}

						$this->atualizarPerfilUsuario->nome_bairro = $bairro;
						$this->atualizarPerfilUsuario->id_cidade = $cid;
						$this->atualizarPerfilUsuario->inserirBairroCidade();



						$baicid = ($this->atualizarPerfilUsuario->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

						if (!empty($img)) {
							$this->atualizarPerfilUsuario->atualizarUsuario1($usuario, $img, $email, $nome, $senha, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						} else {
							$this->atualizarPerfilUsuario->atualizarUsuario2($usuario, $email, $nome, $senha, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						}

						$this->session->set_flashdata('usuario_atualizado', 'A atualização do usuário foi realizada com sucesso');
						redirect('ListagemPerfilUsuario','refresh');

					} else {
						$baicid = ($this->atualizarPerfilUsuario->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

						if (!empty($img)) {
							$this->atualizarPerfilUsuario->atualizarUsuario1($usuario, $img, $email, $nome, $senha, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						} else {
							$this->atualizarPerfilUsuario->atualizarUsuario2($usuario, $email, $nome, $senha, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						}

						$this->session->set_flashdata('usuario_atualizado', 'A atualização do usuário foi realizada com sucesso');
						redirect('ListagemPerfilUsuario','refresh');
					}
					
				} else {
					$img = $_POST['img2'];
					unlink($img);
					$this->session->set_flashdata('senha_erradaa1', 'A senha inserida está errada');
					redirect('ListagemPerfilUsuario','refresh');
				}
			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Senha, tente de novo');
				redirect('ListagemPerfilUsuario','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}


	public function atualizarPerfilUsuarioSSenha() {
		if ($this->session->userdata('id_usuario')) {
			$this->form_validation->set_rules('senhaa', 'Senha', 'required|max_length[12]|min_length[6]');

			if ($this->form_validation->run() == TRUE) {
				$this->load->model('atualizarPerfilUsuario');

				$senhaa = md5($_POST['senhaa']);
				$usuario = $this->session->userdata('id_usuario');

				$eusuario = ($this->atualizarPerfilUsuario->selecionarPorSenha($usuario, $senhaa));

				if ($eusuario) {
					$estado = $_POST['estado'];
					$cidade = $_POST['cidade'];
					$bairro = $_POST['bairro'];

					$img = $_POST['img1'];

					$email = $_POST['email'];
					$nome = $_POST['nome'];
					$numTelefone = $_POST['telefone'];
					$numRua = $_POST['numero_rua'];
					$cep = $_POST['cep'];
					$nomeRua = $_POST['nome_rua'];


					$cid = ($this->atualizarPerfilUsuario->selecionarIDCidade($cidade));
					if ($cid) {
						$cid = ($this->atualizarPerfilUsuario->selecionarIDCidade($cidade))[0]->id_cidade;
					} else {
						$cid = 0;
					}

					
					$baicid = ($this->atualizarPerfilUsuario->selecionarIDBairroCidade($bairro, $cid));


					if (!$baicid) {

						if ($cid == 0) {
							$this->atualizarPerfilUsuario->nome_cidade = $cidade;
							$this->atualizarPerfilUsuario->sigla_estado = $estado;
							$this->atualizarPerfilUsuario->inserirCidade();

							$cid = ($this->atualizarPerfilUsuario->selecionarIDCidade($cidade))[0]->id_cidade;
						}

						$this->atualizarPerfilUsuario->nome_bairro = $bairro;
						$this->atualizarPerfilUsuario->id_cidade = $cid;
						$this->atualizarPerfilUsuario->inserirBairroCidade();



						$baicid = ($this->atualizarPerfilUsuario->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

						if (!empty($img)) {
							$this->atualizarPerfilUsuario->atualizarUsuario3($usuario, $img, $email, $nome, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						} else {
							$this->atualizarPerfilUsuario->atualizarUsuario4($usuario, $email, $nome, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						}

						$this->session->set_flashdata('usuario_atualizado', 'A atualização do usuário foi realizada com sucesso');
						redirect('ListagemPerfilUsuario','refresh');

					} else {
						$baicid = ($this->atualizarPerfilUsuario->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

						if (!empty($img)) {
							$this->atualizarPerfilUsuario->atualizarUsuario3($usuario, $img, $email, $nome, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						} else {
							$this->atualizarPerfilUsuario->atualizarUsuario4($usuario, $email, $nome, $numTelefone, $numRua, $nomeRua, $cep, $baicid);
						}

						$this->session->set_flashdata('usuario_atualizado', 'A atualização do usuário foi realizada com sucesso');
						redirect('ListagemPerfilUsuario','refresh');
					}
					
				} else {
					$img = $_POST['img2'];
					unlink($img);
					$this->session->set_flashdata('senha_erradaa1', 'A senha inserida está errada');
					redirect('ListagemPerfilUsuario','refresh');
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Senha, tente de novo');
				redirect('ListagemPerfilUsuario','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}

}