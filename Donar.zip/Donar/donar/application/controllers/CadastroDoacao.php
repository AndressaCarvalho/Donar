<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CadastroDoacao extends CI_Controller {

	public function cadastrarDoacao() {
		
		$this->form_validation->set_rules('quantidade', 'Quantidade', 'numeric|max_length[5]|trim');
		if ($this->form_validation->run() == TRUE) {
			
			$this->load->model('cadastrarDoacao');

			$vulner = $_POST['vulner'];
			$usuario = $this->session->userdata('id_usuario');
			date_default_timezone_set('America/Sao_Paulo');
			$data = date('Y-m-d');
			$horario = date('H:i:s');

			$catPreenchida = false;
			if (isset($_POST['categoriaLista'])) {
				$catPreenchida = true;
			}

			if ($catPreenchida == true) {
				if (($_POST['quantidade'] != "") && (!isset($_POST['uniLista']))) {
					$this->session->set_flashdata('unidade_inexistente','Selecione a unidade');
					redirect('ListagemVulner','refresh');
				}
				else if (($_POST['quantidade'] == "") && (isset($_POST['uniLista']))) {
					$this->session->set_flashdata('quantidade_inexistente','A quantidade deve ser preenchida');
					redirect('ListagemVulner','refresh');
				}
				else {
					$this->cadastrarDoacao->id_usuario = $usuario;
					$this->cadastrarDoacao->data_doacao = $data;
					$this->cadastrarDoacao->horario_doacao = $horario;
					$this->cadastrarDoacao->inserirDoacao();

					$doacaoid = ($this->cadastrarDoacao->selecionarIDDoacao($horario, $usuario, $data))[0]->id_doacao;

					if (!empty($_FILES['imgb1']['name'])) {
						$img1 = time().$_FILES['imgb1']['name'];
						$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
						move_uploaded_file($_FILES['imgb1']['tmp_name'], $diretorio.$img1);

						$this->cadastrarDoacao->nome_img_doacao = $img1;
						$this->cadastrarDoacao->id_doacao = $doacaoid;
						$this->cadastrarDoacao->inserirDoacaoImagem();
					}
					if (!empty($_FILES['imgb2']['name'])) {
						$img2 = time().$_FILES['imgb2']['name'];
						$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
						move_uploaded_file($_FILES['imgb2']['tmp_name'], $diretorio.$img2);

						$this->cadastrarDoacao->nome_img_doacao = $img2;
						$this->cadastrarDoacao->id_doacao = $doacaoid;
						$this->cadastrarDoacao->inserirDoacaoImagem();
					}
					if (!empty($_FILES['imgb3']['name'])) {
						$img3 = time().$_FILES['imgb3']['name'];
						$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
						move_uploaded_file($_FILES['imgb3']['tmp_name'], $diretorio.$img3);

						$this->cadastrarDoacao->nome_img_doacao = $img3;
						$this->cadastrarDoacao->id_doacao = $doacaoid;
						$this->cadastrarDoacao->inserirDoacaoImagem();
					}
					if (!empty($_FILES['imgb4']['name'])) {
						$img4 = time().$_FILES['imgb4']['name'];
						$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
						move_uploaded_file($_FILES['imgb4']['tmp_name'], $diretorio.$img4);

						$this->cadastrarDoacao->nome_img_doacao = $img4;
						$this->cadastrarDoacao->id_doacao = $doacaoid;
						$this->cadastrarDoacao->inserirDoacaoImagem();
					}
					if (!empty($_FILES['imgb5']['name'])) {
						$img5 = time().$_FILES['imgb5']['name'];
						$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
						move_uploaded_file($_FILES['imgb5']['tmp_name'], $diretorio.$img5);

						$this->cadastrarDoacao->nome_img_doacao = $img5;
						$this->cadastrarDoacao->id_doacao = $doacaoid;
						$this->cadastrarDoacao->inserirDoacaoImagem();
					}


					if (($_POST['quantidade'] != "") && (isset($_POST['uniLista']))) {
						$this->cadastrarDoacao->id_doacao = $doacaoid;
						$this->cadastrarDoacao->id_categoria = $_POST['categoriaLista'];
						$this->cadastrarDoacao->quantidade_doacao = trim($_POST['quantidade']);
						$this->cadastrarDoacao->id_unidade = $_POST['uniLista'];
						$this->cadastrarDoacao->inserirDoacaoItem();

					}
					
					if (($_POST['quantidade'] == "") && (!isset($_POST['uniLista']))) {
						$this->cadastrarDoacao->id_doacao = $doacaoid;
						$this->cadastrarDoacao->id_categoria = $_POST['categoriaLista'];
						$this->cadastrarDoacao->quantidade_doacao = null;
						$this->cadastrarDoacao->id_unidade = null;
						$this->cadastrarDoacao->inserirDoacaoItem();

					}


					$this->cadastrarDoacao->id_vulner = $vulner;
					$this->cadastrarDoacao->id_doacao = $doacaoid;
					$this->cadastrarDoacao->doado_doador = 'P';
					$this->cadastrarDoacao->doado_receptor = 'P';
					$this->cadastrarDoacao->descricao_rejeicao_receptor = null;
					$this->cadastrarDoacao->data_confirmacao_doacao = null;
					$this->cadastrarDoacao->horario_confirmacao_doacao = null;
					$this->cadastrarDoacao->inserirVulnerDoacao();

					$infvulner['lista1'] = ($this->cadastrarDoacao->selecionarVulner($vulner));

					foreach ($infvulner as $li => $l) {
						foreach ($l as $li => $list) {
							if ($list->id_usuario) {
								$infusuario['lista2'] = ($this->cadastrarDoacao->selecionarUsuario($list->id_usuario));
							}

							if ($list->id_bairro_cidade) {
								$inflocal['lista3'] = ($this->cadastrarDoacao->selecionarLocal($list->id_bairro_cidade));
							}	
						}
					}

					foreach ($inflocal as $li2 => $l2) {
						foreach ($l2 as $li2 => $list2) {

							if ($list2->id_cidade) {
								$cidade['lista5'] = ($this->cadastrarDoacao->selecionarCidade($list2->id_cidade));
							}
						}
					}

					$dados = array('infusuario' => $infusuario, 'infvulner' => $infvulner, 'bairro' => $inflocal,'cidade' => $cidade);
					$this->load->view('dadosReceptorDoacao', $dados);

					$this->session->set_flashdata('doacao_cadastrada','A doação foi cadastrada com sucesso! Abaixo estão os dados do receptor');

				}

			} else {
				$this->session->set_flashdata('categoria_inexistente','Selecione pelo menos uma categoria');
				redirect('ListagemVulner','refresh');
			}

		} else {
			$this->session->set_flashdata('erro_form', 'Erro de validação no campo Quantidade, tente de novo');
			redirect('ListagemVulner','refresh');
		}
	}

}