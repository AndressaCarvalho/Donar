<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemVulnerDenunciada extends CI_Controller {

	public function index()
	{
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->model('listarVulnerDenunciada');

			$aval = false;
			$vulner['lista1'] = ($this->listarVulnerDenunciada->selecionarVulner1($aval));

			if (!empty($vulner['lista1'])) {
				
				$imagem2['lista2'] = array();
				foreach ($vulner as $li => $l) {
          			foreach ($l as $lis => $list) {

          				if ($list->id_vulner) {
          					$imagem1 = ($this->listarVulnerDenunciada->selecionarImagemVulner1($list->id_vulner));

          					if (!empty($imagem1)) {
          						$imagem1 = ($this->listarVulnerDenunciada->selecionarImagemVulner1($list->id_vulner))[0];
          						array_push($imagem2['lista2'], $imagem1);
          					}

          				}

					}
				}

				$vulner2['lista3'] = array();
          		foreach ($vulner as $li2 => $l2) {
          			foreach ($l2 as $lis2 => $list2) {
          				
          				if ($list->id_vulner) {
          					$vulner3 = ($this->listarVulnerDenunciada->selecionarVulner2($list2->id_vulner));

          					if (!empty($vulner3)) {
          						$vulner3 = ($this->listarVulnerDenunciada->selecionarVulner2($list2->id_vulner))[0];
          						array_push($vulner2['lista3'], $vulner3);
          					}
          				}

          			}
          		}


          		$dados = array('vulners2' => $vulner2, 'imgs' => $imagem2, 'vulners1' => $vulner);
				$this->load->view('listagemVulnerDenunciada', $dados);

			} else {
				$this->session->set_userdata('retorno_inexistente8', 'Não há nenhuma situação de vulnerabilidade social denunciada');
				$this->load->view('listagemVulnerDenunciada');
			}

		} else {
			redirect('Donar','refresh');
		}

	}


	public function detalhesVulnerDenunciada() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			if ($_POST['vulner']) {
				$this->load->model('listarVulnerDenunciada');

				$vulner = $_POST['vulner'];
				$denuncia = $_POST['denunciavulner'];

				$vuln['lista12'] = $_POST['vulner'];

				//Para denúncia
				$denun['lista16'] = ($this->listarVulnerDenunciada->selecionarDenuncia($denuncia));

				foreach ($denun as $li8 => $l8) {
				    foreach ($l8 as $lis8 => $list8) {

				    	if ($list8->id_motivacao) {
				    		$motivacao['lista12'] = ($this->listarVulnerDenunciada->selecionarMotivacao($list8->id_motivacao));
				    	}

				    }
				}

				//Para a situação de vulnerabilidade social
				$vul['lista1'] = ($this->listarVulnerDenunciada->selecionarVulner3($vulner));

				$imagemv['lista2'] = ($this->listarVulnerDenunciada->selecionarImagemVulner($vulner));

				foreach ($vul as $li => $l) {
				    foreach ($l as $lis => $list) {

				    	if ($list->id_bairro_cidade) {
				    		$idbaicidv['lista3'] = ($this->listarVulnerDenunciada->selecionarLocal($list->id_bairro_cidade));
				    	}

				    }
				}

				foreach ($idbaicidv as $li2 => $l2) {
				    foreach ($l2 as $lis2 => $list2) {

				    	if ($list2->id_cidade) {
				    		$idcidv['lista5'] = ($this->listarVulnerDenunciada->selecionarCidade($list2->id_cidade));
				    	}

				    }
				}

				$itemv['lista6'] = ($this->listarVulnerDenunciada->selecionarVulnerItem($vulner));

				$categoriav['lista7'] = array();
				$unidadev['lista8'] = array();
				foreach ($itemv as $li3 => $l3) {
				    foreach ($l3 as $lis3 => $list3) {

				    	if ($list3->id_categoria) {
				    		$cat = ($this->listarVulnerDenunciada->selecionarCategoria($list3->id_categoria))[0];
				    		array_push($categoriav['lista7'], $cat);
				    	}

				    	if ($list3->id_unidade) {
				    		$uni = ($this->listarVulnerDenunciada->selecionarUnidade($list3->id_unidade))[0];
				    		array_push($unidadev['lista8'], $uni);
				    	}

				    }
				}

				//Para o denunciado
				$infdenunciado['lista4'] = array();
				foreach ($vul as $li4 => $l4) {
				    foreach ($l4 as $lis4 => $list4) {

				    	if ($list4->id_usuario) {
				    		$infdenunciado2 = ($this->listarVulnerDenunciada->selecionarUsuario($list4->id_usuario))[0];
				    		array_push($infdenunciado['lista4'], $infdenunciado2);
				    	}

				    }
				}


				//Para o avaliador
				foreach ($vul as $li6 => $l6) {
				    foreach ($l6 as $lis6 => $list6) {

				    	if ($list6->id_vulner) {
				    		$avaliacao = ($this->listarVulnerDenunciada->selecionarAvaliacao($list6->id_vulner));
				    	}

				    }
				}

				$infavaliador['lista11'] = array();
				foreach ($avaliacao as $li7 => $list7) {
				    if ($list7->id_avaliador) {
				    	$infavaliador2 = ($this->listarVulnerDenunciada->selecionarUsuario($list7->id_avaliador))[0];
				    	array_push($infavaliador['lista11'], $infavaliador2);
				    }
				}


				//Para o denunciador
				$iddenun['lista9'] = ($this->listarVulnerDenunciada->selecionarDenunciador1($denuncia));

				$infdenunciador['lista10'] = array();
				foreach ($iddenun as $li5 => $l5) {
				    foreach ($l5 as $lis5 => $list5) {
				    	
				    	if ($list5->id_usuario) {
				    		$infdenunciador2 = ($this->listarVulnerDenunciada->selecionarUsuario($list5->id_usuario))[0];
				    		array_push($infdenunciador['lista10'], $infdenunciador2);
				    	}

				    }
				}

				$dados = array('vulner' => $vul, 'imagensv' => $imagemv,'bairro' => $idbaicidv, 'cidade' => $idcidv, 'itensv' => $itemv, 'categoriasv' => $categoriav, 'unidadesv' => $unidadev, 'infdenunciado' => $infdenunciado, 'infavaliador' => $infavaliador, 'infdenunciador' => $infdenunciador, 'denuncia' => $denun, 'vulner2' => $vuln, 'motivacao' => $motivacao);
				$this->load->view('detalhesVulnerDenunciada', $dados);

			} else {
				redirect('ListagemVulnerDenunciada','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}


	public function confirmarNegarDenunciaVulner() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			if ($_POST['usuario']) {
				$this->load->model('listarVulnerDenunciada');

				$usuario['lista1'] = $_POST['usuario'];
				$vulner['lista3'] = $_POST['vulner'];
				$avaliador['lista4'] = $_POST['avaliador'];
				$denuncia1 = $_POST['dvulner'];
				$denuncia2['lista2'] = $_POST['dvulner'];

				if (isset($_POST['nbusava'])) {
					$aux1 = true;

					$this->listarVulnerDenunciada->atualizarBanirUsuario($denuncia1, $aux1);

					$this->session->set_flashdata('usuario_nban', 'O usuário e o avaliador não foram banidos');	
					redirect('ListagemVulnerDenunciada','refresh');
				}

				if (isset($_POST['busava'])) {
					$this->load->model('banirUsuario');

					$motivos['lista3'] = ($this->banirUsuario->selecionarMotivo());

					$dados = array('denuncia' => $denuncia2, 'usuario' => $usuario, 'motivos' => $motivos, 'vulner' => $vulner, 'avaliador' => $avaliador);
					$this->load->view('banimentoUsuarioAvaliador', $dados);	
				}

			} else {
				redirect('ListagemVulnerCadastrada','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}