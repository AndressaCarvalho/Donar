<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BanimentoUsuario extends CI_Controller {

	public function banirDoador() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			
			$this->form_validation->set_rules('detalhamento', 'Detalhamento do motivo do banimento do usuário', 'required|min_length[15]|max_length[254]|trim');
			if ($this->form_validation->run() == TRUE) {
				$denuncia = $_POST['denuncia'];
				$usuario = $_POST['usuario'];
				$detalhamento = trim($_POST['detalhamento']);
				$motivo = $_POST['motivoLista'];

				if (!empty($motivo)) {
					$this->load->model('banirUsuario');

					$this->load->model('listarDoacaoDenunciada');

					$aux1 = true;
					$this->listarDoacaoDenunciada->atualizarBanirDoador($denuncia, $aux1);

					$aux2 = false;
					$this->banirUsuario->atualizarUsuario($usuario, $aux2);

					$this->listarDoacaoDenunciada->atualizarVulners($usuario, $aux2);


					date_default_timezone_set('America/Sao_Paulo');
					$data = date('Y-m-d');

					$this->banirUsuario->data_banido = $data;
					$this->banirUsuario->detalhamento_banido = $detalhamento;
					$this->banirUsuario->id_usuario = $usuario;
					$this->banirUsuario->id_motivo_banido = $motivo;
					$this->banirUsuario->banirUsuario();

					$this->session->set_flashdata('usuario_banido', 'O doador foi banido');
					redirect('ListagemDoacaoDenunciada','refresh');
				} else {
					$this->session->set_flashdata('motivo_inexistente', 'O motivo do banimento deve ser informado');
					redirect('ListagemDoacaoDenunciada','refresh');
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Detalhamento do motivo do banimento do usuário, tente de novo');
				redirect('ListagemDoacaoDenunciada','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}


	public function banirUsuarioAvaliador() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			
			$this->form_validation->set_rules('detalhamentous', 'Detalhamento do motivo do banimento do usuário', 'required|min_length[15]|max_length[254]|trim');
			$this->form_validation->set_rules('detalhamentoava', 'Detalhamento do motivo do banimento do avaliador', 'required|min_length[15]|max_length[254]|trim');
			if ($this->form_validation->run() == TRUE) {
				$denuncia = $_POST['denuncia'];
				$usuario = $_POST['usuario'];
				$avaliador = $_POST['avaliador'];
				$vulner = $_POST['vulner'];
				$detalhamentous = trim($_POST['detalhamentous']);
				$motivous = $_POST['motivoListaus'];
				$detalhamentoava = trim($_POST['detalhamentoava']);
				$motivoava = $_POST['motivoListaava'];

				if (!empty($motivous)) {
					if (!empty($motivoava)) {
						$this->load->model('banirUsuario');

						$this->load->model('listarVulnerDenunciada');

						$aux1 = true;
						$this->listarVulnerDenunciada->atualizarBanirUsuario($denuncia, $aux1);

						$aux2 = false;
						$this->listarVulnerDenunciada->atualizarVulner($vulner, $aux2);

						$this->listarVulnerDenunciada->atualizarVulners($usuario, $aux2);

						$this->listarVulnerDenunciada->atualizarVulners($avaliador, $aux2);


						$this->banirUsuario->atualizarUsuario($usuario, $aux2);

						$this->banirUsuario->atualizarUsuario($avaliador, $aux2);

						date_default_timezone_set('America/Sao_Paulo');
						$data = date('Y-m-d');

						$this->banirUsuario->data_banido = $data;
						$this->banirUsuario->detalhamento_banido = $detalhamentous;
						$this->banirUsuario->id_usuario = $usuario;
						$this->banirUsuario->id_motivo_banido = $motivous;
						$this->banirUsuario->banirUsuario();

						$this->banirUsuario->data_banido = $data;
						$this->banirUsuario->detalhamento_banido = $detalhamentoava;
						$this->banirUsuario->id_usuario = $avaliador;
						$this->banirUsuario->id_motivo_banido = $motivoava;
						$this->banirUsuario->banirUsuario();

						$this->session->set_flashdata('usuarios_banidos', 'O usuário que cadastrou a situação de vulnetrabilidade social, e o avaliador, foram banidos');
						redirect('ListagemVulnerDenunciada','refresh');

					} else {
						$this->session->set_flashdata('motivo_inexistente', 'O motivo do banimento do avaliador deve ser informado');
						redirect('ListagemVulnerDenunciada','refresh');
					}

				} else {
					$this->session->set_flashdata('motivo_inexistente', 'O motivo do banimento do usuário deve ser informado');
					redirect('ListagemVulnerDenunciada','refresh');
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Detalhamento do motivo do banimento do usuário e/ou no campo Detalhamento do motivo do banimento do avaliador, tente de novo');
				redirect('ListagemVulnerDenunciada','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}