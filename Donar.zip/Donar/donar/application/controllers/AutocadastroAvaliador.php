<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AutocadastroAvaliador extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->load->model('autocadastrarAvaliador');

			if ((!empty($_FILES['imgb1']['name'])) && (!empty($_FILES['imgb2']['name']))) {
				$img1 = time().$_FILES['imgb1']['name'];
				$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
				move_uploaded_file($_FILES['imgb1']['tmp_name'], $diretorio.$img1);

				$img2 = time().$_FILES['imgb2']['name'];
				$diretorio = "C:\\xampp\\htdocs\\donar\\upload_img\\";
				move_uploaded_file($_FILES['imgb2']['tmp_name'], $diretorio.$img2);


				$usuario = $this->session->userdata('id_usuario');
				date_default_timezone_set('America/Sao_Paulo');
				$data = date('Y-m-d');
				$horario = date('H:i:s');

				$this->autocadastrarAvaliador->id_usuario = $usuario;
				$this->autocadastrarAvaliador->nome_img_identidade = $img1;
				$this->autocadastrarAvaliador->nome_img_cresidencia = $img2;
				$this->autocadastrarAvaliador->descricao_recusa = null;
				$this->autocadastrarAvaliador->data_avaliador = $data;
				$this->autocadastrarAvaliador->horario_avaliador = $horario;
				$this->autocadastrarAvaliador->inserirAvaliador();
				$this->session->set_flashdata('ava_cadastrado','O seu autocadastro foi realizado com sucesso! Aguarde até que a nossa equipe entre em contato sobre o seu ingresso como avaliador');
				redirect('ListagemPerfilUsuario','refresh');

				
			} else {
				$this->session->set_flashdata('sem_imgs','Carregue as duas imagens requeridas');
				$this->load->view('autocadastroAvaliador');
			}

		} else {
			redirect('Donar','refresh');
		}
	}

}