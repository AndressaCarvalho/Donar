<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CadastroDenunciaDoacao extends CI_Controller {

	public function index() {
		if ($this->session->userdata('id_usuario')) {

			$this->form_validation->set_rules('detalhamentorecusa', 'Detalhamento do motivo da recusa', 'max_length[254]|trim');
			$this->form_validation->set_rules('detalhamentodenuncia', 'Detalhamento do motivo da denúncia', 'max_length[254]|trim');
			if ($this->form_validation->run() == TRUE) {

				if (isset($_POST['enviar'])) {

					$doacao = $_POST['doacao'];
					$vulner = $_POST['vulner'];
					$usuario = $this->session->userdata('id_usuario');
					
					if (!empty(trim($_POST['detalhamentorecusa']))) {
						$this->load->model('aceitarRecusarDoacao');
						$this->aceitarRecusarDoacao->rejeicaoDoacaoReceptor($detalhamentor, $vulner, $doacao);
					}
					
					if (!empty($_POST['motivoLista']) && !empty(trim($_POST['detalhamentodenuncia']))) {

						$this->load->model('cadastrarDenunciaDoacao');
						$detalhamentod = trim($_POST['detalhamentodenuncia']);
						$motivo = $_POST['motivoLista'];
						date_default_timezone_set('America/Sao_Paulo');
						$data = date('Y-m-d');
						$horario = date('H:i:s');

						$this->cadastrarDenunciaDoacao->id_doacao = $doacao;
						$this->cadastrarDenunciaDoacao->id_motivacao = $motivo;
						$this->cadastrarDenunciaDoacao->id_usuario = $usuario;
						$this->cadastrarDenunciaDoacao->data_denuncia_doacao = $data;
						$this->cadastrarDenunciaDoacao->horario_denuncia_doacao = $horario;
						$this->cadastrarDenunciaDoacao->detalhamento_denuncia_doacao = $detalhamentod;
						$this->cadastrarDenunciaDoacao->avaliada = false;
						$this->cadastrarDenunciaDoacao->inserirDenunciaDoacao();

						$this->session->set_flashdata('denuncia_cadastrada', 'Denúncia cadastrada com sucesso');
						
						redirect('ListagemRecebimentoDoacao','refresh');

					}

					if (!empty($_POST['motivoLista']) && empty(trim($_POST['detalhamentodenuncia']))) {

						$this->load->model('cadastrarDenunciaDoacao');
						$motivo = $_POST['motivoLista'];
						date_default_timezone_set('America/Sao_Paulo');
						$data = date('Y-m-d');
						$horario = date('H:i:s');

						$this->cadastrarDenunciaDoacao->id_doacao = $doacao;
						$this->cadastrarDenunciaDoacao->id_motivacao = $motivo;
						$this->cadastrarDenunciaDoacao->id_usuario = $usuario;
						$this->cadastrarDenunciaDoacao->data_denuncia_doacao = $data;
						$this->cadastrarDenunciaDoacao->horario_denuncia_doacao = $horario;
						$this->cadastrarDenunciaDoacao->detalhamento_denuncia_doacao = NULL;
						$this->cadastrarDenunciaDoacao->avaliada = false;
						$this->cadastrarDenunciaDoacao->inserirDenunciaDoacao();

						$this->session->set_flashdata('denuncia_cadastrada', 'Denúncia cadastrada com sucesso');
						
						redirect('ListagemRecebimentoDoacao','refresh');
					}

					if (empty($_POST['motivoLista']) && !empty(trim($_POST['detalhamentodenuncia']))) {
						$this->session->set_flashdata('motivo_inexistente', 'O motivo da denúncia deve ser informado');
						
						redirect('ListagemRecebimentoDoacao','refresh');
					}
					
				}

				if (isset($_POST['sair'])) {
					$this->session->set_flashdata('doacao_recusada', 'A doação foi recusada');
							
					redirect('ListagemRecebimentoDoacao','refresh');	
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Detalhamento do motivo da recusa e/ou no campo Detalhamento do motivo da denúncia');
				redirect('ListagemRecebimentoDoacao','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}