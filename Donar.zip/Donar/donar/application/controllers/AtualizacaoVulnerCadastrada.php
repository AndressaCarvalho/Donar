<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AtualizacaoVulnerCadastrada extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			if ($_POST['vulner']) {

				$vulner = $_POST['vulner'];

				$dados = array('vulner' => $vulner);
				$this->load->view('confirmarSenhaUsuario4', $dados);

			} else {
                redirect('ListagemVulnerCadastrada','refresh');
            }
		} else {
            redirect('Donar','refresh');
        }

	}


	public function excluirVulnerCadastrada() {
		if ($this->session->userdata('id_usuario')) {

			$this->form_validation->set_rules('senha', 'Senha', 'required|max_length[12]|min_length[6]');

			if ($this->form_validation->run() == TRUE) {
				$this->load->model('atualizarVulnerCadastrada');

				$vulner = $_POST['vulner'];

				$senha = md5($_POST['senha']);
				$usuario = $this->session->userdata('id_usuario');

				$eusuario = ($this->atualizarVulnerCadastrada->selecionarPorSenha($usuario, $senha));

				if ($eusuario) {
					$visivel = false;

					$this->atualizarVulnerCadastrada->atualizarVulnerInvisivel($visivel, $vulner);

					$this->session->set_flashdata('vulner_excluida', 'A situação de vulnerabilidade social cadastrada foi excluída com sucesso');
					redirect('ListagemVulnerCadastrada','refresh');

				} else {
					$this->session->set_flashdata('senha_erradaa3', 'A senha inserida está errada');
					redirect('ListagemVulnerCadastrada','refresh');
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Senha, tente de novo');
				redirect('ListagemVulnerCadastrada','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}

}