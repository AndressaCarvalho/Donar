<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CadastroDenunciaVulner1 extends CI_Controller {

	public function index() {
		if ($this->session->userdata('id_usuario')) {
			
			$this->form_validation->set_rules('detalhamento', 'Detalhamento do motivo da denúncia', 'max_length[254]|trim');
			if ($this->form_validation->run() == TRUE) {
				$this->load->model('cadastrarDenunciaVulner');

				$vulner = $_POST['vulner'];
				$usuario = $this->session->userdata('id_usuario');
				date_default_timezone_set('America/Sao_Paulo');
				$data = date('Y-m-d');
				$horario = date('H:i:s');

				if (!empty($_POST['motivoLista']) && !empty(trim($_POST['detalhamento']))) {

					$motivo = $_POST['motivoLista'];
					$detalhamento = trim($_POST['detalhamento']);

					$this->cadastrarDenunciaVulner->id_vulner = $vulner;
					$this->cadastrarDenunciaVulner->id_motivacao = $motivo;
					$this->cadastrarDenunciaVulner->id_usuario = $usuario;
					$this->cadastrarDenunciaVulner->data_denuncia_vulner = $data;
					$this->cadastrarDenunciaVulner->horario_denuncia_vulner = $horario;
					$this->cadastrarDenunciaVulner->detalhamento_denuncia_vulner = $detalhamento;
					$this->cadastrarDenunciaVulner->inserirDenunciaVulner();

					$this->session->set_flashdata('denuncia_cadastrada', 'Denúncia cadastrada com sucesso');
					
					redirect('ListagemVulner','refresh');
					
				}

				if (!empty($_POST['motivoLista']) && empty(trim($_POST['detalhamento']))) {

					$motivo = $_POST['motivoLista'];

					$this->cadastrarDenunciaVulner->id_vulner = $vulner;
					$this->cadastrarDenunciaVulner->id_motivacao = $motivo;
					$this->cadastrarDenunciaVulner->id_usuario = $usuario;
					$this->cadastrarDenunciaVulner->data_denuncia_vulner = $data;
					$this->cadastrarDenunciaVulner->horario_denuncia_vulner = $horario;
					$this->cadastrarDenunciaVulner->detalhamento_denuncia_vulner = NULL;
					$this->cadastrarDenunciaVulner->inserirDenunciaVulner();

					$this->session->set_flashdata('denuncia_cadastrada', 'Denúncia cadastrada com sucesso');
					redirect('ListagemVulner','refresh');

				}

				if (empty($_POST['motivoLista']) && !empty(trim($_POST['detalhamento']))) {
					$this->session->set_flashdata('motivo_inexistente', 'O motivo da denúncia deve ser informado');
					redirect('ListagemVulner','refresh');
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Detalhamento do motivo da denúncia, tente de novo');
				redirect('ListagemVulner','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}