<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->view('login');
	}

	public function loginUser() {
		$this->form_validation->set_rules('email', 'Email', 'max_length[254]');
		$this->form_validation->set_rules('senha', 'Senha', 'max_length[12]');

		if ($this->form_validation->run() == TRUE) {
			$this->load->model('loginUsuario');

			$email = $_POST['email'];
			$senha = $_POST['senha'];

			$uid1 = ($this->loginUsuario->selecionarIDUsuario($email));

			if ($uid1) {
				$uid2 = ($this->loginUsuario->selecionarIDUsuario($email))[0]->id_usuario;
				$idumb1 = ($this->loginUsuario->selecionarMotivoUsuarioBanido($uid2));

				if ($idumb1) {
					$uid2 = ($this->loginUsuario->selecionarIDUsuario($email))[0]->id_usuario;
					$idumb3 = ($this->loginUsuario->selecionarMotivoUsuarioBanido($uid2))[0]->id_motivo_banido;
					$idumb4['lista1'] = ($this->loginUsuario->selecionarMotivoUsuarioBanido2($uid2));
					$idumb2['lista2'] = ($this->loginUsuario->selecionarMotivoBanido($idumb3));

					$dados = array('motivo' => $idumb2, 'detalhamento' => $idumb4);
					$this->load->view('usuarioBanido', $dados);

				} else {
					$situacao = true;
					$ati = ($this->loginUsuario->selecionarUsuarioAtivo($email, $situacao));

					if ($ati) {

						$us1 = ($this->loginUsuario->selecionarSenhaUsuario($email))[0]->senha;
						$senha2 = md5($senha);

						if ($us1 == $senha2) {
							$situacaoAvaliador = ($this->loginUsuario->selecionarAtorUsuarioAvaliador($email))[0]->avaliador;
							$situacaoAdm = ($this->loginUsuario->selecionarAtorUsuarioAdm($email))[0]->adm;
							
							if ($situacaoAdm == true) {
								$this->session->set_userdata('id_adm', $uid2);

								$this->session->set_userdata('id_usuario', $uid2);
								
								$unom = ($this->loginUsuario->selecionarNomeUsuario($uid2))[0]->nome_usuario;
								$uper = ($this->loginUsuario->selecionarFotoUsuario($uid2))[0]->nome_img_perfil;
								
								$this->session->set_userdata('nome_usuario', $unom);
								
								$diretorio = base_url("/upload_img/");
								$diretorio .= $uper;
								$this->session->set_userdata('perfil_usuario', $diretorio);
								
								redirect('ListagemVulner','refresh');
							} else if ($situacaoAvaliador == true) {
								$this->session->set_userdata('id_avaliador', $uid2);

								$this->session->set_userdata('id_usuario', $uid2);
								
								$unom = ($this->loginUsuario->selecionarNomeUsuario($uid2))[0]->nome_usuario;
								$uper = ($this->loginUsuario->selecionarFotoUsuario($uid2))[0]->nome_img_perfil;
								
								$this->session->set_userdata('nome_usuario', $unom);
								
								$diretorio = base_url("/upload_img/");
								$diretorio .= $uper;
								$this->session->set_userdata('perfil_usuario', $diretorio);
								
								redirect('ListagemVulner','refresh');
							} elseif ($situacaoAvaliador == false && $situacaoAdm == false) {
								$this->session->set_userdata('id_usuario', $uid2);

								$unom = ($this->loginUsuario->selecionarNomeUsuario($uid2))[0]->nome_usuario;
								$uper = ($this->loginUsuario->selecionarFotoUsuario($uid2))[0]->nome_img_perfil;
								
								$this->session->set_userdata('nome_usuario', $unom);
								
								$diretorio = base_url("/upload_img/");
								$diretorio .= $uper;
								$this->session->set_userdata('perfil_usuario', $diretorio);
								
								redirect('ListagemVulner','refresh');
							}
						} else {
							$this->session->set_flashdata('senha_errada', 'A senha inserida está errada');
							redirect('Login','refresh');
						}
						
					} else {
						$this->session->set_flashdata('usuario_inativo', 'Esta conta está inativa');
						redirect('Login','refresh');
					}

				}
			} else {
				$this->session->set_flashdata('usuario_inexistente', 'O usuário não existe');
				redirect('Login','refresh');
			}
		}
	}

}