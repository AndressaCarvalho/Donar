<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemPerfilUsuario extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->load->model('listarPerfilUsuario');

			$usuario = $this->session->userdata('id_usuario');

			$infusuario['lista1'] = ($this->listarPerfilUsuario->selecionarUsuario($usuario));

			$ava = ($this->listarPerfilUsuario->selecionarAvaliador($usuario));

			$situacao = true;
			$usava = ($this->listarPerfilUsuario->selecionarAvaliadorUsuario($usuario, $situacao));

			
			foreach ($infusuario as $li => $l) {
				foreach ($l as $li => $list) {

					if ($list->id_bairro_cidade) {
						$inflocal['lista2'] = ($this->listarPerfilUsuario->selecionarLocal($list->id_bairro_cidade));
					}

				}
			}


			foreach ($inflocal as $li2 => $l2) {
				foreach ($l2 as $li2 => $list2) {

					if ($list2->id_cidade) {
						$cidade['lista4'] = ($this->listarPerfilUsuario->selecionarCidade($list2->id_cidade));
					}
				}
			}

			$dados = array('infusuario' => $infusuario, 'avaliador' => $ava,  'usava' => $usava, 'bairro' => $inflocal,'cidade' => $cidade);
			$this->load->view('listagemPerfilUsuario', $dados);


		} else {
			redirect('Donar','refresh');
		}
	}

	public function atualizarExcluir() {
		if ($this->session->userdata('id_usuario')) {

			if (!isset($_POST['editar']) && !isset($_POST['excluir']) && !isset($_POST['tavaliador'])) {
				redirect('ListagemPerfilUsuario','refresh');
			}

			if (isset($_POST['editar'])) {

				$nome_img_perfil = $_POST['nome_img_perfil'];
				$nome_usuario = $_POST['nome_usuario'];
				
				$nomes = explode(" ", $nome_usuario);
				
				$email = $_POST['email'];
				$telefone_usuario = $_POST['telefone_usuario'];
				$nome_rua_usuario = $_POST['nome_rua_usuario'];
				$numero_rua_usuario = $_POST['numero_rua_usuario'];
				$cep_usuario = $_POST['cep_usuario'];
				$nome_bairro = $_POST['nome_bairro'];
				$nome_cidade = $_POST['nome_cidade'];
				$sigla_estado = $_POST['sigla_estado'];

				$dados = array('nome_img_perfil' => $nome_img_perfil, 'nomes' => $nomes, 'email' => $email, 'telefone_usuario' => $telefone_usuario, 'nome_rua_usuario' => $nome_rua_usuario, 'numero_rua_usuario' => $numero_rua_usuario, 'cep_usuario' => $cep_usuario, 'nome_bairro' => $nome_bairro, 'nome_cidade' => $nome_cidade, 'sigla_estado' => $sigla_estado);

				$this->load->view('atualizacaoPerfilUsuario', $dados);
			}

			if (isset($_POST['excluir'])) {
				$this->load->view('confirmarSenhaUsuario3');
			}

			if (isset($_POST['tavaliador'])) {
				$this->load->view('autocadastroAvaliador');
			}

		} else {
			redirect('Donar','refresh');
		}

	}


	public function desativarContaUsuario() {
		if ($this->session->userdata('id_usuario')) {
			$this->form_validation->set_rules('senha', 'Senha', 'required|max_length[12]|min_length[6]');

			if ($this->form_validation->run() == TRUE) {

				$this->load->model('atualizarPerfilUsuario');

				$senha = md5($_POST['senha']);
				$usuario = $this->session->userdata('id_usuario');

				$eusuario = ($this->atualizarPerfilUsuario->selecionarPorSenha($usuario, $senha));

				if ($eusuario) {
					$situacao = false;
					$visivel = true;
					$this->atualizarPerfilUsuario->desativarUsuario($situacao, $usuario);
					$idvulner = $this->atualizarPerfilUsuario->selecionarVulner1($visivel, $usuario);

					if ($idvulner) {
						
						foreach ($idvulner as $li => $list) {
							if ($list->id_vulner) {
								$this->atualizarPerfilUsuario->atualizarVulnerInvisivel($situacao, $list->id_vulner);
							}
						}

					}

					$this->session->unset_userdata('perfil_usuario');
					$this->session->unset_userdata('nome_usuario');
					$this->session->unset_userdata('id_usuario');

					if ($this->session->userdata('id_adm')) {
						$this->session->unset_userdata('id_adm');
					}

					if ($this->session->userdata('id_avaliador')) {
						$this->session->unset_userdata('id_avaliador');
					}

					if ($this->session->userdata('retorno_inexistente1')) {
						$this->session->unset_userdata('retorno_inexistente1');
					}

					if ($this->session->userdata('retorno_inexistente2')) {
						$this->session->unset_userdata('retorno_inexistente2');
					}

					if ($this->session->userdata('retorno_inexistente3')) {
						$this->session->unset_userdata('retorno_inexistente3');
					}

					if ($this->session->userdata('retorno_inexistente4')) {
						$this->session->unset_userdata('retorno_inexistente4');
					}

					if ($this->session->userdata('retorno_inexistente5')) {
						$this->session->unset_userdata('retorno_inexistente5');
					}

					if ($this->session->userdata('doado_doador')) {
						$this->session->unset_userdata('doado_doador');
					}

					if ($this->session->userdata('doado_receptor')) {
						$this->session->unset_userdata('doado_receptor');
					}

					$this->session->set_flashdata('conta_desativada', 'A conta foi desativada com sucesso');
					redirect('Login','refresh');

				} else {
					$this->session->set_flashdata('senha_erradaa2', 'A senha inserida está errada');
					redirect('ListagemPerfilUsuario','refresh');
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Senha, tente de novo');
				redirect('ListagemPerfilUsuario','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}