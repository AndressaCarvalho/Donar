<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemDoacaoDenunciada extends CI_Controller {

	public function index()
	{
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->model('listarDoacaoDenunciada');

			$aval = false;
			$doacao['lista1'] = ($this->listarDoacaoDenunciada->selecionarDoacao1($aval));

			if (!empty($doacao['lista1'])) {
				
				$imagem2['lista2'] = array();
				foreach ($doacao as $li => $l) {
          			foreach ($l as $lis => $list) {

          				if ($list->id_doacao) {
          					$imagem1 = ($this->listarDoacaoDenunciada->selecionarImagemDoacao1($list->id_doacao));

          					if (!empty($imagem1)) {
          						$imagem1 = ($this->listarDoacaoDenunciada->selecionarImagemDoacao1($list->id_doacao))[0];
          						array_push($imagem2['lista2'], $imagem1);
          					}

          				}

					}
				}

          		$vulner2['lista3'] = array();
          		foreach ($doacao as $li2 => $l2) {
          			foreach ($l2 as $lis2 => $list2) {

          				if ($list2->id_doacao) {
          					$vulner1 = ($this->listarDoacaoDenunciada->selecionarVulner1($list2->id_doacao));

          					if (!empty($vulner1)) {
          						$vulner1 = ($this->listarDoacaoDenunciada->selecionarVulner1($list2->id_doacao))[0]->id_vulner;
          						array_push($vulner2['lista3'], $vulner1);
          					}

          				}

          			}
          		}

          		$vulner4['lista4'] = array();
          		foreach ($vulner2 as $li3 => $l3) {
          			foreach ($l3 as $lis3 => $list3) {
          				$vulner3 = ($this->listarDoacaoDenunciada->selecionarVulner2($list3));

          				if (!empty($vulner3)) {
          					$vulner3 = ($this->listarDoacaoDenunciada->selecionarVulner2($list3))[0];
          					array_push($vulner4['lista4'], $vulner3);
          				}

          			}
          		}

          		$vulnerdoacao['lista5'] = array();
          		foreach ($doacao as $li4 => $l4) {
          			foreach ($l4 as $lis4 => $list4) {

          				if ($list4->id_doacao) {
          					$vulnerdoacao2 = ($this->listarDoacaoDenunciada->selecionarVulnerDoacao($list4->id_doacao));

          					if (!empty($vulner1)) {
          						$vulnerdoacao2 = ($this->listarDoacaoDenunciada->selecionarVulnerDoacao($list4->id_doacao))[0];
          						array_push($vulnerdoacao['lista5'], $vulnerdoacao2);
          					}

          				}

          			}
          		}


				$dados = array('doacoes' => $doacao, 'imgs' => $imagem2, 'vulners' => $vulner4, 'vulnersdoacoes' => $vulnerdoacao);
				$this->load->view('listagemDoacaoDenunciada', $dados);

			} else {
				$this->session->set_userdata('retorno_inexistente7', 'Não há nenhuma doação denunciada');
				$this->load->view('listagemDoacaoDenunciada');
			}

		} else {
			redirect('Donar','refresh');
		}
	}


	public function detalhesDoacaoDenunciada() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			if ($_POST['vulner']) {
				$this->load->model('listarDoacaoDenunciada');

				$vulner = $_POST['vulner'];
				$doacao = $_POST['doacao'];
				$denuncia = $_POST['denunciadoacao'];

				//Para denúncia
				$denun['lista16'] = ($this->listarDoacaoDenunciada->selecionarDenuncia($denuncia));
				
				foreach ($denun as $li7 => $l7) {
				    foreach ($l7 as $lis7 => $list7) {

				    	if ($list7->id_motivacao) {
				    		$motivacao['lista17'] = ($this->listarDoacaoDenunciada->selecionarMotivacao($list7->id_motivacao));
				    	}

				    }
				}


				//Para a situação de vulnerabilidade social
				$vul['lista1'] = ($this->listarDoacaoDenunciada->selecionarVulner3($vulner));

				$imagemv['lista2'] = ($this->listarDoacaoDenunciada->selecionarImagemVulner($vulner));

				foreach ($vul as $li => $l) {
				    foreach ($l as $lis => $list) {

				    	if ($list->id_bairro_cidade) {
				    		$idbaicidv['lista3'] = ($this->listarDoacaoDenunciada->selecionarLocal($list->id_bairro_cidade));
				    	}

				    }
				}

				foreach ($idbaicidv as $li2 => $l2) {
				    foreach ($l2 as $lis2 => $list2) {

				    	if ($list2->id_cidade) {
				    		$idcidv['lista5'] = ($this->listarDoacaoDenunciada->selecionarCidade($list2->id_cidade));
				    	}

				    }
				}

				$itemv['lista6'] = ($this->listarDoacaoDenunciada->selecionarVulnerItem($vulner));

				$categoriav['lista7'] = array();
				$unidadev['lista8'] = array();
				foreach ($itemv as $li3 => $l3) {
				    foreach ($l3 as $lis3 => $list3) {

				    	if ($list3->id_categoria) {
				    		$cat = ($this->listarDoacaoDenunciada->selecionarCategoria($list3->id_categoria))[0];
				    		array_push($categoriav['lista7'], $cat);
				    	}

				    	if ($list3->id_unidade) {
				    		$uni = ($this->listarDoacaoDenunciada->selecionarUnidade($list3->id_unidade))[0];
				    		array_push($unidadev['lista8'], $uni);
				    	}

				    }
				}


				//Para a doação e doador
				$doac['lista9'] = ($this->listarDoacaoDenunciada->selecionarDoacao2($doacao));

				$imagemd['lista10'] = ($this->listarDoacaoDenunciada->selecionarImagemDoacao1($doacao));

				$itemd['lista11'] = ($this->listarDoacaoDenunciada->selecionarDoacaoItem($doacao));

				$infdoador['lista14'] = array();
				foreach ($doac as $li5 => $l5) {
				    foreach ($l5 as $lis5 => $list5) {

				    	if ($list5->id_usuario) {
				    		$infdoador2 = ($this->listarDoacaoDenunciada->selecionarUsuario($list5->id_usuario))[0];
				    		array_push($infdoador['lista14'], $infdoador2);
				    	}

				    }
				}

				$categoriad['lista12'] = array();
				$unidaded['lista13'] = array();
				foreach ($itemd as $li4 => $l4) {
				    foreach ($l4 as $lis4 => $list4) {

				    	if ($list4->id_categoria) {
				    		$cat = ($this->listarDoacaoDenunciada->selecionarCategoria($list4->id_categoria))[0];
				    		array_push($categoriad['lista12'], $cat);
				    	}

				    	if ($list4->id_unidade) {
				    		$uni = ($this->listarDoacaoDenunciada->selecionarUnidade($list4->id_unidade))[0];
				    		array_push($unidaded['lista13'], $uni);
				    	}

				    }
				}


				//Para o denunciador
				$iddenun['lista14'] = ($this->listarDoacaoDenunciada->selecionarDenunciador1($denuncia));

				$infdenunciador['lista15'] = array();
				foreach ($iddenun as $li6 => $l6) {
				    foreach ($l6 as $lis6 => $list6) {
				    	
				    	if ($list6->id_usuario) {
				    		$infdenunciador2 = ($this->listarDoacaoDenunciada->selecionarUsuario($list6->id_usuario))[0];
				    		array_push($infdenunciador['lista15'], $infdenunciador2);
				    	}

				    }
				}


				$dados = array('vulner' => $vul, 'imagensv' => $imagemv,'bairro' => $idbaicidv, 'cidade' => $idcidv, 'itensv' => $itemv, 'categoriasv' => $categoriav, 'unidadesv' => $unidadev, 'doacao' => $doac, 'imagensd' => $imagemd, 'itensd' => $itemd, 'categoriasd' => $categoriad, 'unidadesd' => $unidaded, 'infdoador' => $infdoador, 'infdenunciador' => $infdenunciador, 'denuncia' => $denun, 'motivacao' => $motivacao);
				$this->load->view('detalhesDoacaoDenunciada', $dados);

			} else {
				redirect('ListagemDoacaoDenunciada','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}

	}


	public function confirmarNegarDenunciaDoacao() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			if ($_POST['doador']) {
				$this->load->model('listarDoacaoDenunciada');

				$doador['lista1'] = $_POST['doador'];
				$denuncia1 = $_POST['ddoacao'];
				$denuncia2['lista2'] = $_POST['ddoacao'];

				if (isset($_POST['nbdoador'])) {
					$aux1 = true;

					$this->listarDoacaoDenunciada->atualizarBanirDoador($denuncia1, $aux1);

					$this->session->set_flashdata('doador_nban', 'O doador não foi banido');	
					redirect('ListagemDoacaoDenunciada','refresh');
				}

				if (isset($_POST['bdoador'])) {
					$this->load->model('banirUsuario');

					$motivos['lista3'] = ($this->banirUsuario->selecionarMotivo());

					$dados = array('denuncia' => $denuncia2, 'usuario' => $doador, 'motivos' => $motivos);
					$this->load->view('banimentoDoador', $dados);	
				}

			} else {
				redirect('ListagemDoacaoDenunciada','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}