<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemVulnerCadastrada extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->load->model('listarVulnerCadastrada');

			$us = $this->session->userdata('id_usuario');

			$vulner1['lista1'] = ($this->listarVulnerCadastrada->selecionarVulner1($us));


               if (!empty($vulner1['lista1'])) {


                    $imagem2['lista2'] = array();
                    $vulner3['lista3'] = array();
                    foreach ($vulner1 as $li => $l) {
                         foreach ($l as $lis => $list) {
                              
                              if ($list->id_vulner) {
                                   $imagem1 = ($this->listarVulnerCadastrada->selecionarImagemVulner1($list->id_vulner));

                                   if (!empty($imagem1)) {
                                        $imagem1 = ($this->listarVulnerCadastrada->selecionarImagemVulner1($list->id_vulner))[0];
                                        array_push($imagem2['lista2'], $imagem1);
                                   }
                              }

                              if ($list->id_vulner) {
                                   $vulner2 = ($this->listarVulnerCadastrada->selecionarVulner2($list->id_vulner));

                                   if (!empty($vulner2)) {
                                        $vulner2 = ($this->listarVulnerCadastrada->selecionarVulner2($list->id_vulner))[0];
                                        array_push($vulner3['lista3'], $vulner2);
                                   }
                              }

                         }
                    }

                    $dados1 = array('imgs' => $imagem2, 'vulners' => $vulner3);
                    $this->load->view('listagemVulnerCadastrada', $dados1);
                    

               } else {
                    $this->session->set_userdata('retorno_inexistente4', 'Você ainda não cadastrou nenhuma situação de vulnerabilidade social...');
                    $this->load->view('listagemVulnerCadastrada');
               }


			
		} else {
			redirect('Donar','refresh');
		}

	}


     public function detalhesVulnerCadastrada() {
          if ($this->session->userdata('id_usuario')) {
               if ($_POST['vulner']) {
                    $this->load->model('listarVulnerCadastrada');

                    $vulner = $_POST['vulner'];

                    
                    //Para a situação de vulnerabilidade social
                    $vul['lista1'] = ($this->listarVulnerCadastrada->selecionarVulner3($vulner));

                    $aux1 = true;
                    $situacao = ($this->listarVulnerCadastrada->selecionarAvaVulner($vulner, $aux1));
                    $situacao2 = ($this->listarVulnerCadastrada->selecionarViVulner($vulner, $aux1));

                    $imagemv['lista2'] = ($this->listarVulnerCadastrada->selecionarImagemVulner2($vulner));

                    foreach ($vul as $li => $l) {
                        foreach ($l as $lis => $list) {

                              if ($list->id_bairro_cidade) {
                                   $idbaicidv['lista3'] = ($this->listarVulnerCadastrada->selecionarLocal($list->id_bairro_cidade));
                              }

                        }
                    }

                    foreach ($idbaicidv as $li2 => $l2) {
                        foreach ($l2 as $lis2 => $list2) {

                              if ($list2->id_cidade) {
                                   $idcidv['lista5'] = ($this->listarVulnerCadastrada->selecionarCidade($list2->id_cidade));
                              }

                        }
                    }


                    $itemv['lista6'] = ($this->listarVulnerCadastrada->selecionarVulnerItem($vulner));

                    $categoriav['lista7'] = array();
                    $unidadev['lista8'] = array();
                    foreach ($itemv as $li3 => $l3) {
                        foreach ($l3 as $lis3 => $list3) {

                              if ($list3->id_categoria) {
                                   $cat = ($this->listarVulnerCadastrada->selecionarCategoria($list3->id_categoria))[0];
                                   array_push($categoriav['lista7'], $cat);
                              }

                              if ($list3->id_unidade) {
                                   $uni = ($this->listarVulnerCadastrada->selecionarUnidade($list3->id_unidade))[0];
                                   array_push($unidadev['lista8'], $uni);
                              }

                        }
                    }


                    //Para a doação
                    $vulnerdoacao1['lista14'] = ($this->listarVulnerCadastrada->selecionarVulnerDoacao2());

                    $doacao1['lista15'] = array();
                    foreach ($vulnerdoacao1 as $li5 => $l5) {
                         foreach ($l5 as $lis5 => $list5) {
                                             
                              if ((($list5->id_vulner == $vulner) && ($list5->doado_doador == 'D')) && ($list5->doado_receptor == 'A')) {
                                   array_push($doacao1['lista15'], $list5->id_doacao);
                              }

                         }
                    }

                    $itemd2['lista16'] = array();
                    foreach ($doacao1 as $li6 => $l6) {
                         foreach ($l6 as $lis6 => $list6) {

                              $itemd1 = ($this->listarVulnerCadastrada->selecionarDoacaoItem($list6));

                              if (!empty($itemd1)) {
                                   $itemd1 = ($this->listarVulnerCadastrada->selecionarDoacaoItem($list6))[0];
                                   array_push($itemd2['lista16'], $itemd1);
                              }

                         }
                    }

                    $categoriad['lista17'] = array();
                    $unidaded['lista18'] = array();
                    foreach ($itemd2 as $li7 => $l7) {
                        foreach ($l7 as $lis7 => $list7) {

                              if ($list7->id_categoria) {
                                   $cat = ($this->listarVulnerCadastrada->selecionarCategoria($list7->id_categoria))[0];
                                   array_push($categoriad['lista17'], $cat);
                              }

                              if ($list7->id_unidade) {
                                   $uni = ($this->listarVulnerCadastrada->selecionarUnidade($list7->id_unidade))[0];
                                   array_push($unidaded['lista18'], $uni);
                              }

                        }
                    }

                    
                    $dados2 = array('vulner' => $vul, 'imagensv' => $imagemv,'bairro' => $idbaicidv, 'cidade' => $idcidv, 'itensv' => $itemv, 'categoriasv' => $categoriav, 'unidadesv' => $unidadev, 'itensd' => $itemd2, 'categoriasd' => $categoriad, 'unidadesd' => $unidaded, 'situacao' => $situacao, 'situacao2' => $situacao2);
                    $this->load->view('detalhesVulnerCadastrada', $dados2);
               } else {
                    redirect('ListagemVulnerCadastrada','refresh');
               }
          } else {
               redirect('Donar','refresh');
          }

     }

}