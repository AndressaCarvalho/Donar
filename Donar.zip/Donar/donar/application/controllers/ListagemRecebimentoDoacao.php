<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemRecebimentoDoacao extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->load->model('listarRecebimentoDoacao');

			$us = $this->session->userdata('id_usuario');


			$vulnerdoacao1['lista6'] = ($this->listarRecebimentoDoacao->selecionarVulnerDoacao2());

			$vulnerdoacao4['lista10'] = array();
			$vulner2['lista1'] = array();
			foreach ($vulnerdoacao1 as $li => $l) {
          		foreach ($l as $lis => $list) {
          			
          			if ($list->id_vulner) {
          				$vulner1 = ($this->listarRecebimentoDoacao->selecionarVulner1($us, $list->id_vulner));

          				if (!empty($vulner1)) {
          					$vulner1 = ($this->listarRecebimentoDoacao->selecionarVulner1($us, $list->id_vulner))[0];
          					array_push($vulner2['lista1'], $vulner1);

          					array_push($vulnerdoacao4['lista10'], $list->id_vulner_doacao);
          				}

          			}

          		}
          	}


			if (!empty($vulner2['lista1'])) {
				
				$vulnerdoacao3['lista5'] = array();
				foreach ($vulnerdoacao4 as $li2 => $l2) {
				    foreach ($l2 as $lis2 => $list2) {

				        if ($list2) {
				          	$vulnerdoacao2 = ($this->listarRecebimentoDoacao->selecionarVulnerDoacao1($list2));

				          	if (!empty($vulnerdoacao2)) {
				          		$vulnerdoacao2 = ($this->listarRecebimentoDoacao->selecionarVulnerDoacao1($list2))[0];
				          		array_push($vulnerdoacao3['lista5'], $vulnerdoacao2);
				          	}
				        }

					}
				}


				$imagem2['lista7'] = array();
				$doacao2['lista8'] = array();
				$vulner4['lista9'] = array();
				foreach ($vulnerdoacao3 as $li3 => $l3) {
					foreach ($l3 as $lis3 => $list3) {
					    	
					    if ($list3->id_doacao) {
					    	$imagem1 = ($this->listarRecebimentoDoacao->selecionarImagemDoacao1($list3->id_doacao));

				          	if (!empty($imagem1)) {
				          		$imagem1 = ($this->listarRecebimentoDoacao->selecionarImagemDoacao1($list3->id_doacao))[0];
				          		array_push($imagem2['lista7'], $imagem1);
				          	}
					    }

					    if ($list3->id_doacao) {
				          	$doacao1 = ($this->listarRecebimentoDoacao->selecionarDoacao1($list3->id_doacao));

				          	if (!empty($doacao1)) {
				          		$doacao1 = ($this->listarRecebimentoDoacao->selecionarDoacao1($list3->id_doacao))[0];
				          		array_push($doacao2['lista8'], $doacao1);
				          	}
				        }

				        if ($list3->id_vulner) {
				        	$vulner3 = ($this->listarRecebimentoDoacao->selecionarVulner2($list3->id_vulner));

				        	if (!empty($vulner3)) {
				        	  	$vulner3 = ($this->listarRecebimentoDoacao->selecionarVulner2($list3->id_vulner))[0];
				        	  	array_push($vulner4['lista9'], $vulner3);
				        	}
				        }

					}
				}


				$dados1 = array('vulnersdoacoes' => $vulnerdoacao3, 'imgs' => $imagem2, 'vulners' => $vulner4, 'doacoes' => $doacao2);
				$this->load->view('listagemRecebimentoDoacao', $dados1);
				

			} else {
				$this->session->set_userdata('retorno_inexistente3', 'Você ainda não tem nenhuma doação para recebimento...');
				$this->load->view('listagemRecebimentoDoacao');
			}


		} else {
			redirect('Donar','refresh');
		}
	}


	public function detalhesRecebimentoDoacao() {
		if ($this->session->userdata('id_usuario')) {
			if ($_POST['vulner']) {
				$this->load->model('listarRecebimentoDoacao');

				$vulner = $_POST['vulner'];
				$doacao = $_POST['doacao'];

				
				//Para a situação de vulnerabilidade social
				$vul['lista1'] = ($this->listarRecebimentoDoacao->selecionarVulner3($vulner));

				$imagemv['lista2'] = ($this->listarRecebimentoDoacao->selecionarImagemVulner($vulner));

				foreach ($vul as $li => $l) {
				    foreach ($l as $lis => $list) {

				    	if ($list->id_bairro_cidade) {
				    		$idbaicidv['lista3'] = ($this->listarRecebimentoDoacao->selecionarLocal($list->id_bairro_cidade));
				    	}

				    }
				}

				foreach ($idbaicidv as $li2 => $l2) {
				    foreach ($l2 as $lis2 => $list2) {

				    	if ($list2->id_cidade) {
				    		$idcidv['lista5'] = ($this->listarRecebimentoDoacao->selecionarCidade($list2->id_cidade));
				    	}

				    }
				}


				$itemv['lista6'] = ($this->listarRecebimentoDoacao->selecionarVulnerItem($vulner));

				$categoriav['lista7'] = array();
				$unidadev['lista8'] = array();
				foreach ($itemv as $li3 => $l3) {
				    foreach ($l3 as $lis3 => $list3) {

				    	if ($list3->id_categoria) {
				    		$cat = ($this->listarRecebimentoDoacao->selecionarCategoria($list3->id_categoria))[0];
				    		array_push($categoriav['lista7'], $cat);
				    	}

				    	if ($list3->id_unidade) {
				    		$uni = ($this->listarRecebimentoDoacao->selecionarUnidade($list3->id_unidade))[0];
				    		array_push($unidadev['lista8'], $uni);
				    	}

				    }
				}


				//Para a doação
				$doac['lista9'] = ($this->listarRecebimentoDoacao->selecionarDoacao2($doacao));

				$imagemd['lista10'] = ($this->listarRecebimentoDoacao->selecionarImagemDoacao1($doacao));

				$itemd['lista11'] = ($this->listarRecebimentoDoacao->selecionarDoacaoItem($doacao));

				$categoriad['lista12'] = array();
				$unidaded['lista13'] = array();
				foreach ($itemd as $li4 => $l4) {
				    foreach ($l4 as $lis4 => $list4) {

				    	if ($list4->id_categoria) {
				    		$cat = ($this->listarRecebimentoDoacao->selecionarCategoria($list4->id_categoria))[0];
				    		array_push($categoriad['lista12'], $cat);
				    	}

				    	if ($list4->id_unidade) {
				    		$uni = ($this->listarRecebimentoDoacao->selecionarUnidade($list4->id_unidade))[0];
				    		array_push($unidaded['lista13'], $uni);
				    	}

				    }
				}

				//Para localidade
				$usu = ($this->listarRecebimentoDoacao->selecionarUsuarioDoacao($doacao))[0]->id_usuario;
				$infdoador['lista15'] = ($this->listarRecebimentoDoacao->selecionarUsuario($usu));
				foreach ($infdoador as $li => $l) {
					foreach ($l as $li => $list) {

						if ($list->id_bairro_cidade) {
							$inflocal['lista16'] = ($this->listarRecebimentoDoacao->selecionarLocal($list->id_bairro_cidade));
						}

					}
				}

				foreach ($inflocal as $li2 => $l2) {
					foreach ($l2 as $li2 => $list2) {

						if ($list2->id_cidade) {
							$cidade['lista17'] = ($this->listarRecebimentoDoacao->selecionarCidade($list2->id_cidade));
						}
					}
				}


				$aux2 = 'A';
				$condoacao1 = ($this->listarRecebimentoDoacao->selecionarVulnerDoacao3($aux2, $doacao));

				$aux3 = 'R';
				$condoacao2 = ($this->listarRecebimentoDoacao->selecionarVulnerDoacao3($aux3, $doacao));

				
				$dados2 = array('vulner' => $vul, 'imagensv' => $imagemv,'bairro' => $idbaicidv, 'cidade' => $idcidv, 'itensv' => $itemv, 'categoriasv' => $categoriav, 'unidadesv' => $unidadev, 'doacao' => $doac, 'imagensd' => $imagemd, 'itensd' => $itemd, 'categoriasd' => $categoriad, 'unidadesd' => $unidaded, 'condoacao1' => $condoacao1, 'condoacao2' => $condoacao2, 'bairro2' => $inflocal,'cidade2' => $cidade);
				$this->load->view('detalhesRecebimentoDoacao', $dados2);
			} else {
				redirect('ListagemRecebimentoDoacao','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}

	}


	public function aceitarRecusarDoacao() {
		if ($this->session->userdata('id_usuario')) {
			if ($_POST['vulner']) {
				$this->load->model('aceitarRecusarDoacao');

				$this->load->model('cadastrarDenunciaVulner');

				$vulner['lista1'] = $_POST['vulner'];
				$doacao = $_POST['doacao'];
				$doa['lista6'] = $_POST['doacao'];

				if (isset($_POST['adoacao'])) {
					$aux1 = 'A';
					$aux2 = 'D';

					$this->aceitarRecusarDoacao->aceitarDoacaoReceptor($aux1, $doacao);

					$readoa = ($this->aceitarRecusarDoacao->selecionarSituacao($aux2, $aux1, $doacao));

					if ($readoa) {
						date_default_timezone_set('America/Sao_Paulo');
						$data = date('Y-m-d');
						$horario = date('H:i:s');

						$this->aceitarRecusarDoacao->horarioDiaDoacao($horario, $data, $doacao);
					}

					$infdoacao['lista1'] = ($this->aceitarRecusarDoacao->selecionarDoacao($doacao));

					foreach ($infdoacao as $li => $l) {
						foreach ($l as $li => $list) {
							
							if ($list->id_usuario) {
								$infusuario['lista2'] = ($this->aceitarRecusarDoacao->selecionarUsuario($list->id_usuario));
							}

						}
					}

					foreach ($infusuario as $li2 => $l2) {
						foreach ($l2 as $li2 => $list2) {
							
							if ($list2->id_bairro_cidade) {
								$inflocal['lista3'] = ($this->aceitarRecusarDoacao->selecionarLocal($list2->id_bairro_cidade));
							}

						}
					}

					foreach ($inflocal as $li3 => $l3) {
						foreach ($l3 as $li3 => $list3) {

							if ($list3->id_cidade) {
								$cidade['lista5'] = ($this->aceitarRecusarDoacao->selecionarCidade($list3->id_cidade));
							}

						}
					}

					$dados3 = array('infusuario' => $infusuario, 'bairro' => $inflocal,'cidade' => $cidade);
					$this->load->view('dadosDoadorDoacao', $dados3);

					$this->session->set_flashdata('doacao_aceita','A doação foi aceita! Abaixo estão os dados do doador');

				}

				if (isset($_POST['rdoacao'])) {
					$aux1 = 'R';

					$this->aceitarRecusarDoacao->recusarDoacaoReceptor($aux1, $doacao);

					
					$motivacoes['lista2'] = ($this->cadastrarDenunciaVulner->selecionarMotivacao());

					$dados3 = array('vulner' => $vulner, 'doacao' => $doa, 'motivacoes' => $motivacoes);
					$this->load->view('cadastroDenunciaDoacao', $dados3);	
				}

			} else {
				redirect('ListagemRecebimentoDoacao','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}