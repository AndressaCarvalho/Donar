<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemDoacaoCadastrada extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->load->model('listarDoacaoCadastrada');

			$us = $this->session->userdata('id_usuario');

			$retorno['lista1'] = ($this->listarDoacaoCadastrada->selecionarDoacao1($us));


			if (!empty($retorno['lista1'])) {
				
				$imagem2['lista2'] = array();
				foreach ($retorno as $li => $l) {
          			foreach ($l as $lis => $list) {

          				if ($list->id_doacao) {
          					$imagem1 = ($this->listarDoacaoCadastrada->selecionarImagemDoacao1($list->id_doacao));

          					if (!empty($imagem1)) {
          						$imagem1 = ($this->listarDoacaoCadastrada->selecionarImagemDoacao1($list->id_doacao))[0];
          						array_push($imagem2['lista2'], $imagem1);
          					}

          				}

					}
				}


          		$vulner2['lista3'] = array();
          		foreach ($retorno as $li2 => $l2) {
          			foreach ($l2 as $lis2 => $list2) {

          				if ($list2->id_doacao) {
          					$vulner1 = ($this->listarDoacaoCadastrada->selecionarVulner1($list2->id_doacao));

          					if (!empty($vulner1)) {
          						$vulner1 = ($this->listarDoacaoCadastrada->selecionarVulner1($list2->id_doacao))[0]->id_vulner;
          						array_push($vulner2['lista3'], $vulner1);
          					}

          				}

          			}
          		}

          		$vulner4['lista4'] = array();
          		foreach ($vulner2 as $li3 => $l3) {
          			foreach ($l3 as $lis3 => $list3) {
          				$vulner3 = ($this->listarDoacaoCadastrada->selecionarVulner2($list3));

          				if (!empty($vulner3)) {
          					$vulner3 = ($this->listarDoacaoCadastrada->selecionarVulner2($list3))[0];
          					array_push($vulner4['lista4'], $vulner3);
          				}

          			}
          		}

          		$vulnerdoacao['lista5'] = ($this->listarDoacaoCadastrada->selecionarVulnerDoacao());


				$dados1 = array('doacoes' => $retorno, 'imgs' => $imagem2, 'vulners' => $vulner4, 'vulnersdoacoes' => $vulnerdoacao);
				$this->load->view('listagemDoacaoCadastrada', $dados1);

			} else {
				$this->session->set_userdata('retorno_inexistente2', 'Você ainda não fez nenhuma doação...');
				$this->load->view('listagemDoacaoCadastrada');
			}


			
		} else {
			redirect('Donar','refresh');
		}

	}


	public function detalhesDoacaoCadastrada() {
		if ($this->session->userdata('id_usuario')) {
			if ($_POST['vulner']) {
				$this->load->model('listarDoacaoCadastrada');

				$vulner = $_POST['vulner'];
				$doacao = $_POST['doacao'];

				
				//Para a situação de vulnerabilidade social
				$vul['lista1'] = ($this->listarDoacaoCadastrada->selecionarVulner3($vulner));

				$imagemv['lista2'] = ($this->listarDoacaoCadastrada->selecionarImagemVulner($vulner));

				foreach ($vul as $li => $l) {
				    foreach ($l as $lis => $list) {

				    	if ($list->id_bairro_cidade) {
				    		$idbaicidv['lista3'] = ($this->listarDoacaoCadastrada->selecionarLocal($list->id_bairro_cidade));
				    	}

				    }
				}

				foreach ($idbaicidv as $li2 => $l2) {
				    foreach ($l2 as $lis2 => $list2) {

				    	if ($list2->id_cidade) {
				    		$idcidv['lista5'] = ($this->listarDoacaoCadastrada->selecionarCidade($list2->id_cidade));
				    	}

				    }
				}


				$itemv['lista6'] = ($this->listarDoacaoCadastrada->selecionarVulnerItem($vulner));

				$categoriav['lista7'] = array();
				$unidadev['lista8'] = array();
				foreach ($itemv as $li3 => $l3) {
				    foreach ($l3 as $lis3 => $list3) {

				    	if ($list3->id_categoria) {
				    		$cat = ($this->listarDoacaoCadastrada->selecionarCategoria($list3->id_categoria))[0];
				    		array_push($categoriav['lista7'], $cat);
				    	}

				    	if ($list3->id_unidade) {
				    		$uni = ($this->listarDoacaoCadastrada->selecionarUnidade($list3->id_unidade))[0];
				    		array_push($unidadev['lista8'], $uni);
				    	}

				    }
				}


				//Para a doação
				$doac['lista9'] = ($this->listarDoacaoCadastrada->selecionarDoacao2($doacao));

				$imagemd['lista10'] = ($this->listarDoacaoCadastrada->selecionarImagemDoacao1($doacao));

				$itemd['lista11'] = ($this->listarDoacaoCadastrada->selecionarDoacaoItem($doacao));

				$categoriad['lista12'] = array();
				$unidaded['lista13'] = array();
				foreach ($itemd as $li4 => $l4) {
				    foreach ($l4 as $lis4 => $list4) {

				    	if ($list4->id_categoria) {
				    		$cat = ($this->listarDoacaoCadastrada->selecionarCategoria($list4->id_categoria))[0];
				    		array_push($categoriad['lista12'], $cat);
				    	}

				    	if ($list4->id_unidade) {
				    		$uni = ($this->listarDoacaoCadastrada->selecionarUnidade($list4->id_unidade))[0];
				    		array_push($unidaded['lista13'], $uni);
				    	}

				    }
				}

				$aux2 = 'D';
				$condoacao1 = ($this->listarDoacaoCadastrada->selecionarVulnerDoacao2($aux2, $doacao));

				$aux3 = 'N';
				$condoacao2 = ($this->listarDoacaoCadastrada->selecionarVulnerDoacao2($aux3, $doacao));

				
				$dados2 = array('vulner' => $vul, 'imagensv' => $imagemv,'bairro' => $idbaicidv, 'cidade' => $idcidv, 'itensv' => $itemv, 'categoriasv' => $categoriav, 'unidadesv' => $unidadev, 'doacao' => $doac, 'imagensd' => $imagemd, 'itensd' => $itemd, 'categoriasd' => $categoriad, 'unidadesd' => $unidaded, 'condoacao1' => $condoacao1, 'condoacao2' => $condoacao2);
				$this->load->view('detalhesDoacaoCadastrada', $dados2);
			} else {
				redirect('ListagemDoacaoCadastrada','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}

	}

	public function confirmarNegarDoacao() {
		if ($this->session->userdata('id_usuario')) {
			if ($_POST['vulner']) {
				$this->load->model('confirmarNegarDoacao');

				$this->load->model('cadastrarDenunciaVulner');

				$vulner['lista1'] = $_POST['vulner'];
				$doacao = $_POST['doacao'];

				if (isset($_POST['cdoacao'])) {
					$aux1 = 'D';
					$aux4 = 'A';

					$this->confirmarNegarDoacao->confirmarDoacaoDoador($aux1, $doacao);

					$readoa = ($this->confirmarNegarDoacao->selecionarSituacao($aux1, $aux4, $doacao));
					if ($readoa) {
						date_default_timezone_set('America/Sao_Paulo');
						$data = date('Y-m-d');
						$horario = date('H:i:s');

						$this->confirmarNegarDoacao->horarioDiaDoacao($horario, $data, $doacao);
					}

					$this->session->set_flashdata('doacao_confirmada', 'Doação confirmada com sucesso');	
					redirect('ListagemDoacaoCadastrada','refresh');	
				}

				if (isset($_POST['ndoacao'])) {
					$aux1 = 'N';

					$this->confirmarNegarDoacao->negarDoacaoDoador($aux1, $doacao);

					
					$motivacoes['lista2'] = ($this->cadastrarDenunciaVulner->selecionarMotivacao());

					$dados3 = array('vulner' => $vulner, 'motivacoes' => $motivacoes);
					$this->load->view('cadastroDenunciaVulner2', $dados3);	
				}
			} else {
				redirect('ListagemDoacaoCadastrada','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}