<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemVulner extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			$this->load->model('listarVulner');

			$us = $this->session->userdata('id_usuario');

			$visi = true;

			$cat2['lista2'] = ($this->listarVulner->selecionarCategoria1());
			$cat3['lista3'] = ($this->listarVulner->selecionarCategoriaN1());

			$vulner['lista6'] = ($this->listarVulner->selecionarVulner2($us));

			$doacaousu['lista20'] = ($this->listarVulner->selecionarDoacao($us));

			$aux2 = false;
			$aux5 = false;
			$aux3 = 'P';
			$aux4 = 'P';
			if (!empty($vulner['lista6'])) {
				foreach ($vulner as $li3 => $l3) {
                	foreach ($l3 as $lis3 => $list3) {

                		$vulnerdoacao2 = ($this->listarVulner->selecionarVulnerDoacao3($list3->id_vulner, $aux3));

                		if ($vulnerdoacao2) {
                			$aux5 = true;
                		}

                	}
            	}

			}

			if (!empty($doacaousu['lista20'])) {
				foreach ($doacaousu as $li20 => $l20) {
                	foreach ($l20 as $lis20 => $list20) {
                		$vulnerdoacao1 = ($this->listarVulner->selecionarVulnerDoacao1($list20->id_doacao, $aux4));

                		if ($vulnerdoacao1) {
                			$aux2 = true;
                		}

                	}
            	}

			}

			if ($aux2 == true) {
				$this->session->set_userdata('doado_doador', 'Existem doações a serem confirmadas como doador dessas. ');
			}

			if ($aux5 == true) {
				$this->session->set_userdata('doado_receptor', 'Existem doações a serem confirmadas como receptor dessas. ');
			}


			$infusuario['lista7'] = ($this->listarVulner->selecionarUsuario($us));

			$inflocal2 = array();
			foreach ($infusuario as $li4 => $l4) {
				foreach ($l4 as $li4 => $list4) {

					if ($list4->id_bairro_cidade) {
						$inflocal1 = ($this->listarVulner->selecionarLocal1($list4->id_bairro_cidade))[0];
						array_push($inflocal2, $inflocal1);
					}

				}
			}


			$locais['lista8'] = ($this->listarVulner->selecionarLocal2($inflocal2[0]->id_cidade));
			

			$retorno = array();
			foreach ($locais as $li5 => $l5) {
				foreach ($l5 as $li5 => $list5) {

					$retorno2 = ($this->listarVulner->selecionarVulner1($visi, $list5->id_bairro_cidade));

					if (!empty($retorno2)) {
						array_push($retorno, $retorno2);	
					}

				}
			}

			
			
			if (!empty($retorno)) {

				$imagem2['lista2'] = array();
				foreach ($retorno as $li => $l) {
					foreach ($l as $li => $list) {
	                    if ($list->id_vulner) {
	                        $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list->id_vulner));

	                        if (!empty($imagem1)) {
	                            $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list->id_vulner))[0];
	                            array_push($imagem2['lista2'], $imagem1);
	                        }

	                    }
                	}

                }

                $dados1 = array('cats2' => $cat2,'cats3' => $cat3, 'vulners' => $retorno, 'imgs' => $imagem2);
				$this->load->view('listagemVulner', $dados1);

			} else {
				$this->session->set_userdata('retorno_inexistente1', 'Não há situações de vulnerabilidade social cadastradas em sua cidade...');
				$this->load->view('listagemVulner');
			}

			
		} else {
			redirect('Donar','refresh');
		}

	}

	public function detalhesVulner() {
		if ($this->session->userdata('id_usuario')) {
		    if ($_POST['vulner']) {
		        $this->load->model('listarVulner');

		        $vulner = $_POST['vulner'];

		          
		        //Para a situação de vulnerabilidade social
		        $vul['lista1'] = ($this->listarVulner->selecionarVulner3($vulner));

		        $aux1 = true;
		        $situacao = ($this->listarVulner->selecionarAvaVulner($vulner, $aux1));

		        $imagemv['lista2'] = ($this->listarVulner->selecionarImagemVulner2($vulner));

		        foreach ($vul as $li => $l) {
		            foreach ($l as $lis => $list) {

		               	if ($list->id_bairro_cidade) {
		                	$idbaicidv['lista3'] = ($this->listarVulner->selecionarLocal($list->id_bairro_cidade));
		               	}

		            }
		        }

		        foreach ($idbaicidv as $li2 => $l2) {
		            foreach ($l2 as $lis2 => $list2) {

		               	if ($list2->id_cidade) {
		                    $idcidv['lista5'] = ($this->listarVulner->selecionarCidade($list2->id_cidade));
		               	}

		            }
		        }


		        $itemv['lista6'] = ($this->listarVulner->selecionarVulnerItem($vulner));

		        $categoriav['lista7'] = array();
		        $unidadev['lista8'] = array();
		        foreach ($itemv as $li3 => $l3) {
		            foreach ($l3 as $lis3 => $list3) {

		               	if ($list3->id_categoria) {
		                    $cat = ($this->listarVulner->selecionarCategoria($list3->id_categoria))[0];
		                    array_push($categoriav['lista7'], $cat);
		               	}

		               	if ($list3->id_unidade) {
		                    $uni = ($this->listarVulner->selecionarUnidade($list3->id_unidade))[0];
		                    array_push($unidadev['lista8'], $uni);
		               	}

		            }
		        }


		        //Para a doação
		        $vulnerdoacao1['lista14'] = ($this->listarVulner->selecionarVulnerDoacao2());

		        $doacao1['lista15'] = array();
		        foreach ($vulnerdoacao1 as $li5 => $l5) {
		            foreach ($l5 as $lis5 => $list5) {
		                                   
		                if ((($list5->id_vulner == $vulner) && ($list5->doado_doador == 'D')) && ($list5->doado_receptor == 'A')) {
		                    array_push($doacao1['lista15'], $list5->id_doacao);
		                }

		            }
		        }

		        $itemd2['lista16'] = array();
		        foreach ($doacao1 as $li6 => $l6) {
		            foreach ($l6 as $lis6 => $list6) {

		                $itemd1 = ($this->listarVulner->selecionarDoacaoItem($list6));

		                if (!empty($itemd1)) {
		                    $itemd1 = ($this->listarVulner->selecionarDoacaoItem($list6))[0];
		                    array_push($itemd2['lista16'], $itemd1);
		                }

		            }
		        }

		        $categoriad['lista17'] = array();
		        $unidaded['lista18'] = array();
		        foreach ($itemd2 as $li7 => $l7) {
		            foreach ($l7 as $lis7 => $list7) {

		               	if ($list7->id_categoria) {
		                    $cat = ($this->listarVulner->selecionarCategoria($list7->id_categoria))[0];
		                    array_push($categoriad['lista17'], $cat);
		               	}

		               	if ($list7->id_unidade) {
		                    $uni = ($this->listarVulner->selecionarUnidade($list7->id_unidade))[0];
		                    array_push($unidaded['lista18'], $uni);
		               	}

		            }
		        }

		          
		        $dados2 = array('vulner' => $vul, 'imagensv' => $imagemv,'bairro' => $idbaicidv, 'cidade' => $idcidv, 'itensv' => $itemv, 'categoriasv' => $categoriav, 'unidadesv' => $unidadev, 'itensd' => $itemd2, 'categoriasd' => $categoriad, 'unidadesd' => $unidaded, 'situacao' => $situacao);
		        $this->load->view('detalhesVulner', $dados2);
		    } else {
		        redirect('ListagemVulner','refresh');
		   	}
		} else {
		    redirect('Donar','refresh');
		}

	}

	public function cadastrarDoacaoDenunciaVulner() {
		if ($this->session->userdata('id_usuario')) {
			if ($_POST['vulner']) {
				$this->load->model('cadastrarDenunciaVulner');

				$this->load->model('cadastrarDoacao');


				$vulner['lista1'] = $_POST['vulner'];

				if (isset($_POST['denunciar'])) {
					$motivacoes['lista2'] = ($this->cadastrarDenunciaVulner->selecionarMotivacao());

					$dados3 = array('vulner' => $vulner, 'motivacoes' => $motivacoes);
					$this->load->view('cadastroDenunciaVulner1', $dados3);
				}

				if (isset($_POST['doar'])) {
					$categorias['lista2'] = ($this->cadastrarDoacao->selecionarCategoria());

					$unidades['lista3'] = ($this->cadastrarDoacao->selecionarUnidade());

					$dados4 = array('vulner' => $vulner, 'categorias' => $categorias, 'unidades' => $unidades);
					$this->load->view('cadastroDoacao', $dados4);
				}

			} else {
				redirect('ListagemVulner','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}


	public function buscaPersonalizadaCategoria() {
		if ($this->session->userdata('id_usuario')) {
		    if (empty($_POST['subcategorias']) && !empty($_POST['categorias'])) {
		    	$this->load->model('listarVulner');

		    	$cat2['lista4'] = ($this->listarVulner->selecionarCategoria1());
				$cat3['lista5'] = ($this->listarVulner->selecionarCategoriaN1());

		    	$categoria = $_POST['categorias'];

		    	$subcat['lista6'] = $this->listarVulner->selecionarSubcategoria($categoria);

		    	
				if (!empty($subcat['lista6'])) {
					$visi = true;

					$vulner = array();
					$aux6 = 1;
					foreach ($subcat as $li1 => $l1) {
						foreach ($l1 as $li1 => $list1) {

							if ($list1->id_vulner) {
								$vulner2 = ($this->listarVulner->selecionarVulner4($visi, $list1->id_vulner));

								if (!empty($vulner2)) {
									$vulner2 = ($this->listarVulner->selecionarVulner4($visi, $list1->id_vulner));

									array_push($vulner, $vulner2);

								}
							}

						}
					}

					if (!empty($vulner)) {
						$imagem2['lista2'] = array();
						foreach ($vulner as $li2 => $l2) {
							foreach ($l2 as $li2 => $list2) {
			                    if ($list2->id_vulner) {
			                        $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list2->id_vulner));

			                        if (!empty($imagem1)) {
			                            $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list2->id_vulner))[0];
			                            array_push($imagem2['lista2'], $imagem1);
			                        }

			                    }

			                }
		            	}

		                $dados = array('cats2' => $cat2,'cats3' => $cat3, 'vulners' => $vulner, 'imgs' => $imagem2);
						$this->load->view('listagemVulnerBusca', $dados);
					} else {
						$this->session->set_flashdata('sem_vulner_categoria','Nenhuma situação de vulnerabilidade social relacionada a esta categoria');
						redirect('ListagemVulner','refresh');
					}
				} else {
					$this->session->set_flashdata('sem_vulner_categoria','Nenhuma situação de vulnerabilidade social relacionada a esta categoria');
					redirect('ListagemVulner','refresh');
				}

		    }
		    elseif (empty($_POST['categorias']) && !empty($_POST['subcategorias'])) {
		    	$this->load->model('listarVulner');

		    	$cat2['lista4'] = ($this->listarVulner->selecionarCategoria1());
				$cat3['lista5'] = ($this->listarVulner->selecionarCategoriaN1());

		    	$subcategoria = $_POST['subcategorias'];

		    	$vulnercat['lista1'] = $this->listarVulner->selecionarVulnerCategoria($subcategoria);

				if (!empty($vulnercat['lista1'])) {
					$visi = true;

					$vulner = array();
					foreach ($vulnercat as $li1 => $l1) {
						foreach ($l1 as $li1 => $list1) {

							if ($list1->id_vulner) {
								$vulner2 = ($this->listarVulner->selecionarVulner4($visi, $list1->id_vulner));

								if (!empty($vulner2)) {
									$vulner2 = ($this->listarVulner->selecionarVulner4($visi, $list1->id_vulner));
									array_push($vulner, $vulner2);
								}
							}

						}
					}

					if (!empty($vulner)) {
						$imagem2['lista2'] = array();
						foreach ($vulner as $li2 => $l2) {
							foreach ($l2 as $li2 => $list2) {
			                    if ($list2->id_vulner) {
			                        $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list2->id_vulner));

			                        if (!empty($imagem1)) {
			                            $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list2->id_vulner))[0];
			                            array_push($imagem2['lista2'], $imagem1);
			                        }

			                    }

			                }
		            	}

		                $dados = array('cats2' => $cat2,'cats3' => $cat3, 'vulners' => $vulner, 'imgs' => $imagem2);
						$this->load->view('listagemVulnerBusca', $dados);
					} else {
						$this->session->set_flashdata('sem_vulner_categoria','Nenhuma situação de vulnerabilidade social relacionada a esta subcategoria');
						redirect('ListagemVulner','refresh');
					}

				} else {
					$this->session->set_flashdata('sem_vulner_categoria','Nenhuma situação de vulnerabilidade social relacionada a esta subcategoria');
					redirect('ListagemVulner','refresh');
				}
		    }
		    elseif (empty($_POST['categorias']) && empty($_POST['subcategorias'])) {
		    	$this->session->set_flashdata('selecao_categoria_inexistente','Selecione a categoria ou a subcategoria');
				redirect('ListagemVulner','refresh');
		    } else {
		    	$this->session->set_flashdata('selecao_categoria','Selecione apenas a categoria ou a subcategoria');
				redirect('ListagemVulner','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

	public function buscaPersonalizadaTitulo() {
		if ($this->session->userdata('id_usuario')) {
			if (!empty($_POST['procurarTexto'])) {
				if ($this->session->userdata('retorno_inexistente9')) {
		    		$this->session->unset_userdata('retorno_inexistente9');
		    	}

		    	$this->load->model('listarVulner');

		    	$cat2['lista4'] = ($this->listarVulner->selecionarCategoria1());
				$cat3['lista5'] = ($this->listarVulner->selecionarCategoriaN1());

		    	$titulo = trim(strtolower($_POST['procurarTexto']));
		    	$visi = true;

		    	$vulner['lista1'] = $this->listarVulner->selecionarVulner5($visi, $titulo);

		    	if (!empty($vulner['lista1'])) {
		    		$imagem2['lista2'] = array();
					foreach ($vulner as $li2 => $l2) {
						foreach ($l2 as $li2 => $list2) {
		                    if ($list2->id_vulner) {
		                        $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list2->id_vulner));

		                        if (!empty($imagem1)) {
		                            $imagem1 = ($this->listarVulner->selecionarImagemVulner1($list2->id_vulner))[0];
		                            array_push($imagem2['lista2'], $imagem1);
		                        }

		                    }

		                }
	            	}

	                $dados = array('cats2' => $cat2,'cats3' => $cat3, 'vulners' => $vulner, 'imgs' => $imagem2);
					$this->load->view('listagemVulnerBusca', $dados);

		    	} else {
					$this->session->set_flashdata('sem_vulner_título','Nenhuma situação de vulnerabilidade social relacionada a esta palavra');
					redirect('ListagemVulner','refresh');
				}

			} else {
				$this->session->set_flashdata('titulo_inexistente','Informe o título');
				redirect('ListagemVulner','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

}