<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CadastroUsuario extends CI_Controller {

	public function index()
	{
		$this->load->view('cadastroUsuario');
	}


	public function cadastrarUsuario() {
		$this->form_validation->set_rules('nome', 'Nome', 'required|max_length[40]|min_length[2]|trim|alpha');
		$this->form_validation->set_rules('sobrenome', 'Sobrenome', 'required|max_length[60]|min_length[2]|trim|alpha');
		$this->form_validation->set_rules('email', 'Email', 'required|max_length[254]|min_length[7]|trim|valid_email');
		$this->form_validation->set_rules('numTelefone', 'Número de telefone', 'required|max_length[13]|min_length[13]|trim');
        $this->form_validation->set_rules('senha', 'Senha', 'required|max_length[12]|min_length[6]');
        $this->form_validation->set_rules('confirmarSenha', 'Confirmar a senha', 'required|max_length[12]|min_length[6]|matches[senha]');
        $this->form_validation->set_rules('numRua', 'Número da casa', 'required|max_length[5]|min_length[1]|trim');
        $this->form_validation->set_rules('cep', 'CEP', 'required|max_length[9]|min_length[9]|trim');
        $this->form_validation->set_rules('rua', 'Rua', 'required|max_length[100]');
        $this->form_validation->set_rules('bairro', 'Bairro', 'required|max_length[100]');
        $this->form_validation->set_rules('cidade', 'Cidade', 'required|max_length[200]');
        $this->form_validation->set_rules('uf', 'Estado', 'required|max_length[2]');

        if ($this->form_validation->run() == TRUE) {
        	$this->load->model('cadastrarUsuario');

			$estado = $_POST['uf'];
			$cidade = $_POST['cidade'];
			$bairro = $_POST['bairro'];
			
			$imgPerfil = "default.png";

			$email = trim($_POST['email']);
			$primeiroNome = trim($_POST['nome']);
			$sobrenome1 = trim($_POST['sobrenome']);
			$sobrenome2 = str_replace(' ', '.', $sobrenome1);
			$nome = $primeiroNome.' '.$sobrenome2;
			$numTelefone = trim($_POST['numTelefone']);
			$senha = md5($_POST['senha']);
			$numRua = trim($_POST['numRua']);
			$cep = $_POST['cep'];
			$nomeRua = $_POST['rua'];

			$cid = ($this->cadastrarUsuario->selecionarIDCidade($cidade));
			if ($cid) {
				$cid = ($this->cadastrarUsuario->selecionarIDCidade($cidade))[0]->id_cidade;
			} else {
				$cid = 0;
			}

			
			$baicid = ($this->cadastrarUsuario->selecionarIDBairroCidade($bairro, $cid));


			if (!$baicid) {

				if ($cid == 0) {
					$this->cadastrarUsuario->nome_cidade = $cidade;
					$this->cadastrarUsuario->sigla_estado = $estado;
					$this->cadastrarUsuario->inserirCidade();

					$cid = ($this->cadastrarUsuario->selecionarIDCidade($cidade))[0]->id_cidade;
				}

				$this->cadastrarUsuario->nome_bairro = $bairro;
				$this->cadastrarUsuario->id_cidade = $cid;
				$this->cadastrarUsuario->inserirBairroCidade();



				$baicid = ($this->cadastrarUsuario->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

				$this->cadastrarUsuario->nome_usuario = $nome;
				$this->cadastrarUsuario->email = $email;
				$this->cadastrarUsuario->telefone_usuario = $numTelefone;
				$this->cadastrarUsuario->senha = $senha;
				$this->cadastrarUsuario->nome_img_perfil = $imgPerfil;
				$this->cadastrarUsuario->numero_rua_usuario = $numRua;
				$this->cadastrarUsuario->nome_rua_usuario = $nomeRua;
				$this->cadastrarUsuario->cep_usuario = $cep;
				$this->cadastrarUsuario->id_bairro_cidade = $baicid;
				$this->cadastrarUsuario->ativo = true;
				$this->cadastrarUsuario->inserirUsuario();

				$uid = ($this->cadastrarUsuario->selecionarIDUsuario($email))[0]->id_usuario;

				$this->session->set_userdata('id_usuario', $uid);

				$unom = ($this->cadastrarUsuario->selecionarNomeUsuario($uid))[0]->nome_usuario;
				$uper = ($this->cadastrarUsuario->selecionarFotoUsuario($uid))[0]->nome_img_perfil;
				
				$this->session->set_userdata('nome_usuario', $unom);
				
				$diretorio = base_url("/upload_img/");
				$diretorio .= $uper;
				$this->session->set_userdata('perfil_usuario', $diretorio);

				redirect('ListagemVulner','refresh');

			} else {
				$baicid = ($this->cadastrarUsuario->selecionarIDBairroCidade($bairro, $cid))[0]->id_bairro_cidade;

				$this->cadastrarUsuario->nome_usuario = $nome;
				$this->cadastrarUsuario->email = $email;
				$this->cadastrarUsuario->telefone_usuario = $numTelefone;
				$this->cadastrarUsuario->senha = $senha;
				$this->cadastrarUsuario->nome_img_perfil = $imgPerfil;
				$this->cadastrarUsuario->numero_rua_usuario = $numRua;
				$this->cadastrarUsuario->nome_rua_usuario = $nomeRua;
				$this->cadastrarUsuario->cep_usuario = $cep;
				$this->cadastrarUsuario->id_bairro_cidade = $baicid;
				$this->cadastrarUsuario->ativo = true;
				$this->cadastrarUsuario->inserirUsuario();

				$uid = ($this->cadastrarUsuario->selecionarIDUsuario($email))[0]->id_usuario;

				$this->session->set_userdata('id_usuario', $uid);

				$unom = ($this->cadastrarUsuario->selecionarNomeUsuario($uid))[0]->nome_usuario;
				$uper = ($this->cadastrarUsuario->selecionarFotoUsuario($uid))[0]->nome_img_perfil;
				
				$this->session->set_userdata('nome_usuario', $unom);
				
				$diretorio = base_url("/upload_img/");
				$diretorio .= $uper;
				$this->session->set_userdata('perfil_usuario', $diretorio);

				redirect('ListagemVulner','refresh');
			}
		
		} else {
			$this->load->view('cadastroUsuario');
		}
	}
}
