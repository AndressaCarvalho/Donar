<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemVulnerParaAvaliacao extends CI_Controller {

	public function index()
	{
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_avaliador')) || ($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->model('listarVulnerParaAvaliacao');

			$usid = $this->session->userdata('id_usuario');

			$visivel = false;

			$vulner1['lista1'] = ($this->listarVulnerParaAvaliacao->selecionarVulner1($visivel));

			if (!empty($vulner1['lista1'])) {

				$avaliada = false;
				
				$vulner4['lista4'] = array();
				foreach ($vulner1 as $li => $l) {
				    foreach ($l as $lis => $list) {
				          
				        if ($list->id_vulner) {

				        	$vulner5 = ($this->listarVulnerParaAvaliacao->selecionarVulnerParaAvaliacao($list->id_vulner, $avaliada, $usid));

				        	if (!empty($vulner5)) {
				        	    $vulner5 = ($this->listarVulnerParaAvaliacao->selecionarVulnerParaAvaliacao($list->id_vulner, $avaliada, $usid))[0];
				        	    array_push($vulner4['lista4'], $vulner5);
				        	}

				        }
				    }
				}


				if (!empty($vulner4['lista4'])) {

					$imagem2['lista2'] = array();
					$vulner3['lista3'] = array();
					foreach ($vulner4 as $li => $l) {
					     foreach ($l as $lis => $list) {
					          
					          if ($list->id_vulner) {
					               $imagem1 = ($this->listarVulnerParaAvaliacao->selecionarImagemVulner1($list->id_vulner));

					               if (!empty($imagem1)) {
					                    $imagem1 = ($this->listarVulnerParaAvaliacao->selecionarImagemVulner1($list->id_vulner))[0];
					                    array_push($imagem2['lista2'], $imagem1);
					               }
					          }

					          if ($list->id_vulner) {
					               $vulner2 = ($this->listarVulnerParaAvaliacao->selecionarVulner2($list->id_vulner));

					               if (!empty($vulner2)) {
					                    $vulner2 = ($this->listarVulnerParaAvaliacao->selecionarVulner2($list->id_vulner))[0];
					                    array_push($vulner3['lista3'], $vulner2);
					               }
					          }

					     }
					}

					$dados1 = array('imgs' => $imagem2, 'vulners' => $vulner3);
					$this->load->view('listagemVulnerParaAvaliacao', $dados1);

				} else {
                	$this->session->set_userdata('retorno_inexistente5', 'Não há nenhuma situação de vulnerabilidade social pendente de avaliação');
               		$this->load->view('listagemVulnerParaAvaliacao');
            	}


			} else {
                $this->session->set_userdata('retorno_inexistente5', 'Não há nenhuma situação de vulnerabilidade social pendente de avaliação');
                $this->load->view('listagemVulnerParaAvaliacao');
            }

		} else {
			redirect('Donar','refresh');
		}
	}


	public function detalhesVulnerParaAvaliacao() {
	    if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_avaliador')) || ($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
	        if ($_POST['vulner']) {
	            $this->load->model('listarVulnerParaAvaliacao');

	            $vulner = $_POST['vulner'];


	            $vul['lista1'] = ($this->listarVulnerParaAvaliacao->selecionarVulner3($vulner));

	            $imagemv['lista2'] = ($this->listarVulnerParaAvaliacao->selecionarImagemVulner2($vulner));

	            foreach ($vul as $li => $l) {
	                foreach ($l as $lis => $list) {

	                    if ($list->id_bairro_cidade) {
	                        $idbaicidv['lista3'] = ($this->listarVulnerParaAvaliacao->selecionarLocal($list->id_bairro_cidade));
	                    }

	                }
	            }

	            foreach ($idbaicidv as $li2 => $l2) {
	                foreach ($l2 as $lis2 => $list2) {

	                    if ($list2->id_cidade) {
	                        $idcidv['lista5'] = ($this->listarVulnerParaAvaliacao->selecionarCidade($list2->id_cidade));
	                    }

	                }
	            }


	            $itemv['lista6'] = ($this->listarVulnerParaAvaliacao->selecionarVulnerItem($vulner));

	            $categoriav['lista7'] = array();
	            $unidadev['lista8'] = array();
	            foreach ($itemv as $li3 => $l3) {
	                foreach ($l3 as $lis3 => $list3) {

	                    if ($list3->id_categoria) {
	                        $cat = ($this->listarVulnerParaAvaliacao->selecionarCategoria($list3->id_categoria))[0];
	                        array_push($categoriav['lista7'], $cat);
	                    }

	                    if ($list3->id_unidade) {
	                        $uni = ($this->listarVulnerParaAvaliacao->selecionarUnidade($list3->id_unidade))[0];
	                        array_push($unidadev['lista8'], $uni);
	                    }

	                }
	            }

	               
	            $dados2 = array('vulner' => $vul, 'imagensv' => $imagemv,'bairro' => $idbaicidv, 'cidade' => $idcidv, 'itensv' => $itemv, 'categoriasv' => $categoriav, 'unidadesv' => $unidadev);
	            $this->load->view('detalhesVulnerParaAvaliacao', $dados2);
	        } else {
	            redirect('ListagemVulnerParaAvaliacao','refresh');
	        }
	    } else {
	        redirect('Donar','refresh');
	    }

	}


	public function confirmarNegarVulner() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_avaliador')) || ($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			if ($_POST['vulner']) {
				$this->load->model('confirmarNegarVulner');

				$this->load->model('cadastrarDenunciaVulner');

				$vulner['lista1'] = $_POST['vulner'];

				$vul = $_POST['vulner'];

				$us = $this->session->userdata('id_usuario');

				if (isset($_POST['cvulner'])) {
					$aux1 = true;
					$aux2 = false;

					$this->confirmarNegarVulner->confirmarVVulner($aux1, $vul);

					$this->confirmarNegarVulner->confirmarAvaliacaoVulner($aux1, $aux2, $vul, $us);

					$this->session->set_flashdata('vulner_confirmada', 'Veracidade da situação de vulnerabilidade social confirmada com sucesso');	
					redirect('ListagemVulnerParaAvaliacao','refresh');
				}

				if (isset($_POST['nvulner'])) {
					$aux1 = true;
					$aux2 = false;

					$this->confirmarNegarVulner->confirmarAvaliacaoVulner($aux1, $aux2, $vul, $us);

					$this->session->set_flashdata('vulner_negada', 'A situação de vulnerabilidade social é inverídica, e não estará visível para possíveis doadores');
							
					redirect('ListagemVulnerParaAvaliacao','refresh');
				}

			} else {
				redirect('ListagemVulnerParaAvaliacao','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}

	}

}