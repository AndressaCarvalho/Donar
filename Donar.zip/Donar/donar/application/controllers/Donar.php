<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Donar extends CI_Controller {

	public function index()
	{
		if ($this->session->userdata('id_usuario')) {
			redirect('ListagemVulner','refresh');
		} else {
			$this->load->view('donar');
		}
	}

	public function carregar() {
		if (isset($_POST['sobre'])) {
			
		}

		if (isset($_POST['cadastro'])) {
			redirect('CadastroUsuario','refresh');
		}

		if (isset($_POST['entrar'])) {
			redirect('Login','refresh');
		}

	}

	public function logout()
	{
		$this->session->unset_userdata('perfil_usuario');
		$this->session->unset_userdata('nome_usuario');
		$this->session->unset_userdata('id_usuario');

		if ($this->session->userdata('id_adm')) {
			$this->session->unset_userdata('id_adm');
		}

		if ($this->session->userdata('id_avaliador')) {
			$this->session->unset_userdata('id_avaliador');
		}

		if ($this->session->userdata('retorno_inexistente1')) {
			$this->session->unset_userdata('retorno_inexistente1');
		}

		if ($this->session->userdata('retorno_inexistente2')) {
			$this->session->unset_userdata('retorno_inexistente2');
		}

		if ($this->session->userdata('retorno_inexistente3')) {
			$this->session->unset_userdata('retorno_inexistente3');
		}

		if ($this->session->userdata('retorno_inexistente4')) {
			$this->session->unset_userdata('retorno_inexistente4');
		}

		if ($this->session->userdata('retorno_inexistente5')) {
			$this->session->unset_userdata('retorno_inexistente5');
		}

		if ($this->session->userdata('retorno_inexistente6')) {
			$this->session->unset_userdata('retorno_inexistente6');
		}

		if ($this->session->userdata('retorno_inexistente7')) {
			$this->session->unset_userdata('retorno_inexistente7');
		}

		if ($this->session->userdata('retorno_inexistente8')) {
			$this->session->unset_userdata('retorno_inexistente8');
		}

		if ($this->session->userdata('doado_doador')) {
			$this->session->unset_userdata('doado_doador');
		}

		if ($this->session->userdata('doado_receptor')) {
			$this->session->unset_userdata('doado_receptor');
		}

		$this->load->view('donar');
	}

}