<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListagemUsuarioParaAvaliador extends CI_Controller {

	public function index()
	{
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->model('listarUsuarioParaAvaliador');

			$aux2 = null;
			$ava['lista1'] = ($this->listarUsuarioParaAvaliador->selecionarAva1($aux2));

			$aux = false;
			$nava = array();
			if (!empty($ava['lista1'])) {
				foreach ($ava as $li1 => $l1) {
                	foreach ($l1 as $lis1 => $list1) {

                		if ($list1->id_usuario) {
                			$nava2 = ($this->listarUsuarioParaAvaliador->selecionarNAva($list1->id_usuario, $aux));

                			if (!empty($nava2)) {
                				$nava2 = ($this->listarUsuarioParaAvaliador->selecionarNAva($list1->id_usuario, $aux))[0];
                				array_push($nava, $nava2);
                			}
                		}

                	}
                }
            }

            $avaf = array();
            if (!empty($nava)) {
				foreach ($nava as $li2 => $list2) {
                	if ($list2->id_usuario) {
                		$avaf2 = ($this->listarUsuarioParaAvaliador->selecionarAva2($list2->id_usuario));

                		if (!empty($avaf2)) {
                			$avaf2 = ($this->listarUsuarioParaAvaliador->selecionarAva2($list2->id_usuario))[0];
                			array_push($avaf, $avaf2);
                		}
                	}
                }
            }


            if (!empty($avaf)) {
                $dados1 = array('nava' => $nava,'avaf' => $avaf);
				$this->load->view('listagemUsuarioParaAvaliador', $dados1);

			} else {
				$this->session->set_userdata('retorno_inexistente6', 'Não há usuários que desejam se tornar avaliadores...');
				$this->load->view('listagemUsuarioParaAvaliador');
			}

		} else {
			redirect('Donar','refresh');
		}

	}


	public function detalhesUsuarioParaAvaliador() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			if ($_POST['usuario']) {
				$this->load->model('listarUsuarioParaAvaliador');

				$usuario = $_POST['usuario'];

				$infusuario['lista1'] = ($this->listarUsuarioParaAvaliador->selecionarUsuario($usuario));

				$infava['lista2'] = ($this->listarUsuarioParaAvaliador->selecionarUsuario2($usuario));

				foreach ($infusuario as $li => $l) {
					foreach ($l as $li => $list) {

						if ($list->id_bairro_cidade) {
							$inflocal['lista2'] = ($this->listarUsuarioParaAvaliador->selecionarLocal($list->id_bairro_cidade));
						}

					}
				}

				foreach ($inflocal as $li2 => $l2) {
					foreach ($l2 as $li2 => $list2) {

						if ($list2->id_cidade) {
							$cidade['lista4'] = ($this->listarUsuarioParaAvaliador->selecionarCidade($list2->id_cidade));
						}
					}
				}

				$dados = array('infusuario' => $infusuario, 'infava' => $infava, 'bairro' => $inflocal,'cidade' => $cidade);
				$this->load->view('detalhesUsuarioParaAvaliador', $dados);
			} else {
				redirect('ListagemUsuarioParaAvaliador','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}


	public function aceitarRecusarAvaliador() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			if ($_POST['usuario']) {
				$this->load->model('aceitarRecusarUsuarioAvaliador');

				$usuario = $_POST['usuario'];

				$us['usuario'] = $_POST['usuario'];
				$data['data'] = $_POST['data'];
				$hor['horario'] = $_POST['horario'];

				if (isset($_POST['aceitar'])) {
					$aux = true;
					$this->aceitarRecusarUsuarioAvaliador->atualizarUsuario($usuario, $aux);
					$this->aceitarRecusarUsuarioAvaliador->deletarAvaliador($usuario);

					$this->session->set_flashdata('usuario_atualizado_avaliador1', 'O usuário agora é um avaliador!');
					redirect('ListagemUsuarioParaAvaliador','refresh');
				}

				if (isset($_POST['recusar'])) {
					$dados = array('usuario' => $us, 'data' => $data, 'horario' => $hor);
					$this->load->view('cadastroRecusaParaAvaliador', $dados);
				}

			} else {
				redirect('ListagemUsuarioParaAvaliador','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}

	}

	public function recusarUsuarioAvaliador() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {

			$this->form_validation->set_rules('detalhamento', 'Detalhamento do motivo da recusa a permissão de avaliador', 'required|min_length[15]|max_length[254]|trim');
			if ($this->form_validation->run() == TRUE) {

				$this->load->model('aceitarRecusarUsuarioAvaliador');

				$usuario = $_POST['usuario'];
				$data = $_POST['data'];
				$horario = $_POST['horario'];
				$detalhamento = trim($_POST['detalhamento']);

				$this->aceitarRecusarUsuarioAvaliador->atualizarUsuarioRecusaAvaliador($usuario, $data, $horario, $detalhamento);

				$this->session->set_flashdata('usuario_atualizado_avaliador2', 'O detalhamento da recusa à permissão de avaliador ao usuário foi cadastrado');
				redirect('ListagemUsuarioParaAvaliador','refresh');

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Detalhamento do motivo da recusa a permissão de avaliador, tente de novo');
				redirect('ListagemUsuarioParaAvaliador','refresh');
			}
			
		} else {
			redirect('Donar','refresh');
		}

	}

}