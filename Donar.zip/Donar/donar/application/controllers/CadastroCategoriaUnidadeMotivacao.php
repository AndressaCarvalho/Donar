<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CadastroCategoriaUnidadeMotivacao extends CI_Controller {

	public function cadastrarUnidade1() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->view('cadastroUnidade');
		} else {
			redirect('Donar','refresh');
		}
	}

	public function cadastrarUnidade2() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {

			$this->form_validation->set_rules('unidade', 'Unidade', 'required|is_unique[tb_unidade.nome_unidade]|min_length[1]|max_length[60]|trim');
			if ($this->form_validation->run() == TRUE) {
				$unidade = trim($_POST['unidade']);

				$this->load->model('cadastrarCategoriaUnidadeMotivacao');

				$this->cadastrarCategoriaUnidadeMotivacao->nome_unidade = $unidade;
				$this->cadastrarCategoriaUnidadeMotivacao->cadastrarUnidade();

				$this->session->set_flashdata('unidade_cadastrada', 'A unidade foi cadastrada');
				redirect('CadastroCategoriaUnidadeMotivacao/cadastrarUnidade1','refresh');
			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Unidade, tente novamente');
				redirect('CadastroCategoriaUnidadeMotivacao/cadastrarUnidade1','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}

	public function cadastrarMotivoBanido1() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->view('cadastroMotivoBanido');
		} else {
			redirect('Donar','refresh');
		}
	}

	public function cadastrarMotivoBanido2() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {

			$this->form_validation->set_rules('motivo', 'Motivo', 'required|is_unique[tb_motivo_banido.motivo_banido]|min_length[15]|max_length[150]|trim');
			if ($this->form_validation->run() == TRUE) {
				$motivo = trim($_POST['motivo']);

				$this->load->model('cadastrarCategoriaUnidadeMotivacao');

				$this->cadastrarCategoriaUnidadeMotivacao->motivo_banido = $motivo;
				$this->cadastrarCategoriaUnidadeMotivacao->cadastrarMotivoBanido();

				$this->session->set_flashdata('motivob_cadastrado', 'O motivo de banimento foi cadastrado');
				redirect('CadastroCategoriaUnidadeMotivacao/cadastrarMotivoBanido1','refresh');
			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Motivo, tente novamente');
				redirect('CadastroCategoriaUnidadeMotivacao/cadastrarMotivoBanido1','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}

	public function cadastrarMotivoDenuncia1() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->view('cadastroMotivoDenuncia');
		} else {
			redirect('Donar','refresh');
		}
	}

	public function cadastrarMotivoDenuncia2() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {

			$this->form_validation->set_rules('motivo', 'Motivo', 'required|is_unique[tb_motivacao.motivacao]|min_length[15]|max_length[150]|trim');
			if ($this->form_validation->run() == TRUE) {
				$motivo = trim($_POST['motivo']);

				$this->load->model('cadastrarCategoriaUnidadeMotivacao');

				$this->cadastrarCategoriaUnidadeMotivacao->motivacao = $motivo;
				$this->cadastrarCategoriaUnidadeMotivacao->cadastrarMotivoDenuncia();

				$this->session->set_flashdata('motivod_cadastrada', 'O motivo da denúncia foi cadastrado');
				redirect('CadastroCategoriaUnidadeMotivacao/cadastrarMotivoDenuncia1','refresh');
			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Motivo, tente novamente');
				redirect('CadastroCategoriaUnidadeMotivacao/cadastrarMotivoDenuncia1','refresh');
			}
		} else {
			redirect('Donar','refresh');
		}
	}

	public function cadastrarCategoria1() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			$this->load->model('cadastrarCategoriaUnidadeMotivacao');

			$cat['lista1'] = ($this->cadastrarCategoriaUnidadeMotivacao->selecionarCategoria());
			$dados = array('categorias' => $cat);
			
			$this->load->view('cadastroCategoria', $dados);
		} else {
			redirect('Donar','refresh');
		}
	}

	public function cadastrarCategoria2() {
		if (($this->session->userdata('id_usuario')) && ($this->session->userdata('id_adm'))) {
			
			$this->form_validation->set_rules('categoria', 'categoria', 'required|min_length[1]|max_length[100]|trim');
			if ($this->form_validation->run() == TRUE) {
				$categoria = trim($_POST['categoria']);

				$this->load->model('cadastrarCategoriaUnidadeMotivacao');

				if (empty($_POST['categoriass'])) {
					$this->cadastrarCategoriaUnidadeMotivacao->nome_categoria = $categoria;
					$this->cadastrarCategoriaUnidadeMotivacao->id_categoria_sup = null;
					$this->cadastrarCategoriaUnidadeMotivacao->cadastrarCategoria();

					$this->session->set_flashdata('categoria_cadastrada', 'A categoria foi cadastrada');
					redirect('CadastroCategoriaUnidadeMotivacao/cadastrarCategoria1','refresh');
				} else {
					$categorias = $_POST['categoriass'];
					$this->cadastrarCategoriaUnidadeMotivacao->nome_categoria = $categoria;
					$this->cadastrarCategoriaUnidadeMotivacao->id_categoria_sup = $categorias;
					$this->cadastrarCategoriaUnidadeMotivacao->cadastrarCategoria();

					$this->session->set_flashdata('categoria_cadastrada', 'A categoria foi cadastrada');
					redirect('CadastroCategoriaUnidadeMotivacao/cadastrarCategoria1','refresh');
				}

			} else {
				$this->session->set_flashdata('erro_form', 'Erro de validação no campo Categoria, tente novamente');
				redirect('CadastroCategoriaUnidadeMotivacao/cadastrarCategoria1','refresh');
			}

		} else {
			redirect('Donar','refresh');
		}
	}

}