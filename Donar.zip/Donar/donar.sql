-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 09-Nov-2019 às 19:06
-- Versão do servidor: 10.4.8-MariaDB
-- versão do PHP: 7.2.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `donar`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_avaliacao`
--

CREATE TABLE `tb_avaliacao` (
  `id_avaliacao` int(11) NOT NULL,
  `avaliada` tinyint(4) NOT NULL,
  `id_vulner` int(11) NOT NULL,
  `id_avaliador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_avaliacao`
--

INSERT INTO `tb_avaliacao` (`id_avaliacao`, `avaliada`, `id_vulner`, `id_avaliador`) VALUES
(1, 1, 1, 3),
(2, 1, 2, 2),
(3, 1, 3, 2),
(4, 1, 4, 2),
(5, 1, 25, 2),
(6, 1, 26, 2),
(7, 1, 27, 3),
(8, 1, 29, 3),
(9, 0, 30, 2),
(10, 0, 31, 3),
(11, 1, 32, 2),
(12, 0, 33, 2),
(13, 0, 35, 2),
(15, 1, 37, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_avaliador`
--

CREATE TABLE `tb_avaliador` (
  `id_avaliador` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nome_img_identidade` varchar(254) NOT NULL,
  `nome_img_cresidencia` varchar(254) NOT NULL,
  `descricao_recusa` varchar(254) DEFAULT NULL,
  `data_avaliador` date NOT NULL,
  `horario_avaliador` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_avaliador`
--

INSERT INTO `tb_avaliador` (`id_avaliador`, `id_usuario`, `nome_img_identidade`, `nome_img_cresidencia`, `descricao_recusa`, `data_avaliador`, `horario_avaliador`) VALUES
(1, 3, '1564714204identidade.jpg', '1564714204comprovante-residencia.png', NULL, '2019-08-01', '23:51:55'),
(2, 2, '1564714685identidade.jpg', '1564714685comprovante-residencia.png', NULL, '2019-08-01', '23:58:05'),
(4, 4, '1568567198identidade.jpg', '1568567198comprovante-residencia.png', NULL, '2019-09-15', '14:06:38');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_bairro_cidade`
--

CREATE TABLE `tb_bairro_cidade` (
  `id_bairro_cidade` int(11) NOT NULL,
  `nome_bairro` varchar(100) NOT NULL,
  `id_cidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_bairro_cidade`
--

INSERT INTO `tb_bairro_cidade` (`id_bairro_cidade`, `nome_bairro`, `id_cidade`) VALUES
(1, 'COHAB A', 1),
(2, 'Salgado Filho', 1),
(3, 'Boqueirão', 2),
(4, 'Estrela', 3),
(5, 'São Jerônimo', 1),
(6, 'Centro', 1),
(7, 'Sarandi', 4),
(8, 'Morada do Vale I', 1),
(9, 'COHAB B', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_banido`
--

CREATE TABLE `tb_banido` (
  `id_banido` int(11) NOT NULL,
  `data_banido` date NOT NULL,
  `detalhamento_banido` varchar(254) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_motivo_banido` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_banido`
--

INSERT INTO `tb_banido` (`id_banido`, `data_banido`, `detalhamento_banido`, `id_usuario`, `id_motivo_banido`) VALUES
(1, '2019-07-27', 'Teste detalhamento banido 1', 5, 1),
(2, '2019-09-17', 'Teste banir doador 2', 6, 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_categoria`
--

CREATE TABLE `tb_categoria` (
  `id_categoria` int(11) NOT NULL,
  `nome_categoria` varchar(100) NOT NULL,
  `id_categoria_sup` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_categoria`
--

INSERT INTO `tb_categoria` (`id_categoria`, `nome_categoria`, `id_categoria_sup`) VALUES
(1, 'Móveis', NULL),
(2, 'Mesas', 1),
(3, 'Cadeiras', 1),
(4, 'Sofás', 1),
(5, 'Poltronas', 1),
(6, 'Racks', 1),
(7, 'Estantes', 1),
(8, 'Camas', 1),
(9, 'Colchões', 1),
(10, 'Armários', 1),
(11, 'Guarda-roupas', 1),
(12, 'Outros', 1),
(13, 'Eletrodomésticos', NULL),
(14, 'Fogões', 13),
(15, 'Fornos', 13),
(16, 'Geladeiras', 13),
(17, 'Freezers', 13),
(18, 'Lava-roupas', 13),
(19, 'Eletroportáteis', 13),
(20, 'Outros', 13),
(21, 'Materiais de construção', NULL),
(22, 'Tijolos', 21),
(23, 'Cimento', 21),
(24, 'Areia', 21),
(25, 'Pedra brita', 21),
(26, 'Aditivos', 21),
(27, 'Cal', 21),
(28, 'Aço', 21),
(29, 'Madeira', 21),
(30, 'Telha', 21),
(31, 'Portas', 21),
(32, 'Janelas', 21),
(33, 'Pisos', 21),
(34, 'Materiais hidráulicos', 21),
(35, 'Materiais elétricos', 21),
(36, 'Outros', 21),
(37, 'Animais', NULL),
(38, 'Acessórios para gatos', 37),
(39, 'Acessórios para cachorros', 37),
(40, 'Outros', 37),
(41, 'Serviços', NULL),
(42, 'Reparação/Concerto/Reforma', 41),
(43, 'Transporte/Mudanças', 41),
(44, 'Cuidador', 41),
(45, 'Outros', 41);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cidade`
--

CREATE TABLE `tb_cidade` (
  `id_cidade` int(11) NOT NULL,
  `nome_cidade` varchar(200) NOT NULL,
  `sigla_estado` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_cidade`
--

INSERT INTO `tb_cidade` (`id_cidade`, `nome_cidade`, `sigla_estado`) VALUES
(1, 'Gravataí', 'RS'),
(2, 'Guarapuava', 'PR'),
(3, 'Ponta Grossa', 'PR'),
(4, 'Porto Alegre', 'RS');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_denuncia_doacao`
--

CREATE TABLE `tb_denuncia_doacao` (
  `id_denuncia_doacao` int(11) NOT NULL,
  `data_denuncia_doacao` date NOT NULL,
  `horario_denuncia_doacao` time NOT NULL,
  `detalhamento_denuncia_doacao` varchar(254) DEFAULT NULL,
  `id_doacao` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_motivacao` int(11) NOT NULL,
  `avaliada` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_denuncia_doacao`
--

INSERT INTO `tb_denuncia_doacao` (`id_denuncia_doacao`, `data_denuncia_doacao`, `horario_denuncia_doacao`, `detalhamento_denuncia_doacao`, `id_doacao`, `id_usuario`, `id_motivacao`, `avaliada`) VALUES
(1, '2019-08-03', '02:31:46', NULL, 2, 1, 3, 1),
(2, '2019-08-03', '02:35:23', 'Teste 1 detalhamento denúncia doação', 3, 1, 4, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_denuncia_vulner`
--

CREATE TABLE `tb_denuncia_vulner` (
  `id_denuncia_vulner` int(11) NOT NULL,
  `data_denuncia_vulner` date NOT NULL,
  `horario_denuncia_vulner` time NOT NULL,
  `detalhamento_denuncia_vulner` varchar(254) DEFAULT NULL,
  `id_vulner` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_motivacao` int(11) NOT NULL,
  `avaliada` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_denuncia_vulner`
--

INSERT INTO `tb_denuncia_vulner` (`id_denuncia_vulner`, `data_denuncia_vulner`, `horario_denuncia_vulner`, `detalhamento_denuncia_vulner`, `id_vulner`, `id_usuario`, `id_motivacao`, `avaliada`) VALUES
(1, '2019-07-27', '20:03:24', NULL, 2, 4, 1, 1),
(2, '2019-07-31', '02:47:32', 'Teste denúncia vulner 1 na listagem de doações', 1, 4, 2, 0),
(3, '2019-08-06', '17:27:25', 'Teste denúncia vulner 1 na listagem de vulners', 2, 4, 1, 0),
(4, '2019-08-18', '14:47:21', 'Teste 1 denúncia vulner na listagem de pendentes de avaliação', 3, 2, 1, 1),
(5, '2019-09-15', '17:53:21', NULL, 2, 3, 2, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_doacao`
--

CREATE TABLE `tb_doacao` (
  `id_doacao` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `data_doacao` date NOT NULL,
  `horario_doacao` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_doacao`
--

INSERT INTO `tb_doacao` (`id_doacao`, `id_usuario`, `data_doacao`, `horario_doacao`) VALUES
(2, 6, '2019-07-28', '00:17:47'),
(3, 4, '2019-07-28', '00:46:07'),
(33, 4, '2019-07-28', '02:58:20'),
(34, 4, '2019-08-03', '03:03:21'),
(35, 1, '2019-08-05', '16:15:13'),
(36, 1, '2019-08-06', '17:21:08'),
(37, 2, '2019-08-11', '23:02:31'),
(38, 4, '2019-10-13', '16:08:32'),
(43, 8, '2019-10-25', '19:19:55'),
(46, 4, '2019-11-09', '15:40:38');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_doacao_imagem`
--

CREATE TABLE `tb_doacao_imagem` (
  `id_doacao_imagem` int(11) NOT NULL,
  `nome_img_doacao` varchar(254) NOT NULL,
  `id_doacao` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_doacao_imagem`
--

INSERT INTO `tb_doacao_imagem` (`id_doacao_imagem`, `nome_img_doacao`, `id_doacao`) VALUES
(1, '1564285567cadeira.png', 3),
(3, '1564293500cimento.jpg', 33),
(4, '1565032513tijolo.jpg', 35),
(5, '1565032513tijolo.jpg', 35),
(6, '1565032513tijolo.jpg', 35),
(7, '1565032514tijolo.jpg', 35),
(8, '1565032514tijolo.jpg', 35),
(9, '1565122868colchao.jpg', 36),
(10, '1570993712mesa.jpg', 38),
(11, '1573321238areia.jpg', 46);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_doacao_item`
--

CREATE TABLE `tb_doacao_item` (
  `id_doacao_item` int(11) NOT NULL,
  `id_doacao` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `quantidade_doacao` varchar(30) DEFAULT NULL,
  `id_unidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_doacao_item`
--

INSERT INTO `tb_doacao_item` (`id_doacao_item`, `id_doacao`, `id_categoria`, `quantidade_doacao`, `id_unidade`) VALUES
(3, 2, 2, '1', 1),
(4, 3, 3, '1', 1),
(34, 33, 23, '1', 4),
(35, 34, 23, '2', 4),
(36, 35, 22, '20', 1),
(37, 36, 9, '1', 1),
(38, 37, 3, '1', 1),
(39, 38, 2, '1', 1),
(40, 43, 43, NULL, NULL),
(43, 46, 24, '3', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_motivacao`
--

CREATE TABLE `tb_motivacao` (
  `id_motivacao` int(11) NOT NULL,
  `motivacao` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_motivacao`
--

INSERT INTO `tb_motivacao` (`id_motivacao`, `motivacao`) VALUES
(4, 'A doação cadastrada é imprópria'),
(3, 'A doação cadastrada é inverídica'),
(2, 'A situação de vulnerabilidade social é imprópria'),
(1, 'A situação de vulnerabilidade social é inverídica'),
(6, 'Contato inadequado com o doador'),
(5, 'Contato inadequado com o receptor da doação'),
(12, 'Pedido de doação equivocado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_motivo_banido`
--

CREATE TABLE `tb_motivo_banido` (
  `id_motivo_banido` int(11) NOT NULL,
  `motivo_banido` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_motivo_banido`
--

INSERT INTO `tb_motivo_banido` (`id_motivo_banido`, `motivo_banido`) VALUES
(4, 'A doação cadastrada é imprópria'),
(3, 'A doação cadastrada é inverídica'),
(2, 'A situação de vulnerabilidade social cadastrada é imprópria'),
(1, 'A situação de vulnerabilidade social cadastrada é inverídica'),
(6, 'Contato inadequado com o doador'),
(7, 'Contato inadequado com o receptor de uma doação'),
(5, 'O avaliador não executou corretamente a sua função'),
(8, 'Pedido de doação equivocado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_unidade`
--

CREATE TABLE `tb_unidade` (
  `id_unidade` int(11) NOT NULL,
  `nome_unidade` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_unidade`
--

INSERT INTO `tb_unidade` (`id_unidade`, `nome_unidade`) VALUES
(3, 'g'),
(4, 'kg'),
(2, 'mg'),
(5, 't'),
(1, 'uni');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuario`
--

CREATE TABLE `tb_usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome_usuario` varchar(100) NOT NULL,
  `email` varchar(254) NOT NULL,
  `telefone_usuario` char(13) NOT NULL,
  `senha` varchar(32) NOT NULL,
  `adm` tinyint(4) NOT NULL,
  `avaliador` tinyint(4) NOT NULL,
  `nome_img_perfil` varchar(254) NOT NULL,
  `numero_rua_usuario` varchar(5) NOT NULL,
  `nome_rua_usuario` varchar(100) NOT NULL,
  `cep_usuario` char(9) NOT NULL,
  `id_bairro_cidade` int(11) NOT NULL,
  `ativo` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_usuario`
--

INSERT INTO `tb_usuario` (`id_usuario`, `nome_usuario`, `email`, `telefone_usuario`, `senha`, `adm`, `avaliador`, `nome_img_perfil`, `numero_rua_usuario`, `nome_rua_usuario`, `cep_usuario`, `id_bairro_cidade`, `ativo`) VALUES
(1, 'Andressa Carvalho', 'andressa.carvalho13454@gmail.com', '51 98467-5827', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 'default.png', '61', 'Rua Criciúma', '94050-060', 1, 1),
(2, 'Vera Machado', 'veram@gmail.com', '51 98455-6374', 'e10adc3949ba59abbe56e057f20f883e', 0, 1, 'default.png', '51', 'Rua Jaci Ilma Tedesco Jaeger', '94020-030', 2, 1),
(3, 'Angela Carvalho', 'angelac@gmail.com', '51 98463-7634', 'e10adc3949ba59abbe56e057f20f883e', 1, 1, 'default.png', '89', 'Rua Tubarão', '94050-070', 1, 1),
(4, 'Shinji Ikari', 'shinjiikari@gmail.com', '51 98477-6334', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '1564703778avatars4.png', '64', 'Rua Jaguaruna', '94050-050', 1, 1),
(5, 'Samara Pacheco', 'samarap@hotmail.com', '51 98334-5563', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 'default.png', '67', 'Rua Volta Redonda', '85020-050', 3, 0),
(6, 'Camila Amarante', 'camilaa@outlook.com', '51 98355-6771', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 'default.png', '24', 'Rua Adolfo Postiglione', '84050-050', 4, 0),
(7, 'Andressa Oliveira', 'andressa@localhost', '51 98467-7780', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 'default.png', '78', 'Rua Criciúma', '94050-060', 1, 1),
(8, 'Clarisa Luz', 'clarisa@gmail.com', '51 98563-3102', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, 'default.png', '54', 'Rua Farias Lobato', '94045-060', 9, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_vulnerabilidade`
--

CREATE TABLE `tb_vulnerabilidade` (
  `id_vulner` int(11) NOT NULL,
  `visivel` tinyint(4) NOT NULL,
  `telefone_vulner` char(13) NOT NULL,
  `titulo_vulner` varchar(40) NOT NULL,
  `data_vulner` date NOT NULL,
  `horario_vulner` time NOT NULL,
  `descricao_vulner` varchar(200) NOT NULL,
  `numero_rua_vulner` varchar(5) NOT NULL,
  `nome_rua_vulner` varchar(100) NOT NULL,
  `cep_vulner` char(9) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_bairro_cidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_vulnerabilidade`
--

INSERT INTO `tb_vulnerabilidade` (`id_vulner`, `visivel`, `telefone_vulner`, `titulo_vulner`, `data_vulner`, `horario_vulner`, `descricao_vulner`, `numero_rua_vulner`, `nome_rua_vulner`, `cep_vulner`, `id_usuario`, `id_bairro_cidade`) VALUES
(1, 1, '51 98467-5827', 'Teste 1 Teste 1 Teste 1', '2019-07-27', '19:59:24', '11111111111 111111111111 11111111111 111111111111 1111111111111', '61', 'Rua Criciúma', '94050-060', 1, 1),
(2, 1, '51 98455-7771', 'Teste 2 Teste 2 Teste 2', '2019-07-27', '20:01:16', '22222222 222222222 22222222 222222222 222222222222', '52', 'Rua Timbauva', '94040-020', 1, 5),
(3, 0, '51 98477-6334', 'Teste 3 Teste 3 Teste 3', '2019-08-04', '23:18:06', '333333333 3333333333 33333333 333333333 333333333', '64', 'Rua Jaguaruna', '94050-050', 4, 1),
(4, 1, '51 98477-6334', 'Teste 4 Teste 4 Teste 4 Teste 4 Teste  4', '2019-08-05', '16:07:53', '44444444444 444444444444 444444444444444 444444444444 44444444444444 44444444444444 44444444444444 4444444444444 4444444444444 44444444444444 4444444444444 444444444444 444444444444444 444444444444444', '64', 'Rua Jaguaruna', '94050-050', 4, 1),
(25, 0, '51 98355-6771', 'Teste 5 Teste 5 Teste 5', '2019-08-11', '21:28:19', '555555555 555555555 55555555 555555555 5555555555', '24', 'Rua João Alves dos Santos', '94020-010', 6, 2),
(26, 0, '51 98457-8252', 'Teste 6 Teste 6 Teste 6', '2019-08-11', '21:42:35', '66666666 66666666 66666666 6666666666 666666666', '856', 'Rua Coronel Sarmento', '94010-030', 6, 6),
(27, 1, '51 98477-6334', 'Teste 7 Teste 7 Teste 7', '2019-08-11', '22:32:49', '77777777 77777777777 7777777777 7777777777 77777777777', '64', 'Rua Jaguaruna', '94050-050', 4, 1),
(29, 1, '51 98455-6374', 'Teste 8 Teste 8 Teste 8', '2019-08-23', '01:24:04', '88888888 888888888 88888888 88888888 8888888888', '51', 'Rua Jaci Ilma Tedesco Jaeger', '94020-030', 2, 2),
(30, 0, '51 98466-7557', 'Teste 9 Teste 9 Teste 9', '2019-10-13', '20:33:52', '999999999999 99999999999 999999999999 9999999999999 99999999999', '98', 'Beco Braço do Norte', '94050-020', 1, 1),
(31, 0, '51 98466-5223', 'Teste 10 Teste 10 Teste 10', '2019-10-15', '15:25:04', '10101010101010 10101010101010 10101010101010 1010101010101010 10101010101010', '65', 'Rua Tubarão', '94050-070', 4, 1),
(32, 0, '51 98556-6334', 'Teste 11 Teste 11 Teste 11', '2019-10-15', '15:38:26', '1111111111111111 1111111111111111 1111111111111111 1111111111111111 1111111111111111', '51', 'Rua Alfredo Soares Pitres', '94020-050', 4, 2),
(33, 0, '51 98467-7780', 'Teste 12 Teste 12 Teste 12', '2019-10-25', '18:21:55', '1212121212121212 1212121212121212 12121212121212 12121212121212 12121212121212', '51', 'Rua Criciúma', '94050-060', 7, 1),
(35, 0, '51 98504-2762', 'Teste 13 Teste 13 Teste 13', '2019-11-04', '12:15:04', '13131313131313 1313131313131313 1313131313131313 13131313131313 1313131313131313', '98', 'Avenida Conde da Figueira', '94085-010', 4, 8),
(37, 1, '51 98467-5821', 'Teste 14 Teste 14 Teste 14', '2019-11-09', '15:36:56', '1414141414141414 1414141414141414 1414141414141414 141414141414141414 14141414141414', '68', 'Rua Criciúma', '94050-060', 7, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_vulner_doacao`
--

CREATE TABLE `tb_vulner_doacao` (
  `id_vulner_doacao` int(11) NOT NULL,
  `id_vulner` int(11) NOT NULL,
  `id_doacao` int(11) NOT NULL,
  `doado_doador` char(1) NOT NULL,
  `doado_receptor` char(1) NOT NULL,
  `descricao_rejeicao_receptor` varchar(254) DEFAULT NULL,
  `data_confirmacao_doacao` date DEFAULT NULL,
  `horario_confirmacao_doacao` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_vulner_doacao`
--

INSERT INTO `tb_vulner_doacao` (`id_vulner_doacao`, `id_vulner`, `id_doacao`, `doado_doador`, `doado_receptor`, `descricao_rejeicao_receptor`, `data_confirmacao_doacao`, `horario_confirmacao_doacao`) VALUES
(1, 1, 2, 'N', 'R', 'Teste 1 detalhamento recusa doação', NULL, NULL),
(2, 2, 3, 'N', 'R', NULL, NULL, NULL),
(32, 1, 33, 'N', 'A', NULL, NULL, NULL),
(33, 1, 34, 'D', 'A', NULL, '2019-08-03', '03:08:16'),
(34, 4, 35, 'D', 'A', NULL, NULL, NULL),
(35, 4, 36, 'N', 'P', NULL, NULL, NULL),
(36, 2, 37, 'P', 'P', NULL, NULL, NULL),
(37, 1, 38, 'P', 'P', NULL, NULL, NULL),
(38, 27, 43, 'P', 'P', NULL, NULL, NULL),
(41, 37, 46, 'D', 'A', NULL, '2019-11-09', '15:41:49');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_vulner_imagem`
--

CREATE TABLE `tb_vulner_imagem` (
  `id_vulner_imagem` int(11) NOT NULL,
  `nome_img_vulner` varchar(254) NOT NULL,
  `id_vulner` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_vulner_imagem`
--

INSERT INTO `tb_vulner_imagem` (`id_vulner_imagem`, `nome_img_vulner`, `id_vulner`) VALUES
(1, '1564268365mesa.jpg', 1),
(2, '1564268365cimento.jpg', 1),
(3, '1564971486armario.jpg', 3),
(4, '1564971486geladeira.jpg', 3),
(5, '1564971486colchao.jpg', 3),
(6, '1564971486mesa.jpg', 3),
(7, '1564971486poltrona.jpg', 3),
(8, '1565032073tijolo.jpg', 4),
(9, '1565032073madeira.jpg', 4),
(10, '1565032073mesa.jpg', 4),
(11, '1565032073colchao.jpg', 4),
(12, '1565032073criadomudo.jpg', 4),
(13, '1571163904armario.jpg', 31),
(14, '1571164707casa-cachorro.jpg', 32),
(15, '1573321016areia.jpg', 37),
(16, '1573321016brita.jpg', 37),
(17, '1573321016madeira.jpg', 37),
(18, '1573321016telha.png', 37),
(19, '1573321016tijolo.jpg', 37);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_vulner_item`
--

CREATE TABLE `tb_vulner_item` (
  `id_vulner_item` int(11) NOT NULL,
  `id_vulner` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `quantidade_vulner` varchar(30) DEFAULT NULL,
  `id_unidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_vulner_item`
--

INSERT INTO `tb_vulner_item` (`id_vulner_item`, `id_vulner`, `id_categoria`, `quantidade_vulner`, `id_unidade`) VALUES
(1, 1, 2, '1', 1),
(2, 1, 23, '5', 4),
(3, 2, 3, '4', 1),
(4, 3, 10, '1', 1),
(5, 3, 16, '1', 1),
(6, 3, 9, '1', 1),
(7, 3, 2, '1', 1),
(8, 3, 5, '1', 1),
(9, 4, 22, '23333', 1),
(10, 4, 29, '85555', 1),
(11, 4, 2, '33333', 1),
(12, 4, 9, '11111', 1),
(13, 4, 12, '22222', 1),
(14, 4, 10, '11111', 1),
(15, 4, 19, '33333', 1),
(16, 4, 16, '22222', 1),
(17, 4, 8, '55555', 1),
(18, 4, 24, '11111', 5),
(20, 25, 43, NULL, NULL),
(21, 26, 27, '1', 4),
(22, 27, 43, NULL, NULL),
(23, 29, 44, NULL, NULL),
(24, 30, 5, '3', 1),
(25, 31, 10, '6', 1),
(26, 32, 39, '1', 1),
(27, 33, 7, '1', 1),
(28, 35, 24, '30', 4),
(30, 37, 24, '5', 4),
(31, 37, 25, '3', 4),
(32, 37, 29, '30', 1),
(33, 37, 30, '10', 1),
(34, 37, 22, '100', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_avaliacao`
--
ALTER TABLE `tb_avaliacao`
  ADD PRIMARY KEY (`id_avaliacao`),
  ADD KEY `fk_tb_avaliacao_tb_vulnerabilidade1_idx` (`id_vulner`),
  ADD KEY `fk_tb_avaliacao_tb_usuario1_idx` (`id_avaliador`);

--
-- Índices para tabela `tb_avaliador`
--
ALTER TABLE `tb_avaliador`
  ADD PRIMARY KEY (`id_avaliador`),
  ADD KEY `fk_tb_avaliador_tb_usuario1_idx` (`id_usuario`);

--
-- Índices para tabela `tb_bairro_cidade`
--
ALTER TABLE `tb_bairro_cidade`
  ADD PRIMARY KEY (`id_bairro_cidade`),
  ADD KEY `fk_tb_bairro_has_tb_cidade_tb_cidade1_idx` (`id_cidade`);

--
-- Índices para tabela `tb_banido`
--
ALTER TABLE `tb_banido`
  ADD PRIMARY KEY (`id_banido`),
  ADD KEY `fk_tb_banido_tb_usuario1_idx` (`id_usuario`),
  ADD KEY `fk_tb_banido_tb_motivo_banido1_idx` (`id_motivo_banido`);

--
-- Índices para tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  ADD PRIMARY KEY (`id_categoria`),
  ADD KEY `fk_tb_categoria_tb_categoria1_idx` (`id_categoria_sup`);

--
-- Índices para tabela `tb_cidade`
--
ALTER TABLE `tb_cidade`
  ADD PRIMARY KEY (`id_cidade`),
  ADD UNIQUE KEY `nome_cidade_UNIQUE` (`nome_cidade`);

--
-- Índices para tabela `tb_denuncia_doacao`
--
ALTER TABLE `tb_denuncia_doacao`
  ADD PRIMARY KEY (`id_denuncia_doacao`),
  ADD KEY `fk_tb_denuncia_doacao_tb_usuario1_idx` (`id_usuario`),
  ADD KEY `fk_tb_denuncia_doacao_tb_doacao1_idx` (`id_doacao`),
  ADD KEY `fk_tb_denuncia_doacao_tb_motivacao1_idx` (`id_motivacao`);

--
-- Índices para tabela `tb_denuncia_vulner`
--
ALTER TABLE `tb_denuncia_vulner`
  ADD PRIMARY KEY (`id_denuncia_vulner`),
  ADD KEY `fk_tb_denuncia_vulner_tb_vulnerabilidade1_idx` (`id_vulner`),
  ADD KEY `fk_tb_denuncia_vulner_tb_usuario1_idx` (`id_usuario`),
  ADD KEY `fk_tb_denuncia_vulner_tb_motivacao1_idx` (`id_motivacao`);

--
-- Índices para tabela `tb_doacao`
--
ALTER TABLE `tb_doacao`
  ADD PRIMARY KEY (`id_doacao`),
  ADD KEY `fk_tb_doacao_tb_usuario1_idx` (`id_usuario`);

--
-- Índices para tabela `tb_doacao_imagem`
--
ALTER TABLE `tb_doacao_imagem`
  ADD PRIMARY KEY (`id_doacao_imagem`),
  ADD KEY `fk_tb_doacao_imagem_tb_doacao1_idx` (`id_doacao`);

--
-- Índices para tabela `tb_doacao_item`
--
ALTER TABLE `tb_doacao_item`
  ADD PRIMARY KEY (`id_doacao_item`),
  ADD KEY `fk_tb_doacao_item_tb_doacao1_idx` (`id_doacao`),
  ADD KEY `fk_tb_doacao_item_tb_categoria1_idx` (`id_categoria`),
  ADD KEY `fk_tb_doacao_item_tb_unidade1_idx` (`id_unidade`);

--
-- Índices para tabela `tb_motivacao`
--
ALTER TABLE `tb_motivacao`
  ADD PRIMARY KEY (`id_motivacao`),
  ADD UNIQUE KEY `motivacao_UNIQUE` (`motivacao`);

--
-- Índices para tabela `tb_motivo_banido`
--
ALTER TABLE `tb_motivo_banido`
  ADD PRIMARY KEY (`id_motivo_banido`),
  ADD UNIQUE KEY `motivo_banido_UNIQUE` (`motivo_banido`);

--
-- Índices para tabela `tb_unidade`
--
ALTER TABLE `tb_unidade`
  ADD PRIMARY KEY (`id_unidade`),
  ADD UNIQUE KEY `nome_unidade_UNIQUE` (`nome_unidade`);

--
-- Índices para tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `fk_tb_usuario_tb_bairro_cidade1_idx` (`id_bairro_cidade`);

--
-- Índices para tabela `tb_vulnerabilidade`
--
ALTER TABLE `tb_vulnerabilidade`
  ADD PRIMARY KEY (`id_vulner`),
  ADD KEY `fk_tb_vulnerabilidade_tb_usuario1_idx` (`id_usuario`),
  ADD KEY `fk_tb_vulnerabilidade_tb_bairro_cidade1_idx` (`id_bairro_cidade`);

--
-- Índices para tabela `tb_vulner_doacao`
--
ALTER TABLE `tb_vulner_doacao`
  ADD PRIMARY KEY (`id_vulner_doacao`),
  ADD KEY `fk_tb_vulner_doacao_tb_vulnerabilidade1_idx` (`id_vulner`),
  ADD KEY `fk_tb_vulner_doacao_tb_doacao1_idx` (`id_doacao`);

--
-- Índices para tabela `tb_vulner_imagem`
--
ALTER TABLE `tb_vulner_imagem`
  ADD PRIMARY KEY (`id_vulner_imagem`),
  ADD KEY `fk_tb_vulner_imagem_tb_vulnerabilidade1_idx` (`id_vulner`);

--
-- Índices para tabela `tb_vulner_item`
--
ALTER TABLE `tb_vulner_item`
  ADD PRIMARY KEY (`id_vulner_item`),
  ADD KEY `fk_tb_vulner_item_tb_unidade1_idx` (`id_unidade`),
  ADD KEY `fk_tb_vulner_item_tb_vulnerabilidade1_idx` (`id_vulner`),
  ADD KEY `fk_tb_vulner_item_tb_categoria1_idx` (`id_categoria`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_avaliacao`
--
ALTER TABLE `tb_avaliacao`
  MODIFY `id_avaliacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `tb_avaliador`
--
ALTER TABLE `tb_avaliador`
  MODIFY `id_avaliador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_bairro_cidade`
--
ALTER TABLE `tb_bairro_cidade`
  MODIFY `id_bairro_cidade` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tb_banido`
--
ALTER TABLE `tb_banido`
  MODIFY `id_banido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de tabela `tb_cidade`
--
ALTER TABLE `tb_cidade`
  MODIFY `id_cidade` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_denuncia_doacao`
--
ALTER TABLE `tb_denuncia_doacao`
  MODIFY `id_denuncia_doacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `tb_denuncia_vulner`
--
ALTER TABLE `tb_denuncia_vulner`
  MODIFY `id_denuncia_vulner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tb_doacao`
--
ALTER TABLE `tb_doacao`
  MODIFY `id_doacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT de tabela `tb_doacao_imagem`
--
ALTER TABLE `tb_doacao_imagem`
  MODIFY `id_doacao_imagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `tb_doacao_item`
--
ALTER TABLE `tb_doacao_item`
  MODIFY `id_doacao_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de tabela `tb_motivacao`
--
ALTER TABLE `tb_motivacao`
  MODIFY `id_motivacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `tb_motivo_banido`
--
ALTER TABLE `tb_motivo_banido`
  MODIFY `id_motivo_banido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `tb_unidade`
--
ALTER TABLE `tb_unidade`
  MODIFY `id_unidade` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `tb_vulnerabilidade`
--
ALTER TABLE `tb_vulnerabilidade`
  MODIFY `id_vulner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de tabela `tb_vulner_doacao`
--
ALTER TABLE `tb_vulner_doacao`
  MODIFY `id_vulner_doacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de tabela `tb_vulner_imagem`
--
ALTER TABLE `tb_vulner_imagem`
  MODIFY `id_vulner_imagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `tb_vulner_item`
--
ALTER TABLE `tb_vulner_item`
  MODIFY `id_vulner_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `tb_avaliacao`
--
ALTER TABLE `tb_avaliacao`
  ADD CONSTRAINT `fk_tb_avaliacao_tb_usuario1` FOREIGN KEY (`id_avaliador`) REFERENCES `tb_usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_avaliacao_tb_vulnerabilidade1` FOREIGN KEY (`id_vulner`) REFERENCES `tb_vulnerabilidade` (`id_vulner`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_avaliador`
--
ALTER TABLE `tb_avaliador`
  ADD CONSTRAINT `fk_tb_avaliador_tb_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_bairro_cidade`
--
ALTER TABLE `tb_bairro_cidade`
  ADD CONSTRAINT `fk_tb_bairro_has_tb_cidade_tb_cidade1` FOREIGN KEY (`id_cidade`) REFERENCES `tb_cidade` (`id_cidade`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_banido`
--
ALTER TABLE `tb_banido`
  ADD CONSTRAINT `fk_tb_banido_tb_motivo_banido1` FOREIGN KEY (`id_motivo_banido`) REFERENCES `tb_motivo_banido` (`id_motivo_banido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_banido_tb_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  ADD CONSTRAINT `fk_tb_categoria_tb_categoria1` FOREIGN KEY (`id_categoria_sup`) REFERENCES `tb_categoria` (`id_categoria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_denuncia_doacao`
--
ALTER TABLE `tb_denuncia_doacao`
  ADD CONSTRAINT `fk_tb_denuncia_doacao_tb_doacao1` FOREIGN KEY (`id_doacao`) REFERENCES `tb_doacao` (`id_doacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_denuncia_doacao_tb_motivacao1` FOREIGN KEY (`id_motivacao`) REFERENCES `tb_motivacao` (`id_motivacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_denuncia_doacao_tb_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_denuncia_vulner`
--
ALTER TABLE `tb_denuncia_vulner`
  ADD CONSTRAINT `fk_tb_denuncia_vulner_tb_motivacao1` FOREIGN KEY (`id_motivacao`) REFERENCES `tb_motivacao` (`id_motivacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_denuncia_vulner_tb_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_denuncia_vulner_tb_vulnerabilidade1` FOREIGN KEY (`id_vulner`) REFERENCES `tb_vulnerabilidade` (`id_vulner`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_doacao`
--
ALTER TABLE `tb_doacao`
  ADD CONSTRAINT `fk_tb_doacao_tb_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_doacao_imagem`
--
ALTER TABLE `tb_doacao_imagem`
  ADD CONSTRAINT `fk_tb_doacao_imagem_tb_doacao1` FOREIGN KEY (`id_doacao`) REFERENCES `tb_doacao` (`id_doacao`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_doacao_item`
--
ALTER TABLE `tb_doacao_item`
  ADD CONSTRAINT `fk_tb_doacao_item_tb_categoria1` FOREIGN KEY (`id_categoria`) REFERENCES `tb_categoria` (`id_categoria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_doacao_item_tb_doacao1` FOREIGN KEY (`id_doacao`) REFERENCES `tb_doacao` (`id_doacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_doacao_item_tb_unidade1` FOREIGN KEY (`id_unidade`) REFERENCES `tb_unidade` (`id_unidade`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  ADD CONSTRAINT `fk_tb_usuario_tb_bairro_cidade1` FOREIGN KEY (`id_bairro_cidade`) REFERENCES `tb_bairro_cidade` (`id_bairro_cidade`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_vulnerabilidade`
--
ALTER TABLE `tb_vulnerabilidade`
  ADD CONSTRAINT `fk_tb_vulnerabilidade_tb_bairro_cidade1` FOREIGN KEY (`id_bairro_cidade`) REFERENCES `tb_bairro_cidade` (`id_bairro_cidade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_vulnerabilidade_tb_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_vulner_doacao`
--
ALTER TABLE `tb_vulner_doacao`
  ADD CONSTRAINT `fk_tb_vulner_doacao_tb_doacao1` FOREIGN KEY (`id_doacao`) REFERENCES `tb_doacao` (`id_doacao`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_vulner_doacao_tb_vulnerabilidade1` FOREIGN KEY (`id_vulner`) REFERENCES `tb_vulnerabilidade` (`id_vulner`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_vulner_imagem`
--
ALTER TABLE `tb_vulner_imagem`
  ADD CONSTRAINT `fk_tb_vulner_imagem_tb_vulnerabilidade1` FOREIGN KEY (`id_vulner`) REFERENCES `tb_vulnerabilidade` (`id_vulner`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_vulner_item`
--
ALTER TABLE `tb_vulner_item`
  ADD CONSTRAINT `fk_tb_vulner_item_tb_categoria1` FOREIGN KEY (`id_categoria`) REFERENCES `tb_categoria` (`id_categoria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_vulner_item_tb_unidade1` FOREIGN KEY (`id_unidade`) REFERENCES `tb_unidade` (`id_unidade`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_vulner_item_tb_vulnerabilidade1` FOREIGN KEY (`id_vulner`) REFERENCES `tb_vulnerabilidade` (`id_vulner`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
